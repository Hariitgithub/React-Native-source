/* eslint-disable no-unused-vars */
import { mmkvStorage } from '../../Utils/Constants';
import { saveAlertMessage } from '../Slice/alertMessage';
import store from '../store/store';
import HttpClient from './HttpClient';

const notify = msg => {
  if (msg) {
    store.dispatch(saveAlertMessage({ msg: msg }));
  }
};

HttpClient.interceptors.response.use(
  response => response,
  error => {
    console.log('from handleException', error.response);
    if (!error.response?.data) {
      notify('Something went wrong  or check your internet');
      return Promise.reject(error);
    }
    if (error?.response?.data) {
      let { data, status, statusText, config, headers, request } =
        error.response;
      console.log('error res', data);
      if (status === 400) {
        if (data?.errors) {
          notify(data?.message + ' ' + data?.errors);
        } else {
          notify(data?.message || data?.detail);
        }
        return data;
      } else if (status === 401) {
        notify('Unauthenticated');
      } else if (status === 404) {
        notify(data?.message ?? data?.detail ?? 'Page Not Found');
      } else {
        notify(`${data?.message}`);
      }
    }
    return Promise.reject(error);
  },
);
//  POST METHOD
export const post = async (url, data) => {
  //to set headers for formdata and token
  const isFormData = data instanceof FormData;
  let config = {};
  config = isFormData
    ? {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }
    : {};
  config = mmkvStorage.getString('token')
    ? {
      headers: {
        ...config?.headers,
        Authorization: `Bearer ${mmkvStorage.getString('token')}`,
      },
    }
    : config?.headers;

  try {
    let res = await HttpClient.post(url, data, config);
    console.log('====================================');
    console.log('POSTTTRESPONCES', res);
    console.log('====================================');
    return PrepareResponse(res);
  } catch (error) {
    return {};
  }
};

//  PUT METHOD
export const put = async (url, data) => {
  //to set headers for formdata and token
  const isFormData = data instanceof FormData;
  let config = {};
  config = isFormData
    ? {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }
    : {};
  config = mmkvStorage.getString('token')
    ? {
      headers: {
        ...config?.headers,
        Authorization: `Bearer ${mmkvStorage.getString('token')}`,
      },
    }
    : config?.headers;

  // console.log('api handler', config);
  try {
    let res = await HttpClient.put(url, data, config);
    return PrepareResponse(res);
  } catch (error) {
    return {};
  }
};

//  PATCH METHOD
export const patch = async (url, data) => {
  //to set headers for formdata and token
  const isFormData = data instanceof FormData;
  let config = {};
  config = isFormData
    ? {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }
    : {};
  config = mmkvStorage.getString('token')
    ? {
      headers: {
        ...config?.headers,
        Authorization: `Bearer ${mmkvStorage.getString('token')}`,
      },
    }
    : config?.headers;

  // console.log('api handler', config);
  try {
    let res = await HttpClient.patch(url, data, config);
    return PrepareResponse(res);
  } catch (error) {
    return {};
  }
};

// GET METHOD
export const get = async (url, data) => {
  let config = mmkvStorage.getString('token')
    ? {
      headers: {
        Authorization: `Bearer ${mmkvStorage.getString('token')}`,
      },
    }
    : {};

  try {
    let res = await HttpClient.get(url, config);
    return PrepareResponse(res);
  } catch (error) {
    return {};
  }
};

// DELETE METHOD
export const deletes = async (url, data) => {
  let config = mmkvStorage.getString('token')
    ? {
      headers: {
        Authorization: `Bearer ${mmkvStorage.getString('token')}`,
      },
    }
    : {};
  try {
    let res = await HttpClient.delete(url, config);
    return PrepareResponse(res);
  } catch (error) {
    return {};
  }
};

// FOR RESPONCSE
const PrepareResponse = res => {
  console.log('PrepareResponse', res);

  if (res?.status >= 200 && res?.status < 300) {
    return res.data;
  }
  notify(res?.message || 'Unexpected error');
  return {};
};
