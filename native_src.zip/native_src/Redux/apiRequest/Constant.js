export const BASE_URL =
  'http://192.168.0.45:8000/api/driver/'; //Local
// 'https://tranzbackend.ninositsolution.com/api/driver/'

export const URLS = {
  LOGIN: 'send-otp',
  VERIFY_OTP: 'verify-otp',
  REGISTER: 'register',
  LOGOUT: 'logout',
  REFERRAL: 'referral/store',
  //profile
  VIEW_PROFILE: 'profile',
  GETDOCUMENT: 'documents',
  EMERGENCY_CONTACT: 'emergency-contacts/bulk-store',
  EMERGENCY: 'emergency-contacts',
  DELETEREASON: 'contents'
};
