import { configureStore } from '@reduxjs/toolkit';
import alertMessage from '../Slice/alertMessage';
import propertyData from '../Slice/propertyData';
import checkIn from '../Slice/checkIn';

const store = configureStore({
  reducer: {
    alertMessage: alertMessage,
    propertyData: propertyData,
    checkIn: checkIn,
  },
});
export default store;
