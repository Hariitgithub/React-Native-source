import { isRejectedWithValue } from '@reduxjs/toolkit';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { saveAlertMessage } from './Slice/alertMessage';

export const rtkQueryErrorLogger =
  ({ dispatch, getState }) =>
  next =>
  action => {
    // console.log("action", action);
    if (isRejectedWithValue(action)) {
      console.log('errorLogger.js:', action);

      if (action?.payload?.status == 400) {
        dispatch(saveAlertMessage({ msg: action.payload?.data?.message }));
        console.log('koio');
      } else if (action?.payload?.status == 401) {
        AsyncStorage.clear()
          .then(() => {
            console.log('AsyncStorage cleared successfully');
            dispatch(saveAlertMessage({ msg: 'Unauthenticated' }));
          })
          .catch(error => {
            console.error('Error clearing AsyncStorage:', error);
          });
      } else if (action?.payload?.status == 500) {
        dispatch(saveAlertMessage({ msg: action?.payload }));
      } else if (action?.payload?.status == 'FETCH_ERROR') {
        dispatch(saveAlertMessage({ msg: 'Check Your Internet' }));
      } else {
        console.warn('Unhandled status code:', action?.payload?.status);
      }
    }

    return next(action);
  };
