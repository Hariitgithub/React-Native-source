import { createSlice } from '@reduxjs/toolkit';

const alertMessage = createSlice({
  name: 'alertMessage',
  initialState: {},
  reducers: {
    saveAlertMessage: (state, action) => {
      return action.payload;
    },
  },
});

export const { saveAlertMessage } = alertMessage.actions;
export default alertMessage.reducer;
