import { createSlice } from '@reduxjs/toolkit';

const checkInSlice = createSlice({
  name: 'checkIn',
  initialState: {
    visible: false,
    visibleData: null,
    source: null,
  },
  reducers: {
    showCheckInModal: (state, action) => {
      if (
        state.visible &&
        state.source === 'notification' &&
        action.payload.source === 'api'
      ) {
        return;
      }
      state.visible = true;
      state.visibleData = action.payload.visibleData;
      state.source = action.payload.source;
    },
    hideCheckInModal: state => {
      state.visible = false;
      state.visibleData = null;
      state.source = null;
    },
    resetFirstView: () => {
      return {
        visible: false,
        visibleData: null,
        source: null,
      };
    },
  },
});

export const { showCheckInModal, hideCheckInModal, resetFirstView } =
  checkInSlice.actions;
export default checkInSlice.reducer;
