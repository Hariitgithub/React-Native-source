import { createSlice } from '@reduxjs/toolkit';

const propertyData = createSlice({
  name: 'propertyData',
  initialState: {},
  reducers: {
    savePropertyData: (state, action) => {
      return action.payload;
    },
  },
});

export const { savePropertyData } = propertyData.actions;
export default propertyData.reducer;
