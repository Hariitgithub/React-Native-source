import RNFS from 'react-native-fs';
import { get, post } from '../Redux/apiRequest/ApiHandler';
import { unzip } from 'react-native-zip-archive';
import RNRestart from 'react-native-restart';
import { Toast } from '../Utils/Constants';
import { URLS } from '../Redux/apiRequest/Constant';

const ZIP_PATH = `${RNFS.DocumentDirectoryPath}/update.zip`;
const EXTRACT_PATH = `${RNFS.DocumentDirectoryPath}`;

export const checkForUpdates = async () => {
  try {
    console.log('insideTry');
    let url = `${URLS.OWNER_VERSION}?type=9`;
    console.log('url', url);
    let res = await get(url);

    console.log('otaRes', res);

    if (res?.status == 'success') {
      let { user_ota_downloaded: update_available, data } = res ?? {};
      let [value] = data ?? [];
      let { image: bundle_url } = value ?? {};

      if (!update_available) {
        const result = await RNFS.downloadFile({
          fromUrl: bundle_url,
          toFile: ZIP_PATH,
        }).promise;

        console.log('resut------------------------------->', result);
        await unzip(ZIP_PATH, EXTRACT_PATH);

        const files = await RNFS.readDir(EXTRACT_PATH);

        console.log(
          'FILES AFTER UNZIP',
          files.map(f => f.name),
        );

        const bundleExists = await RNFS.exists(
          `${RNFS.DocumentDirectoryPath}/main.bundle`,
        );

        console.log('BUNDLE EXISTS =>', bundleExists);

        console.log(
          'Bundle Extracted Successfully-------------------------------------------------->',
        );

        let updateCompleteRes = await post(URLS.VOW_BUILD_DOWNLOAD_COMPLETE);
        console.log('updateCompleteRes---------------->', updateCompleteRes);
        if (updateCompleteRes?.status == 'success') {
          // RNRestart.restart();
          console.log(
            'Process completed-------------------------------------------------->',
          );
          Toast('process completed');
        }
      }
    } else {
      console.log('UpdateRes', res);
    }
  } catch (err) {
    console.log('UpdateErr', err);
  }
};
