/* eslint-disable no-useless-escape */
import {
  Dimensions,
  Platform,
  ToastAndroid,
  Animated,
  Text,
  StyleSheet,
} from 'react-native';
import { createMMKV } from 'react-native-mmkv';
import { VS, HS } from './FontSize';

export const NUMBER = /^\+?[1-9]\d{9,14}$/;
export const EMAIL =
  /^[a-zA-Z][^<>()[\]\\.,;:\s@"]*(\.[^<>()[\]\\.,;:\s@"]+)*@((\[[0-9]{1,3}(\.[0-9]{1,3}){3}\])|(([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}))$/;

// export const EMAIL =
//   /^[a-z][^<>()[\]\\.,;:\s@"]*(\.[\^<>()[\]\\.,;:\s@"]+)*@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

export const URL = /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/;
export const PASSWORD =
  /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

export const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } =
  Dimensions.get('window');

import RNToast from 'react-native-toast-message';
import { URLS } from '../Redux/apiRequest/Constant';
import { post } from '../Redux/apiRequest/ApiHandler';

// ... (existing helper functions)

export const Toast = message => {
  if (message && Platform.OS === 'android') {
    ToastAndroid.show(message, ToastAndroid.SHORT);
  }
};

export const paddingHV = (h, v) => ({
  paddingHorizontal: HS(h),
  paddingVertical: VS(v),
});

export const marginHV = (h, v) => ({
  marginHorizontal: HS(h),
  marginVertical: VS(v),
});

export const mmkvStorage = new createMMKV();
//
export const MAP_KEY = "AIzaSyDyI5lsccJKQP1Qc1h0xVh03aDb3KGzxmk";
// export const RAZORPAY_KEY = 'rzp_live_yelgAnQUfUU1pv';
export const RAZORPAY_KEY = 'rzp_test_RXBsAwYtN6KmFB';
//

export const handlePaymentFailure = async transaction_id => {
  // <--- ADD THIS LINE: Closes the price modal immediately
  try {
    // Path B: Notify backend of failure regardless of popup visibility
    await post(URLS.BOOKING_PAYMENT_FAIL, { transaction_id: transaction_id });
  } catch (error) {
    console.log('Error logging payment failure:', error);
  }

  // Condition: ONLY show the retry popup if BOTH gateways are enabled
};


export const logger = (message, ...logs) => {
  console.group(message);
  logs.forEach(log => console.log(log));
  console.groupEnd();
}


export const Android = Platform.OS === 'android';
export const IOS = Platform.OS === 'ios';