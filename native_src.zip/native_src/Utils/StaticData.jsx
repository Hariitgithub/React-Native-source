import dayjs from 'dayjs';
import {
  Afive,
  Afour,
  Aone,
  Athree,
  Atwo,
  fill_star,
  green_tick,
  name_pro,
  plain_star,
  reviewer_img,
  room_img,
  star,
} from '../assets/images/imgIndex';

export const genderList = [
  { id: 1, name: 'Male' },
  { id: 2, name: 'Female' },
];

export const MartialStatus = [
  { id: 1, name: 'Single' },
  { id: 2, name: 'Married' },
];

export const areaList = [
  { id: 1, name: 'Tnager' },
  { id: 2, name: 'saidapet' },
  { id: 3, name: 'porur' },
  { id: 4, name: 'ECR' },
  { id: 5, name: 'Tambaram' },
  { id: 6, name: 'banglore' },
];

export const sampleList = [
  { id: 1, name: 'test' },
  { id: 2, name: 'test2' },
  { id: 3, name: 'test2' },
  { id: 4, name: 'test2' },
  { id: 5, name: 'test2' },
  { id: 6, name: 'test2' },
  { id: 7, name: 'test2' },
  { id: 8, name: 'test2' },
];

export const bannerList = [
  {
    id: 1,
    url: 'https://images.pexels.com/photos/261181/pexels-photo-261181.jpeg',
  },
  {
    id: 2,
    url: 'https://images.pexels.com/photos/261181/pexels-photo-261181.jpeg',
  },
  {
    id: 3,
    url: 'https://images.pexels.com/photos/261181/pexels-photo-261181.jpeg',
  },
  {
    id: 4,
    url: 'https://images.pexels.com/photos/261181/pexels-photo-261181.jpeg',
  },
];

export const whatsppchatList = [
  { id: 1, name: 'VOW Support', number: '+918939155101' },
];

export const PropertyTypes = [
  { id: 1, name: 'Resort' },
  { id: 2, name: 'Villa' },
  { id: 3, name: 'Apartment' },
  { id: 4, name: 'Homes' },
  { id: 5, name: 'Hotels' },
];

export const tags = [
  { id: 1, name: 'Couple Friendly' },
  { id: 2, name: 'Family Stay' },
  { id: 3, name: 'Pet Friendly' },
  { id: 4, name: 'Luxury ' },
  { id: 5, name: 'Budget Friendly' },
  { id: 6, name: 'Near Beach' },
  { id: 7, name: 'Mountain View' },
  { id: 8, name: 'Private Pool' },
  { id: 9, name: 'Free Breakfast' },
  { id: 10, name: 'Parking Available' },
  { id: 11, name: 'WiFi Included' },
  { id: 12, name: 'Long Stays' },
];

export const roomType = [
  {
    id: '1',
    type: 'Normal',
    price: '₹ 2000',
    status: 'active',
    img: room_img,
  },
  {
    id: '2',
    type: 'Deluxe',
    price: '₹ 3000',
    status: 'sold out',
    img: room_img,
  },
  {
    id: '3',
    type: 'Super Deluxe',
    price: '₹ 3500',
    status: 'active',
    img: room_img,
  },
  {
    id: '4',
    type: 'Suite',
    price: '₹ 5000',
    status: 'active',
    img: room_img,
  },
  {
    id: '5',
    type: 'Executive Suite',
    price: '₹ 6000',
    status: 'sold out',
    img: room_img,
  },
  {
    id: '7',
    type: 'Family Room',
    price: '₹ 4000',
    status: 'active',
    img: room_img,
  },
  {
    id: '8',
    type: 'Twin Room',
    price: '₹ 2500',
    status: 'sold out',
    img: room_img,
  },
  {
    id: '9',
    type: 'King Room',
    price: '₹ 4500',
    status: 'active',
    img: room_img,
  },
  {
    id: '10',
    type: 'Queen Room',
    price: '₹ 4200',
    status: 'sold out',
    img: room_img,
  },
];

export const hints = [
  {
    id: 1,
    hint: 'Rate may vary on weekends than the weekdays for better experience',
    mark: '*',
  },
  {
    id: 2,
    hint: 'Couple friendly ( Unmarried couple are also welcome )',
    mark: '*',
  },
];

export const slots = [
  {
    id: '1',
    slotType: '11 HRS Slot',
    period: 'Night',
    dateTime: '5 Nov, 10am-2pm',
    price: '₹ 4200',
    img: green_tick,
  },
  {
    id: '2',
    slotType: '5 HRS Slot',
    period: 'Day',
    dateTime: '6 Nov, 9am-2pm',
    price: '₹ 2500',
    img: green_tick,
  },
  {
    id: '3',
    slotType: '8 HRS Slot',
    period: 'Night',
    dateTime: '6 Nov, 6pm-2am',
    price: '₹ 3500',
    img: green_tick,
  },
  {
    id: '4',
    slotType: '3 HRS Slot',
    period: 'Day',
    dateTime: '7 Nov, 11am-2pm',
    price: '₹ 1500',
    img: green_tick,
  },
  {
    id: '5',
    slotType: '12 HRS Slot',
    period: 'Night',
    dateTime: '7 Nov, 8pm-8am',
    price: '₹ 5000',
    img: green_tick,
  },
  {
    id: '6',
    slotType: '6 HRS Slot',
    period: 'Day',
    dateTime: '8 Nov, 12pm-6pm',
    price: '₹ 2800',
    img: green_tick,
  },
  {
    id: '7',
    slotType: '10 HRS Slot',
    period: 'Night',
    dateTime: '8 Nov, 9pm-7am',
    price: '₹ 4000',
    img: green_tick,
  },
  {
    id: '8',
    slotType: '4 HRS Slot',
    period: 'Day',
    dateTime: '9 Nov, 2pm-6pm',
    price: '₹ 2000',
    img: green_tick,
  },
];

export const amenities = [
  {
    id: 1,
    img: Aone,
    name: 'Amenity 1',
  },
  {
    id: 2,
    img: Atwo,
    name: 'Amenity 2',
  },
  {
    id: 3,
    img: Athree,
    name: 'Amenity 3',
  },
  {
    id: 4,
    img: Afour,
    name: 'Amenity 4',
  },
  {
    id: 5,
    img: Afive,
    name: 'Amenity 5',
  },
  {
    id: 6,
    img: Aone,
    name: 'Amenity 6',
  },
  {
    id: 7,
    img: Atwo,
    name: 'Amenity 7',
  },
  {
    id: 8,
    img: Athree,
    name: 'Amenity 8',
  },
  {
    id: 9,
    img: Afour,
    name: 'Amenity 9',
  },
  {
    id: 10,
    img: Afive,
    name: 'Amenity 10',
  },
];

export const priceDetail = [
  {
    id: 1,
    Phase_Price: '₹ 2000',
    Wallet_money: '₹ 1000',
    Tips: '₹ 20',
    Total_Amount: '₹ 1020',
  },
];

export const facilities = [
  {
    id: 1,
    Hospital: '1 Km',
    Beach: '2 Km',
    Theater: '2 Km',
    Medical_Shop: '2 Km',
  },
];

export const PropertyPolicyData = [
  {
    id: 1,
    heading: 'House Policy',
    desc: 'Hotel 1 is a 5 star complemented with 80 well bedroom and suit, modern residence in a very strategic.',
  },
  {
    id: 2,
    heading: 'Cancellation Policy',
    desc: 'Hotel 1 is a 5 star complemented with 80 well bedroom and suit, modern residence in a very strategic.',
  },
  {
    id: 3,
    heading: 'Terms & Conditions',
    desc: 'Hotel 1 is a 5 star complemented with 80 well bedroom and suit, modern residence in a very strategic.',
  },
];

export const couponData = [
  {
    id: 1,
    off: '₹ 100 Off',
    code: 'Code “VOW100“',
    content: 'Use the coupon and get ₹100 Off on your first room booking',
    terms: [
      { id: 1, term: 'Valid only on first booking through the app' },
      { id: 2, term: 'Minimum booking value ₹1000' },
      { id: 3, term: 'Cannot be combined with other offers' },
    ],
    status: 'active',
  },
  {
    id: 2,
    off: '₹ 100 Off',
    code: 'Code “VOW100“',
    content: 'Save 20% on all weekend stays',
    terms: [
      { id: 1, term: 'Applicable only on Friday–Sunday check-ins' },
      { id: 2, term: 'Maximum discount capped at ₹500' },
      { id: 3, term: 'Offer valid till 31st Dec 2025' },
    ],
    status: 'active',
  },
  {
    id: 3,
    off: '₹ 100 Off',
    code: 'Code “VOW100“',
    content: 'Get ₹250 cashback on bookings above ₹2000',
    terms: [
      { id: 1, term: 'Cashback credited to your wallet within 24 hrs' },
      { id: 2, term: 'Minimum transaction amount ₹2000' },
      { id: 3, term: 'Cashback not withdrawable, can be reused for booking' },
    ],
    status: 'expired',
  },
  {
    id: 4,
    off: '₹ 100 Off',
    code: 'Code “VOW100“',
    content: 'Flat ₹500 off on your second booking',
    terms: [
      { id: 1, term: 'Applicable only from 2nd booking onwards' },
      { id: 2, term: 'Minimum booking amount ₹1500' },
      { id: 3, term: 'Not applicable on luxury villas' },
    ],
    status: 'active',
  },
  {
    id: 5,
    off: '₹ 100 Off',
    code: 'Code “VOW100“',
    content: 'Get 15% off on festive season bookings',
    terms: [
      { id: 1, term: 'Valid during Diwali & Christmas week' },
      { id: 2, term: 'Maximum discount ₹750' },
      { id: 3, term: 'Non-refundable bookings not included' },
    ],
    status: 'active',
  },
];

export const ratings = [
  {
    id: 1,
    rating: 5,
    percentage: 1,
    value: '100%',
  },
  {
    id: 2,
    rating: 4,
    percentage: 0.8,
    value: '80%',
  },
  {
    id: 3,
    rating: 3,
    percentage: 0.6,
    value: '60%',
  },
  {
    id: 4,
    rating: 2,
    percentage: 0.4,
    value: '40%',
  },
  {
    id: 5,
    rating: 1,
    percentage: 0.2,
    value: '20%',
  },
];

export const reviewData = [
  {
    id: 1,
    name: 'Nayanthara',
    review:
      'Great place to visit whenever you feel hungry or tired after hours of shopping. Budget friendly and tasteful snacks and food.',
    img: star,
    starCount: 5,
    reviewerImg: reviewer_img,
  },
  {
    id: 2,
    name: 'Vijay',
    review:
      'Amazing experience! The staff were friendly and the service was quick. Highly recommend this place for families.',
    img: star,
    starCount: 4,
    reviewerImg: reviewer_img,
  },
  {
    id: 3,
    name: 'Samantha',
    review:
      'Loved the ambience and the variety of food available. Everything was fresh and delicious.',
    img: star,
    starCount: 5,
    reviewerImg: reviewer_img,
  },
  {
    id: 4,
    name: 'Dhanush',
    review:
      'A nice spot for quick bites. Seating could be more comfortable but overall worth it.',
    img: star,
    starCount: 3,
    reviewerImg: reviewer_img,
  },
  {
    id: 5,
    name: 'Trisha',
    review:
      'One of the best experiences I have had recently. Very clean, well maintained and food quality is superb.',
    img: star,
    starCount: 5,
    reviewerImg: reviewer_img,
  },
  {
    id: 6,
    name: 'Suriya',
    review:
      'Good place for casual hangouts with friends. Pricing is affordable and taste is consistent.',
    img: star,
    starCount: 4,
    reviewerImg: reviewer_img,
  },
  {
    id: 7,
    name: 'Kajal',
    review:
      'Nice place to relax after shopping. Snacks are tasty but the waiting time is a little long.',
    img: star,
    starCount: 3,
    reviewerImg: reviewer_img,
  },
  {
    id: 8,
    name: 'Ajith',
    review:
      'Very impressive service. Staff are courteous and attentive. Will surely come back again.',
    img: star,
    starCount: 5,
    reviewerImg: reviewer_img,
  },
  {
    id: 9,
    name: 'Keerthy',
    review:
      'The food is good but sometimes the crowd makes it hard to find a place to sit. Still recommended.',
    img: star,
    starCount: 4,
    reviewerImg: reviewer_img,
  },
  {
    id: 10,
    name: 'Vikram',
    review:
      'Best value for money! Tasty food, good service and a lively atmosphere.',
    img: star,
    starCount: 5,
    reviewerImg: reviewer_img,
  },
];
