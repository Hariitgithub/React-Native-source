
import { Svg, Path } from 'react-native-svg';



const Arrow_back_icon = (props) => (
  <Svg
    {...props}
    xmlns="http://www.w3.org/2000/svg"
    width={8}
    height={14}
    fill="none"
  >
    <Path
      stroke="#000"
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M6.75 13 .5 6.75 6.75.5"
    />
  </Svg>
)



export { Arrow_back_icon }


