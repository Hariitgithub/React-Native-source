// const S3_BASE = 'https://test-iye.blr1.cdn.digitaloceanspaces.com/VOW-Images';

export const common_location =
  'https://images.pexels.com/photos/10588471/pexels-photo-10588471.jpeg';
export const common_property =
  'https://images.pexels.com/photos/261181/pexels-photo-261181.jpeg';

//Splash
// export const logo = `${S3_BASE}/logo.png`;
export const logo = require('./logo.png');
export const boxIcon = require('./box.png');
export const boxI1con = require('./box1.png');
export const call = require('./call.png');
export const leftArrow = require('./left_arrow.png');
export const bookings = require('./bookings.png');
export const notification = require('./notification.png');
export const homeIocn = require('./home.png');
export const profilePic = require('./profile.png');

export const rightArrow = require('./rightArrow.png');
export const deleteIcon = require('./deleteIcon.png');
export const logoutLogo = require('./logoutLogo.png');
export const pickUpCode = require('./pickUpCode.png');
export const phoneIcon = require('./phoneIcon.png');
export const officeBag = require('./officeBag.png');
export const addHome = require('./addHome.png');
export const personal = require('./personal.png');
export const editIcon = require('./editIcon.png');
export const Userplus = require('./Userplus.png');
export const checks = require('./checks.png');
export const folderIcon = require('./folderIcon.png');
export const connection = require('./connection.png');
export const referStick = require('./referStick.png');
export const yellowRebben = require('./yellowRebben.png');
export const CopyIcon = require('./CopyIcon.png');
export const editText = require('./editText.png');
export const walletIcon = require('./walletIcon.png');
export const docs = require('./docs.png');
export const carIcon = require('./carIcon.png');
export const upload = require('./upload.png');
export const downArrow = require('./downArrow.png');
export const share = require('./share.png');
export const mailicon = require('./mailicon.png');
export const facebook = require('./facebook.png');
export const whatsapp = require('./whatsapp.png');
export const pointer_img = require("./Pointer.png");