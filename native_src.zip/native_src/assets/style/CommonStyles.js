import { StyleSheet } from 'react-native';
import { VS } from '../../Utils/FontSize';
import { C } from '../../Utils/ColorFonts';

export const commonStyles = StyleSheet.create({
  shadow: {
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 2, // For Android
  },
  RowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: MS(10),
  },
  Line: {
    borderWidth: 1,
    borderColor: C.BORDER_COLOR,
    marginVertical: VS(15),
  },
});
