/* eslint-disable react-native/no-inline-styles */
/* eslint-disable react-hooks/exhaustive-deps */
import { Modal, StyleSheet, View } from 'react-native';
import React, { useEffect } from 'react';
import { SCREEN_HEIGHT, SCREEN_WIDTH } from '../../Utils/Constants';
import { HS, MS, VS } from '../../Utils/FontSize';
import Word from '../../Component/Word/Word';
import LottieView from 'lottie-react-native';

const Location = () => {
  return (
    // <Modal transparent={true} animationType="fade" visible={show}>
    <View style={styles.container}>
      <View
        style={{
          width: '95%',
          backgroundColor: '#fff',
          borderRadius: MS(20),
          paddingVertical: VS(20),
        }}
      >
        <LottieView
          source={require('./location.json')}
          autoPlay
          loop={true}
          cacheComposition
          style={{ height: VS(160), width: HS(200), alignSelf: 'center' }}
        />
      </View>
    </View>
    // </Modal>
  );
};

export default Location;

const styles = StyleSheet.create({
  container: {
    width: HS(24),
    height: VS(14),
    // position: 'absolute',
    zIndex: 10,
    top: 0,
    left: 0,
    backgroundColor: 'rgba(0,0,0,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
