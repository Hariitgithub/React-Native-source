/* eslint-disable react-native/no-inline-styles */
/* eslint-disable react-hooks/exhaustive-deps */
import { Modal, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React, { useEffect } from 'react';
import { SCREEN_HEIGHT, SCREEN_WIDTH } from '../../Utils/Constants';
import { HS, MS, VS } from '../../Utils/FontSize';
import Word from '../../Component/Word/Word';
import LottieView from 'lottie-react-native';
import { F } from '../../Utils/ColorFonts';

const SuccessPopup = ({ show, setShow, message, onPopupClose }) => {
  useEffect(() => {
    if (!show) return;
    setTimeout(
      () => {
        setShow?.(false);
        onPopupClose?.();
      },
      message ==
        'Thanks for booking. Your booking status will be updated within 5 minutes.'
        ? 5000
        : 3000,
    );
  }, [show]);

  console.log('HJKL', show, setShow, message, onPopupClose);

  return (
    <Modal transparent={true} animationType="fade" visible={show}>
      <View style={styles.container}>
        <View
          style={{
            width: '95%',
            backgroundColor: '#fff',
            borderRadius: MS(20),
            paddingVertical: VS(20),
            position: 'relative',
          }}
        >
          {message ==
            'Thanks for booking. Your booking status will be updated within 5 minutes.' && (
              <TouchableOpacity
                style={{
                  position: 'absolute',
                  top: 10,
                  right: 10,
                  borderWidth: 1,
                  borderColor: '#000',
                  borderRadius: 50,
                  width: 25,
                  height: 25,
                  flex: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
                onPress={() => {
                  setShow?.(false);
                  onPopupClose?.();
                }}
              >
                <Text style={{ fontFamily: F.f3 }}>X</Text>
              </TouchableOpacity>
            )}
          <LottieView
            source={require('./success_anim.json')}
            autoPlay
            loop={false}
            cacheComposition
            style={{ height: VS(200), width: HS(200), alignSelf: 'center' }}
          />
          <View
            style={{
              // borderWidth:
              //   message ==
              //   'Thanks for booking. Your booking status will be updated within 5 minutes'
              //     ? 1
              //     : undefined,
              // borderColor:
              //   message ==
              //   'Thanks for booking. Your booking status will be updated within 5 minutes'
              //     ? '#000'
              //     : undefined,
              borderRadius: 10,
              marginHorizontal: 20,
            }}
          >
            <Word
              text={message ?? 'Success'}
              font={3}
              size={22}
              align={'center'}
              mt={10}
              mb={10}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default SuccessPopup;

const styles = StyleSheet.create({
  container: {
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
    // position: 'absolute',
    zIndex: 10,
    top: 0,
    left: 0,
    backgroundColor: 'rgba(0,0,0,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
