/* eslint-disable react-native/no-inline-styles */
/* eslint-disable react-hooks/exhaustive-deps */
import { Modal, StyleSheet, View } from 'react-native';
import React, { useEffect } from 'react';
import { SCREEN_HEIGHT, SCREEN_WIDTH } from '../../Utils/Constants';
import { HS, MS, VS } from '../../Utils/FontSize';
import Word from '../../Component/Word/Word';
import LottieView from 'lottie-react-native';

const CancelPopup = ({ show, setShow, message, onPopupClose }) => {
  useEffect(() => {
    if (!show) return;
    setTimeout(() => {
      setShow?.(false);
      onPopupClose?.();
    }, 3000);
  }, [show]);

  console.log('HJKL', show, setShow, message, onPopupClose);

  return (
    <Modal transparent={true} animationType="fade" visible={show}>
      <View style={styles.container}>
        <View
          style={{
            width: '95%',
            backgroundColor: '#fff',
            borderRadius: MS(20),
            paddingVertical: VS(20),
          }}
        >
          <LottieView
            source={require('./Cancel.json')}
            autoPlay
            loop={false}
            cacheComposition
            style={{ height: VS(200), width: HS(200), alignSelf: 'center' }}
          />
          <Word
            text={message ?? 'Success'}
            font={3}
            size={22}
            align={'center'}
            mt={10}
          />
        </View>
      </View>
    </Modal>
  );
};

export default CancelPopup;

const styles = StyleSheet.create({
  container: {
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
    // position: 'absolute',
    zIndex: 10,
    top: 0,
    left: 0,
    backgroundColor: 'rgba(0,0,0,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
