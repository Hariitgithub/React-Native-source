import { ActivityIndicator } from 'react-native';

const Loader = ({ color, size }) => {
  return <ActivityIndicator size={size ?? 'small'} color={'#000000'} />;
};

export default Loader;
