import { ActivityIndicator, StyleSheet, View } from 'react-native';
import React from 'react';
import { SCREEN_HEIGHT, SCREEN_WIDTH } from '../../Utils/Constants';

const FullLoader = ({ color, size, show }) => {
  return (
    <>
      {show && (
        <View style={styles.Container}>
          <ActivityIndicator size={size ?? 'large'} color={color ?? '#fff'} />
        </View>
      )}
    </>
  );
};

export default FullLoader;

const styles = StyleSheet.create({
  Container: {
    position: 'absolute',
    top: 0,
    left: 0,
    zIndex: 100000001,
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
    backgroundColor: 'rgba(0,0,0,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
