import { StyleSheet, Text, View } from 'react-native';
import React from 'react';
import { SCREEN_HEIGHT, SCREEN_WIDTH } from '../../Utils/Constants';
import LottieView from 'lottie-react-native';
import { MS, VS } from '../../Utils/FontSize';
import Word from '../Word/Word';

const EmptyPage = ({ message, anim }) => {
  return (
    <View
      style={{
        marginTop: VS(100),
        width: '95%',
        backgroundColor: '#fff',
        borderRadius: MS(20),
        paddingVertical: VS(20),
      }}
    >
      <LottieView
        source={
          anim === 'teddy'
            ? require('./Teddy_Bear.json')
            : require('./heart_broken.json')
        }
        autoPlay
        loop={true}
        cacheComposition
        style={{
          height: VS(300),
          width: HS(300),
          alignSelf: 'center',
        }}
        resizeMode="contain"
      />
      <Word
        text={message ?? 'No List Available...'}
        font={3}
        size={22}
        align={'center'}
        mt={10}
      />
    </View>
  );
};

export default EmptyPage;

const styles = StyleSheet.create({});
