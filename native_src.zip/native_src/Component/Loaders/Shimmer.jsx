import React, { useEffect, useState } from 'react';
import ShimmerPlaceHolder from 'react-native-shimmer-placeholder';
import LinearGradient from 'react-native-linear-gradient';
import { C } from '../../Utils/ColorFonts';

const Shimmer = ({ show, style }) => {
  const [reverse, setReverse] = useState(false);
  useEffect(() => {
    if (show)
      setTimeout(() => {
        setReverse(!reverse);
      }, 3000);
  }, [show, reverse]);
  return (
    show && (
      <ShimmerPlaceHolder
        LinearGradient={LinearGradient}
        style={style}
        isReversed={reverse}
      />
    )
  );
};

export default Shimmer;
