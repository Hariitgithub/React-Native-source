/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import { Dimensions, Modal, StyleSheet, Text, View } from 'react-native';
import LottieView from 'lottie-react-native';
import { F } from '../../Utils/ColorFonts';

const { height, width } = Dimensions.get('window');
const NoInternet = () => {
  return (
    <Modal visible transparent>
      <View style={Styles.Container}>
        <LottieView
          source={require('./noInternet.json')}
          autoPlay
          cacheComposition
          loop
          style={{ height: height / 2, width: width }}
        />
        <Text
          style={{
            fontFamily: F.f2,
            marginTop: 20,
            fontSize: 16,
            color: '#000',
          }}
          allowFontScaling={false}
        >
          Oops, No Internet Connection
        </Text>
        <Text
          style={{
            width: '80%',
            textAlign: 'center',
            fontFamily: F.f3,
            fontSize: 13,
            color: '#000',
            opacity: 0.4,
          }}
          allowFontScaling={false}
        >
          Make sure Wifi or Cellular data is turned on and then try again.
        </Text>
      </View>
    </Modal>
  );
};

export default NoInternet;

const Styles = StyleSheet.create({
  Container: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    position: 'absolute',
    top: 0,
    width: width,
    height: height,
    backgroundColor: '#fff',
    zIndex: 100000,
  },
});
