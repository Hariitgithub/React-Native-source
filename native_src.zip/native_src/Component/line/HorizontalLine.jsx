
import React from 'react';
import { View } from 'react-native';
import { VS } from '../../Utils/FontSize';

const HorizontalLine = ({
    color = '#F8F8F8',
    thickness = 2,
    marginVertical = VS(15),
    style
}) => {
    return (
        <View
            style={[
                {
                    height: thickness,
                    backgroundColor: color,
                    width: '100%',
                    marginVertical: marginVertical,
                },
                style,
            ]}
        />
    );
};

export default HorizontalLine;
