/* eslint-disable react-native/no-inline-styles */
/* eslint-disable eqeqeq */
import React from 'react';
import { Image } from 'react-native';
import { SCREEN_HEIGHT, SCREEN_WIDTH } from '../../Utils/Constants';
import { HS, MS, VS } from '../../Utils/FontSize';

const Img = ({
  width,
  height,
  src,
  color,
  resize,
  uri,
  radius,
  size,
  ml,
  mr,
  mt,
  mb,
  mv,
  mh,
  ps,
  pe,
  pt,
  pb,
  pv,
  ph,
  style,
}) => {
  const getSource = src => {
    if (!src) return null;

    if (typeof src === 'object') return src;

    if (typeof src === 'string') {
      return { uri: src };
    }

    return src;
  };

  return (
    <Image
      source={getSource(src)}
      style={[
        {
          width:
            size == '%'
              ? `${width}${size}`
              : size == 'full'
                ? SCREEN_WIDTH
                : width
                  ? HS(width)
                  : null,
          height:
            size == '%'
              ? `${height}${size}`
              : size == 'full'
                ? SCREEN_HEIGHT
                : VS(height),
          borderRadius: MS(radius) || 0,
          marginLeft: ml ? HS(ml) : 0,
          marginRight: mr ? HS(mr) : 0,
          marginTop: mt ? VS(mt) : 0,
          marginBottom: mb ? VS(mb) : 0,
          marginVertical: mv ? VS(mv) : 0,
          marginHorizontal: mh ? HS(mh) : 0,
          paddingLeft: ps ? HS(ps) : 0,
          paddingRight: pe ? HS(pe) : 0,
          paddingTop: pt ? VS(pt) : 0,
          paddingBottom: pb ? VS(pb) : 0,
          paddingVertical: pv ? VS(pv) : 0,
          paddingHorizontal: ph ? HS(ph) : 0,
        },
        style,
        color ? { tintColor: color } : {},
      ]}
      resizeMode={resize === 'cover' ? 'cover' : 'contain'}
    />
  );
};

export default Img;
