import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import SplashScreen from '../../Screens/SplashScreen/SplashScreen';
import Login from '../../Screens/Auth/Login';
import Register from '../../Screens/Auth/Register';
import AccountDeactivated from '../../Screens/Auth/AccountDeactivated';
import OtpComp from '../../Screens/Auth/OtpComp';
import ReferralComp from '../../Screens/Auth/ReferralComp';
import Home from '../../Screens/Home/Home';
import Profile from '../../Screens/Profile/Profile';
import ProfileView from '../../Screens/Profile/ProfileView';
import EmergencyContact from '../../Screens/Profile/EmergencyContact';
import MyReferral from '../../Screens/Profile/MyReferral';
import FavouriteAccount from '../../Screens/Profile/FavouriteAccount';
import DocumentDetails from '../../Screens/Profile/DocumentDetails';
import Documents from '../../Screens/Profile/Documents';
import Vehicle from '../../Screens/Profile/Vehicle';
import WalletScreen from '../../Screens/Profile/WalletScreen';
import EnableOTP from '../../Screens/Profile/EnableOTP';
import DeleteAccount from '../../Screens/Profile/DeleteAccountScreens/DeleteAccount';
import DeletionReason from '../../Screens/Profile/DeleteAccountScreens/DeletionReason';
import DeleteOTP from '../../Screens/Profile/DeleteAccountScreens/DeleteOTP';
import MapScreen from '../../Screens/Profile/MapScreen/MapScreen';


const Stack = createNativeStackNavigator();

const StackNavigator = () => {
  return (
    <Stack.Navigator
      initialRouteName="splash"
      screenOptions={{ headerShown: false }}
    >
      {/* authentication  */}
      <Stack.Screen name="splash" component={SplashScreen} />
      <Stack.Screen name="login" component={Login} />
      <Stack.Screen name="register" component={Register} />
      <Stack.Screen name="otp" component={OtpComp} />
      <Stack.Screen name="referral" component={ReferralComp} />

      {/* main screens  */}
      <Stack.Screen name="home" component={Home} />
      <Stack.Screen name="profile" component={Profile} />
      <Stack.Screen name="profileView" component={ProfileView} />
      <Stack.Screen name="emergencyContact" component={EmergencyContact} />
      <Stack.Screen name="enableOTP" component={EnableOTP} />
      <Stack.Screen name="deleteAccount" component={DeleteAccount} />
      <Stack.Screen name="deletionReason" component={DeletionReason} />
      <Stack.Screen name="deleteOTP" component={DeleteOTP} />
      <Stack.Screen name="accountDeactivated" component={AccountDeactivated} />
      <Stack.Screen name="myReferral" component={MyReferral} />
      <Stack.Screen name="favouriteAccount" component={FavouriteAccount} />
      <Stack.Screen name="documentDetails" component={DocumentDetails} />
      <Stack.Screen name="documents" component={Documents} />
      <Stack.Screen name="vehicle" component={Vehicle} />
      <Stack.Screen name="wallet" component={WalletScreen} />
      <Stack.Screen name="mapScreen" component={MapScreen} />

    </Stack.Navigator>
  );
};

export default StackNavigator;
