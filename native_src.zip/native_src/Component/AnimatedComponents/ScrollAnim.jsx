/* eslint-disable react-native/no-inline-styles */
/* eslint-disable react-hooks/exhaustive-deps */
import {
  Animated,
  BackHandler,
  Keyboard,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { SCREEN_HEIGHT, SCREEN_WIDTH } from '../../Utils/Constants';
import Word from '../Word/Word';
import { MS, VS } from '../../Utils/FontSize';
import { C, F } from '../../Utils/ColorFonts';

const ScrollAnim = ({
  openscroll,
  setOpenScroll,
  title,
  customComp,
  containerHeight,
  bgColor,
  containerStyle,
  disableCloseOnEmptyClick,
}) => {
  const backRef = useRef(null);
  const [keyboardOpen, setKeyboardOpen] = useState(false);

  // 1. Add state to manage if the component should be rendered
  const [isVisible, setIsVisible] = useState(openscroll);

  const scrollAnim = useRef(new Animated.Value(SCREEN_HEIGHT)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current; // 2. Add fade animation for backdrop

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      e => {
        setKeyboardOpen(e.endCoordinates.height);
      },
    );
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => {
        setKeyboardOpen(false);
      },
    );
    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  useFocusEffect(
    useCallback(() => {
      const backAction = () => {
        if (backRef.current) {
          setOpenScroll(false);
          // ScrollAnimation(false) is handled by the useEffect watching `openscroll`
          return true;
        }
      };
      const Handler = BackHandler.addEventListener(
        'hardwareBackPress',
        backAction,
      );
      return () => {
        Handler.remove();
      };
    }, []),
  );

  const ScrollAnimation = show => {
    backRef.current = show;

    if (show) {
      setIsVisible(true); // Mount component before animating
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(scrollAnim, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        })
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(scrollAnim, {
          toValue: SCREEN_HEIGHT,
          duration: 200,
          useNativeDriver: true,
        })
      ]).start(() => {
        setIsVisible(false); // Unmount after animation finishes
      });
    }
  };

  useEffect(() => {
    ScrollAnimation(openscroll);
  }, [openscroll]);

  // 3. Return null if closed to prevent blocking touches
  if (!isVisible) return null;

  return (
    <View style={styles.popupContainer}>

      {/* 4. Backdrop gets the fade animation */}
      <Animated.View
        style={[
          styles.ClosepopupBtn,
          {
            backgroundColor: bgColor ? bgColor : 'rgba(0,0,0,0.4)',
            opacity: fadeAnim
          },
        ]}
      >
        <TouchableOpacity
          activeOpacity={1}
          style={{ flex: 1 }}
          onPress={() => {
            if (
              disableCloseOnEmptyClick ||
              disableCloseOnEmptyClick === undefined
            ) {
              setOpenScroll(false);
            }
            Keyboard.dismiss();
          }}
        />
      </Animated.View>

      {/* 5. Content gets the slide animation */}
      <Animated.View
        style={[
          styles.popupList,
          { height: containerHeight ? containerHeight : '95%' },
          containerStyle,
          { transform: [{ translateY: scrollAnim }] },
        ]}
      >
        {title && (
          <Word
            align={'left'}
            size={35}
            color={'black'}
            text={title}
            font={3}
            mt={30}
          />
        )}
        {customComp}
        <View
          style={{
            height: keyboardOpen,
          }}
        />
      </Animated.View>
    </View>
  );
};

export default ScrollAnim;

const styles = StyleSheet.create({
  popupContainer: {
    height: SCREEN_HEIGHT,
    position: 'absolute',
    bottom: 0,
    top: 0,
    left: 0,
    right: 0,
    width: SCREEN_WIDTH,
    zIndex: 100002,
    elevation: 100002, // Added for Android touch prioritization
  },
  ClosepopupBtn: {
    ...StyleSheet.absoluteFillObject, // Cleaner way to cover the whole screen
    zIndex: -1,
  },
  popupList: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    backgroundColor: '#fff',
    width: SCREEN_WIDTH,
    position: 'absolute',
    bottom: 0,
    paddingHorizontal: '5%',
    zIndex: 1,
    shadowColor: '#000',
    shadowOffset: { height: 20, width: 10 },
    shadowOpacity: 0.8,
    elevation: 10,
  },
  Text: {
    textAlign: 'left',
    marginTop: VS(25),
    color: C.TEXT,
    fontSize: MS(22),
    fontFamily: F.f1,
  },
});