import { StyleSheet, Text, View } from 'react-native';
import React from 'react';
// import Word from './common/Word/Word';
// import { SCREEN_HEIGHT } from '../utils/FontSize';
import Word from './Word/Word';
import { SCREEN_HEIGHT } from '../Utils/Constants';

const RenderEmpty = () => {
  return (
    <View style={styles.empty}>
      <Word text={'No data Found'} />
    </View>
  );
};

export default RenderEmpty;

const styles = StyleSheet.create({
  empty: {
    height: SCREEN_HEIGHT / 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
