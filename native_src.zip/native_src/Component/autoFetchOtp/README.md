# Kotlin Files

Add the above Kt Files into android/app/src/main/java/com/package_name

Change the above three kt files package from com.packagename => com.your_Package_name

add the Below lines into the MainAppilication.kt

import com.Your_package_name.OTPPackage //import this in the top Level change into your package name

add(OTPPackage()) //use this line like below example

        override fun getPackages(): List<ReactPackage> =
            PackageList(this).packages.apply {
              // Packages that cannot be autolinked yet can be added manually here, for example:
              // add(MyReactNativePackage())


              add(OTPPackage())

            }

# Add Dependencies

Open your android/app/build.gradle and add:

Note : Dependency library versions maybe different depends on your react native app versions

dependencies {
implementation 'com.google.android.gms:play-services-auth-api-phone'

    // ... other dependencies

}

Also, ensure Google Maven is added in android/build.gradle:

allprojects {
repositories {
google()
mavenCentral()
}
}

# changing the otp length

if you want to change the receiving otp length (default 4)

goto => MySMSBroadcastReceiver.kt

    ** val otp = Regex("\\d{4,}").find(message ?: "")?.value**

in the above line change the 4 into wanted otp length

# receiving otp from the jsx component

import {useOtpListener} from './useOtpListener';

//paste the below code in the otp screen

const handleOtpReceived = otp => {
console.log('SMS value from Received OTP:', otp);
};

const handleOtpError = useCallback(error => {
console.error('OTP error:', error);
}, []);

useOtpListener(handleOtpReceived, handleOtpError);
