import { StyleSheet } from 'react-native';
import React from 'react';
import MaskedView from '@react-native-masked-view/masked-view';
import LinearGradient from 'react-native-linear-gradient';
import { VS } from '../../Utils/FontSize';

const GradientText = ({ textComponent, Colors, customstyle }) => {
  return (
    <MaskedView
      maskElement={textComponent}
      style={[{ height: VS(80) }, customstyle]}
    >
      <LinearGradient
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        colors={Colors} // Gradient colors
        style={styles.gradient}
      />
    </MaskedView>
  );
};

export default GradientText;

const styles = StyleSheet.create({
  gradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: '100%',
  },
});
