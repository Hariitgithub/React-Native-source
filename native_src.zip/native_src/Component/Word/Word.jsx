/* eslint-disable eqeqeq */
/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import { Text } from 'react-native';
import { HS, MS, VS } from '../../Utils/FontSize';
import { C, F } from '../../Utils/ColorFonts';

const Word = ({
  size,
  font,
  color,
  text,
  onPress,
  align,
  alignVertical,
  line,
  transform,
  ml,
  me,
  mt,
  mb,
  mv,
  mh,
  ps,
  pe,
  pt,
  pb,
  pv,
  ph,
  width,
  style,
  important,
}) => {
  return (
    <Text
      numberOfLines={line}
      onPress={onPress}
      width={width}
      allowFontScaling={false}
      style={[
        {
          fontSize: size ? MS(size) : null,
          textAlign: align,
          textAlignVertical: alignVertical,
          transform: transform,
          marginLeft: ml ? HS(ml) : 0,
          marginRight: me ? HS(me) : 0,
          marginTop: mt ? VS(mt) : 0,
          marginBottom: mb ? VS(mb) : 0,
          marginVertical: mv ? VS(mv) : 0,
          marginHorizontal: mh ? HS(mh) : 0,
          paddingLeft: ps ? HS(ps) : 0,
          paddingRight: pe ? HS(pe) : 0,
          paddingTop: pt ? VS(pt) : 0,
          paddingBottom: pb ? VS(pb) : 0,
          paddingVertical: pv ? VS(pv) : 0,
          paddingHorizontal: ph ? HS(ph) : 0,
          fontFamily:
            font == 1
              ? F.f1
              : font == 2
                ? F.f2
                : font == 3
                  ? F.f3
                  : font == 4
                    ? F.f4
                    : F.f3,
          color:
            color == 'primary'
              ? C.PRIMARY
              : color == 'primary1'
                ? C.PRIMARY1
                : color == 'primary2'
                  ? C.PRIMARY2
                  : color == 'primaryLt'
                    ? C.PRIMARY1
                    : color == 'text'
                      ? C.TEXT
                      : color == 'green'
                        ? C.GREEN
                        : color == 'red'
                          ? C.RED
                          : color == 'orange'
                            ? C.ORANGE
                            : color == 'gray'
                              ? C.GRAY
                              : color == 'gray1'
                                ? C.GRAY1
                                : color == 'white'
                                  ? C.WHITE
                                  : color == 'black'
                                    ? C.BLACK
                                    : color,
        },
        style,
      ]}
    >
      {text}
      {important && (
        <Text
          style={{ color: C.RED, textAlignVertical: 'top' }}
          allowFontScaling={false}
        >
          {' '}
          *
        </Text>
      )}
    </Text>
  );
};

export default Word;
