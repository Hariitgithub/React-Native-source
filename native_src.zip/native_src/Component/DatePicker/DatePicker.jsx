/* eslint-disable react-hooks/exhaustive-deps */
import {
  BackHandler,
  Modal,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { SCREEN_HEIGHT, SCREEN_WIDTH } from '../../Utils/Constants';
import DateTimePicker from 'react-native-ui-datepicker';
import dayjs from 'dayjs';
import { HS, MS, VS } from '../../Utils/FontSize';
import { C, F } from '../../Utils/ColorFonts';
import Word from '../Word/Word';
import Img from '../img/Img';
import { thin_arrow } from '../../assets/images/imgIndex';

const DatePicker = ({
  onSelect,
  showPicker,
  setShowPicker,
  value,
  hidePastDates,
  hideFutureDates,
}) => {
  const today = dayjs();
  const [dateView, setDateView] = useState('day');
  const [selected, setSelected] = useState(today);
  const backref = useRef(false);
  const dateRef = useRef(null);
  console.log('date time ref ', dateRef);
  useFocusEffect(
    useCallback(() => {
      const backAction = () => {
        if (backref.current) {
          setDateView('day');
          setShowPicker?.(false);
          return true;
        }
      };
      let backListener = BackHandler.addEventListener(
        'hardwareBackPress',
        backAction,
      );
      return () => backListener.remove();
    }, []),
  );

  useEffect(() => {
    backref.current = showPicker;
  }, [showPicker]);

  const handleDateChange = date => {
    setSelected(date);
    onSelect?.(date);
    setDateView('day');
    setShowPicker(false);
  };
  return (
    <Modal transparent={true} animationType="fade" visible={showPicker}>
      <View style={styles.container}>
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => {
            setDateView('day');
            setShowPicker?.(false);
          }}
          style={styles.ClostBtn}
        />
        <View style={styles.container2}>
          {/* <View style={styles.selectedDate}>
            <View style={styles.selectedDateContainer}>
              <Word
                text={value ?? dayjs(selected).format('DD')}
                font={3}
                size={25}
                color={'black'}
              />
            </View>
            <Word text={'-'} font={3} size={25} color={'black'} ml={5} />
            <TouchableOpacity
              activeOpacity={1}
              onPress={() => setDateView('month')}
              style={styles.selectedDateContainer}
            >
              <Word
                text={value ?? dayjs(selected).format('MM')}
                font={3}
                size={25}
                color={'black'}
              />
            </TouchableOpacity>
            <Word text={'-'} font={3} size={25} color={'black'} ml={5} />
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={() => setDateView('year')}
              style={styles.selectedDateContainer}
            >
              <Word
                text={value ?? dayjs(selected).format('YYYY')}
                font={3}
                size={25}
                color={'black'}
              />
            </TouchableOpacity>
          </View> */}
          <View style={styles.dateContainer}>
            <DateTimePicker
              ref={dateRef}
              key={selected}
              mode="single"
              navigationPosition="right"
              minDate={hidePastDates ? today : undefined}
              maxDate={hideFutureDates ? today : undefined}
              headerButtonSize={VS(20)}
              firstDayOfWeek={1}
              showOutsideDays={true}
              components={{
                IconPrev: <Img src={thin_arrow} height={22} width={22} />,
                IconNext: (
                  <Img
                    src={thin_arrow}
                    height={22}
                    width={22}
                    style={{
                      transform: [{ rotate: '180deg' }],
                    }}
                  />
                ),
              }}
              styles={{
                header: {
                  fontFamily: F.f2,
                  color: C.BLACK,
                  fontSize: MS(22),
                  paddingBottom: VS(10),
                  borderBottomWidth: 1,
                  borderColor: C.DRAG_GRAY,
                },
                selected: {
                  borderRadius: MS(10),
                  backgroundColor: C.PURPLE_BORDER,
                },
                selected_label: {
                  color: C.WHITE,
                  fontFamily: F.f2,
                },
                disabled_label: { color: C.READ_ONLY_TEXT },
                today: {
                  borderWidth: 2,
                  borderRadius: MS(10),
                  borderColor: C.PURPLE_BORDER,
                },
                today_label: {
                  color: C.PURPLE_BORDER,
                  fontFamily: F.f2,
                  fontSize: MS(20),
                },
                day_label: { fontFamily: F.f2 },
                month_label: { fontFamily: F.f2 },
                weekday_label: { fontFamily: F.f2 },
                month_selector_label: { fontFamily: F.f2 },
                year_selector_label: { fontFamily: F.f2 },
                year_label: { fontFamily: F.f2 },
                year_selector: {
                  borderWidth: 2,
                  borderColor: C.PURPLE_BORDER,
                  padding: MS(10),
                  borderRadius: MS(10),
                  marginLeft: HS(5),
                },
                month_selector: {
                  borderWidth: 2,
                  borderColor: C.PURPLE_BORDER,
                  padding: MS(10),
                  borderRadius: MS(10),
                  marginLeft: HS(5),
                },
                selected_year: {
                  borderWidth: 2,
                  borderColor: C.PURPLE_BORDER,
                  padding: MS(10),
                  borderRadius: MS(10),
                  marginLeft: HS(5),
                },
                selected_month: {
                  borderWidth: 2,
                  borderColor: C.PURPLE_BORDER,
                  padding: MS(10),
                  borderRadius: MS(10),
                  marginLeft: HS(5),
                },
              }}
              date={value ?? selected}
              onChange={({ date }) => {
                console.log('slected date', dayjs(date).format('DD-MM-YYYY'));
                setDateView('day');
                handleDateChange(date);
              }}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default DatePicker;

const styles = StyleSheet.create({
  container: {
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
    // position: 'absolute',
    zIndex: 10,
    top: 0,
    left: 0,
    backgroundColor: 'rgba(0,0,0,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  container2: {
    backgroundColor: '#fff',
    borderRadius: MS(30),
    padding: MS(20),
    alignItems: 'center',
    justifyContent: 'center',
  },
  ClostBtn: {
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
    position: 'absolute',
    zIndex: -1,
  },
  dateContainer: {
    height: SCREEN_WIDTH,
    width: SCREEN_WIDTH / 1.2,
    backgroundColor: '#fff',
    borderRadius: MS(20),
    padding: MS(20),
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedDateContainer: {
    borderWidth: 2,
    borderColor: C.PURPLE_BORDER,
    padding: MS(10),
    borderRadius: MS(10),
    marginLeft: HS(5),
  },
  selectedDate: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    alignSelf: 'flex-start',
  },
});
