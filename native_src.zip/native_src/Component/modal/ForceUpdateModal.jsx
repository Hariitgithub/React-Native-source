import { Modal, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { HS, VS } from '../../Utils/FontSize';
import { C, F } from '../../Utils/ColorFonts';

const ForceUpdateModal = ({ visible, onUpdate, forceupdatedatas = {} }) => {
  console.log('forceupdatedatas', forceupdatedatas);

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.box}>
          <Text style={styles.title} allowFontScaling={false}>
            {forceupdatedatas?.title || '-'}
          </Text>
          <Text style={styles.desc} allowFontScaling={false}>
            {forceupdatedatas?.body || '-'}
          </Text>

          <TouchableOpacity style={styles.btn} onPress={onUpdate}>
            <Text style={styles.btnText} allowFontScaling={false}>
              Update
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

export default ForceUpdateModal;

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  box: {
    width: '80%',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
  },
  title: {
    fontSize: 18,
    fontFamily: F.f2,
  },
  desc: {
    marginVertical: 12,
    fontSize: 14,
    fontFamily: F.f3,
  },
  btn: {
    backgroundColor: C.PRIMARY1,
    padding: 12,
    borderRadius: 6,
    alignItems: 'center',
    width: HS(200),
    alignSelf: 'center',
    marginTop: VS(20),
  },
  btnText: {
    color: '#fff',
    fontFamily: F.f3,
  },
});
