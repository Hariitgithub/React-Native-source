import { Modal, StyleSheet, View, TouchableOpacity, Text } from 'react-native'
import React from 'react'
import Word from '../Word/Word'
import Img from '../img/Img'
import { close_icon_16px } from '../../assets/images/imgIndex'
import { HS, MS, VS } from '../../Utils/FontSize'
import { C, F } from '../../Utils/ColorFonts'

const CommonPopup = ({ visible = false, isMixGenderContent = false, isAgeInfo = false, title = "Title", discription = "Description", onClose = () => { }, titleColor = C.PURPLE }) => {
  return (
    <Modal visible={visible} animationType="fade" transparent={true}>
      <View style={styles.overlay}>
        <View style={styles.card}>
          {/* Header Section */}
          <View style={styles.header}>
            <Word
              text={title}
              size={isAgeInfo ? 24 : 20}
              font={1}
              color={titleColor}
            />

            <TouchableOpacity
              onPress={onClose}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            >
              <Img src={close_icon_16px} height={VS(30)} width={HS(30)} />
            </TouchableOpacity>
          </View>

          {/* Divider Line */}
          <View style={styles.divider} />

          {/* Content Section */}
          <View style={styles.content}>
            {isAgeInfo ? (
              <Text
                style={{ fontSize: 14, fontFamily: F.f1, color: C.BLACK }}
                allowFontScaling={false}
              >
                Make sure you meet the{' '}
                <Text style={{ fontFamily: F.f3 }} allowFontScaling={false}>
                  minimum age requirement mentioned above
                </Text>{' '}
                and the house policies. This helps avoid last-minute
                cancellations during check-in.
              </Text>
            ) : (
              <View>
                <Word text={discription} font={1} color={C.BLACK} size={18} />

                {isMixGenderContent && (
                  <Word
                    mt={8}
                    text={
                      'Two males and one female, or two females and one male, are not allowed to stay together unless they are family.'
                    }
                    font={1}
                    color={C.BLACK}
                    size={18}
                  />
                )}
              </View>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
}

export default CommonPopup

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)', // Dimmed background
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: HS(20),
  },
  card: {
    backgroundColor: C.WHITE,
    borderRadius: MS(12),
    width: '100%',
    padding: MS(20),
    // Shadow for iOS
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    // Elevation for Android
    elevation: 5,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: VS(12),
  },
  divider: {
    height: 1,
    backgroundColor: '#E0E0E0',
    marginBottom: VS(15),
  },

})