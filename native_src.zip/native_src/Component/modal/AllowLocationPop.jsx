import {
  Linking,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import { SCREEN_HEIGHT, SCREEN_WIDTH } from '../../Utils/Constants';
import { MS, VS } from '../../Utils/FontSize';
import Img from '../img/Img';
import { Approx_map, marker } from '../../assets/images/imgIndex';
import Word from '../Word/Word';
import { F } from '../../Utils/ColorFonts';

const AllowLocationPop = ({ showPopup, setShowPop }) => {
  const openLocationSettings = async () => {
    setShowPop?.(false);
    if (Platform.OS === 'android') {
      Linking.openSettings();
    } else {
      Linking.openURL('app-settings:');
    }
  };

  const openTurnOnSettings = async () => {
    setShowPop?.(false);
    if (Platform.OS === 'android') {
      await Linking.sendIntent('android.settings.LOCATION_SOURCE_SETTINGS');
    } else {
      Linking.openURL('app-settings:');
    }
  };
  return (
    <>
      {showPopup && (
        <View style={styles.container}>
          <View style={styles.Container2}>
            <Img
              src={marker}
              height={40}
              width={40}
              resize={'contain'}
              mt={10}
            />
            <Word
              text={'Allow Maps to access this'}
              font={1}
              size={22}
              color={'black'}
              mt={20}
            />
            <Word
              text={'device’s precise location?'}
              font={1}
              size={22}
              color={'black'}
            />

            <Img
              src={Approx_map}
              height={200}
              width={200}
              resize={'contain'}
              mt={30}
            />
            <TouchableOpacity
              style={styles.btn}
              onPress={() => {
                if (showPopup === 'permission') openLocationSettings();
                else openTurnOnSettings();
              }}
            >
              <Text style={styles.text} allowFontScaling={false}>
                {showPopup === 'permission' ? 'Allow' : 'Turn on Location'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </>
  );
};

export default AllowLocationPop;

const styles = StyleSheet.create({
  container: {
    height: SCREEN_HEIGHT,
    width: SCREEN_WIDTH,
    position: 'absolute',
    zIndex: 100,
    top: 0,
    left: 0,
    backgroundColor: 'rgba(0,0,0,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  Container2: {
    height: SCREEN_WIDTH,
    width: SCREEN_WIDTH / 1.2,
    backgroundColor: '#fff',
    borderRadius: '10%',
    alignItems: 'center',
    padding: MS(20),
  },
  btn: {
    width: '90%',
    height: VS(80),
    backgroundColor: '#D2E4FC',
    marginTop: VS(30),
    borderRadius: MS(100),
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: { fontFamily: F.f1, fontSize: MS(22), color: '#000' },
});
