import { Alert, Linking, Platform } from 'react-native';

export const showSettingsAlert = name => {
  Alert.alert(
    'Permission Required',
    `${name} access is blocked. Please enable it in settings.`,
    [
      {
        text: 'Cancel',
        style: 'cancel',
      },
      {
        text: 'Open Settings',
        onPress: () => {
          if (Platform.OS === 'android') {
            Linking.openSettings(); // Equivalent to: Intent to your app's settings
          } else {
            Linking.openURL('app-settings:'); // iOS
          }
        },
      },
    ],
    { cancelable: true },
  );
};
