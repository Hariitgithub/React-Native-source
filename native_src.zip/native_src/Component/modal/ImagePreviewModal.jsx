import React from 'react';
import {
    Modal,
    View,
    TouchableOpacity,
    StyleSheet,
    Dimensions,
    Image,
    Text,
} from 'react-native';
import ImageZoom from 'react-native-image-pan-zoom';
import Word from '../Word/Word';
import Img from '../img/Img';
import { HS, MS, VS } from '../../Utils/FontSize';

const { width, height } = Dimensions.get('window');

const ImagePreviewModal = ({
    visible,
    image,
    onClose,
}) => {
    return (
        <Modal
            visible={visible}
            transparent
            animationType="fade"
            statusBarTranslucent
            onRequestClose={onClose}
        >
            <View style={styles.container}>
                <TouchableOpacity
                    style={styles.closeButton}
                    activeOpacity={0.8}
                    onPress={onClose}
                >
                    <Word text={'✕'} style={styles.closeText} />
                </TouchableOpacity>

                <ImageZoom
                    cropWidth={width}
                    cropHeight={height}
                    imageWidth={width}
                    imageHeight={height * 0.8}
                    enableCenterFocus
                >
                    <Img
                        src={{ uri: image }}
                        style={styles.image}
                        resize="contain"
                    />
                </ImageZoom>
            </View>
        </Modal>
    );
};

export default ImagePreviewModal;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.95)',
        justifyContent: 'center',
        alignItems: 'center',
    },

    image: {
        width: width,
        height: height * 0.8,
    },

    closeButton: {
        position: 'absolute',
        top: VS(50),
        right: HS(20),
        zIndex: 100,
        width: HS(42),
        height: VS(42),
        borderRadius: MS(21),
        backgroundColor: 'rgba(255,255,255,0.2)',
        justifyContent: 'center',
        alignItems: 'center',
    },

    closeText: {
        color: '#fff',
        fontSize: MS(22),
    },
});