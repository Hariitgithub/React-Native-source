import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Modal,
  Platform,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { HS, MS, VS } from '../../Utils/FontSize';
import { C, F } from '../../Utils/ColorFonts';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

const AlertModel = ({
  show = false,
  msg = '',
  onClose,
  btn_text = 'Close',
  navi = null,
}) => {
  const dispatch = useDispatch();

  const handleClose = () => {
    if (typeof onClose === 'function') {
      onClose();
    }
  };

  return (
    <Modal visible={show} transparent={true} animationType="fade">
      <View style={styles.alertTlBox}>
        <View style={styles.alertBoxInner}>
          {msg ? (
            <Text style={styles.msgText} allowFontScaling={false}>
              {msg}
            </Text>
          ) : (
            <Text style={styles.msgText} allowFontScaling={false}>
              Please confirm this action.
            </Text>
          )}
          <TouchableOpacity style={styles.closeBtn} onPress={handleClose}>
            <Text style={styles.closeText} allowFontScaling={false}>
              {btn_text}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  alertTlBox: {
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: 'rgba(0,0,0,0.3)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 11111111,
  },
  alertBoxInner: {
    width: '75%',
    padding: 20,
    minHeight: VS(200),
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeBtn: {
    width: HS(150),
    height: VS(50),
    backgroundColor: C.PRIMARY,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15,
  },
  closeText: {
    fontFamily: F.f2,
    color: C.WHITE,
    fontSize: MS(24),
  },
  msgText: {
    fontFamily: F.f3,
    lineHeight: VS(27),
    color: '#000',
    fontSize: MS(18),
    textAlign: 'center',
  },
});

export default AlertModel;
