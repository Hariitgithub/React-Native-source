import {
  Modal,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import Word from '../Word/Word';
import { HS, MS, VS } from '../../Utils/FontSize';
import { C, F } from '../../Utils/ColorFonts';
import Loader from '../Loaders/Loader';

const LogoutModal = ({
  visible,
  onClose,
  title,
  title_2,
  title_3,
  OnPressYes,
  loader,
  isClosePop,
  input,
  setReason,
  error,
}) => {
  return (
    <Modal
      visible={visible}
      onRequestClose={() => onClose?.(false)}
      transparent={true}
    >
      <View style={styles.container}>
        <View style={styles.viewBox}>
          {title && (
            <Word
              text={title}
              size={20}
              font={3}
              color={'#000'}
              tc={'center'}
              width={200}
              align={'center'}
            />
          )}
          {title_2 && (
            <Word
              text={title_2}
              size={14}
              font={1}
              color={'#000'}
              tc={'center'}
              mt={10}
              width={250}
              align={'center'}
            />
          )}
          {title_3 && (
            <Word
              text={title_3}
              size={14}
              font={4}
              color={'#000'}
              tc={'center'}
              mt={10}
              width={250}
              align={'center'}
            />
          )}

          {input && (
            <>
              <TextInput
                style={[
                  styles.reasonInput,
                  error ? { borderColor: 'red' } : null,
                ]}
                placeholder="Enter reason..."
                placeholderTextColor={'#999'}
                multiline
                onChangeText={text => setReason?.(text)}
                allowFontScaling={false}
              />
              {!!error && (
                <Text style={styles.errorText} allowFontScaling={false}>
                  {error}
                </Text>
              )}
            </>
          )}

          <View style={styles.btnRow}>
            {!isClosePop && (
              <TouchableOpacity
                style={styles.btn}
                onPress={() => onClose?.(false)}
              >
                <Word
                  text={'No'}
                  size={18}
                  font={2}
                  color={C.BLACK}
                  tc={'center'}
                />
              </TouchableOpacity>
            )}
            <TouchableOpacity
              style={[styles.btn, { backgroundColor: C.WHITE }]}
              onPress={() => {
                if (!loader) {
                  OnPressYes?.();
                }
              }}
            >
              {loader ? (
                <Loader color={C.PRIMARY1} />
              ) : (
                <Word
                  text={isClosePop ? 'Close' : 'Yes'}
                  size={18}
                  font={2}
                  color={C.PRIMARY1}
                  tc={'center'}
                />
              )}
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default LogoutModal;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.2)',
    paddingHorizontal: HS(20),
  },
  viewBox: {
    width: '98%',
    backgroundColor: C.WHITE,
    elevation: 3,
    shadowColor: C.BLACK,
    shadowOffset: { width: HS(0), height: VS(4) },
    shadowOpacity: 0.24,
    padding: MS(40),
    alignItems: 'center',
    borderRadius: MS(50),
  },
  btn: {
    width: '40%',
    height: VS(55),
    borderWidth: 1,
    borderColor: C.PRIMARY1,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: MS(15),
    backgroundColor: C.PRIMARY1,
  },
  btnRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: MS(20),
    marginTop: VS(25),
  },
  reasonInput: {
    width: '100%',
    minHeight: VS(100),
    borderWidth: 1,
    borderColor: C.PRIMARY1,
    borderRadius: MS(15),
    padding: MS(15),
    marginTop: VS(20),
    fontFamily: F.f1,
    fontSize: MS(20),
    color: '#000',
    textAlignVertical: 'top',
  },
  errorText: {
    color: 'red',
    fontSize: MS(18),
    fontFamily: F.f1,
    alignSelf: 'flex-start',
    marginTop: VS(6),
  },
});
