import React, {
  useState,
  useRef,
  useEffect,
  useMemo,
  useCallback,
  cache,
} from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  FlatList,
  ScrollView,
  DeviceEventEmitter,
  ActivityIndicator,
  InteractionManager,
} from 'react-native';
import moment from 'moment';
import Img from '../img/Img';
import { PopUP_Absent_Icon } from '../../assets/images/imgIndex';
import { C, F } from '../../Utils/ColorFonts';
import { post } from '../../Redux/apiRequest/ApiHandler';
import { URLS } from '../../Redux/apiRequest/Constant';
import { SCREEN_HEIGHT } from '../../Utils/Constants';
import { useDispatch } from 'react-redux';
import { resetFirstView } from '../../Redux/Slice/checkIn';
import notifee from '@notifee/react-native';

const PURPLE = '#7C5CBF';
const HOURS = [
  '01',
  '02',
  '03',
  '04',
  '05',
  '06',
  '07',
  '08',
  '09',
  '10',
  '11',
  '12',
];
const MINUTES = [
  '00',
  '05',
  '10',
  '15',
  '20',
  '25',
  '30',
  '35',
  '40',
  '45',
  '50',
  '55',
];
const PERIODS = ['AM', 'PM'];
const ITEM_HEIGHT = 44;
const VISIBLE_ITEMS = 3;

const normalise = (d = {}) => {
  const safe = d ?? {};
  return {
    startDate: safe.startDate ?? safe.start_date ?? null,
    endDate: safe.endDate ?? safe.end_date ?? null,
    startTime: safe.startTime ?? safe.start_time ?? null,
    endTime: safe.endTime ?? safe.end_time ?? null,
    propertyName: safe.propertyName ?? safe.property_name ?? '—',
    bookingCode: safe.bookingCode ?? safe.booking_code ?? null,
  };
};

// ── toMins helper ─────────────────────────────────────────────────────────
const toMinsHelper = (h, m, p) => {
  if (!h || !m || !p) return 0;
  let hrs = parseInt(h, 10);
  if (isNaN(hrs)) return 0;
  if (p === 'PM' && hrs !== 12) hrs += 12;
  if (p === 'AM' && hrs === 12) hrs = 0;
  const mins = parseInt(m, 10);
  return hrs * 60 + (isNaN(mins) ? 0 : mins);
};

const getCurrentRoundedTime = () => {
  const now = moment();
  if (!now.isValid()) {
    return { hour: '12', minute: '00', period: 'PM', total: 12 * 60 };
  }
  let hour = now.hour();
  let minute = now.minute();

  minute = Math.ceil(minute / 5) * 5;

  if (minute === 60) {
    minute = 0;
    hour += 1;
  }

  if (hour === 24) {
    hour = 0;
  }

  const period = hour >= 12 ? 'PM' : 'AM';

  let displayHour = hour % 12;
  if (displayHour === 0) displayHour = 12;

  return {
    hour: String(displayHour).padStart(2, '0'),
    minute: String(minute).padStart(2, '0'),
    period,
  };
};

const parseFixed24h = timeStr => {
  if (!timeStr || typeof timeStr !== 'string') return getCurrentRoundedTime();
  const parsed = moment(timeStr, 'HH:mm', true);
  if (!parsed.isValid()) return getCurrentRoundedTime();
  const h = parsed.hours();
  const m = parsed.minutes();
  const period = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return {
    hour: String(hour12).padStart(2, '0'),
    minute: String(m).padStart(2, '0'),
    period,
  };
};

const toISOString = (sDate, h, m, p) => {
  if (!sDate || !h || !m || !p) return null;
  let hours = parseInt(h, 10);
  const mins = parseInt(m, 10);
  if (isNaN(hours) || isNaN(mins)) return null;
  if (p === 'AM' && hours === 12) hours = 0;
  else if (p === 'PM' && hours !== 12) hours += 12;
  const date = moment(sDate, ['YYYY-MM-DD', 'DD-MM-YYYY'], true);
  if (!date.isValid()) return null;
  date.set({ hour: hours, minute: mins, second: 0, millisecond: 0 });
  return date.utc().toISOString();
};

function ScrollColumn({ data, value, onChange, ready }) {
  const flatRef = useRef(null);

  const SPACER = '__spacer__';

  // ── add spacers so first/last can reach CENTER
  const paddedData = useMemo(() => {
    return [SPACER, ...data, SPACER];
  }, [data]);

  // ── normalize index (+1 because of top spacer)
  const index = useMemo(() => {
    const v = String(value).padStart(2, '0');
    const rawIndex = data.indexOf(v);
    return rawIndex >= 0 ? rawIndex + 1 : 1;
  }, [data, value]);

  // ── scroll to CENTER (IMPORTANT FIX)
  useEffect(() => {
    if (!ready || index < 0) return;

    const task = InteractionManager.runAfterInteractions(() => {
      requestAnimationFrame(() => {
        flatRef.current?.scrollToOffset({
          offset: index * ITEM_HEIGHT - ITEM_HEIGHT, // 🔥 CENTER ALIGNMENT FIX
          animated: false,
        });
      });
    });

    return () => task.cancel();
  }, [ready, index]);

  // ── detect selected item correctly
  const onMomentumEnd = useCallback(
    e => {
      const y = e.nativeEvent.contentOffset.y;

      // convert scroll position → centered index
      const centerIndex = Math.round((y + ITEM_HEIGHT) / ITEM_HEIGHT);

      const realIndex = centerIndex - 1;

      const clamped = Math.max(0, Math.min(realIndex, data.length - 1));

      onChange(data[clamped]);
    },
    [data, onChange],
  );

  return (
    <View style={{ flex: 1, height: ITEM_HEIGHT * 3 }}>
      {/* center highlight */}
      <View
        pointerEvents="none"
        style={{
          position: 'absolute',
          top: ITEM_HEIGHT,
          left: 0,
          right: 0,
          height: ITEM_HEIGHT,
          backgroundColor: '#F0EBF8',
          borderRadius: 8,
          zIndex: 0,
        }}
      />

      <FlatList
        ref={flatRef}
        data={paddedData}
        keyExtractor={(item, index) => item + index}
        showsVerticalScrollIndicator={false}
        snapToInterval={ITEM_HEIGHT}
        decelerationRate="fast"
        getItemLayout={(_, index) => ({
          length: ITEM_HEIGHT,
          offset: ITEM_HEIGHT * index,
          index,
        })}
        onMomentumScrollEnd={onMomentumEnd}
        windowSize={5}
        maxToRenderPerBatch={10}
        initialNumToRender={10}
        renderItem={({ item }) => {
          if (item === SPACER) {
            return <View style={{ height: ITEM_HEIGHT }} />;
          }

          const isActive = item === value;

          return (
            <View
              style={{
                height: ITEM_HEIGHT,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Text
                style={{
                  fontSize: isActive ? 20 : 18,
                  color: isActive ? '#7C5CBF' : '#BBBBBB',
                }}
              >
                {item}
              </Text>
            </View>
          );
        }}
      />
    </View>
  );
}

const col = StyleSheet.create({
  wrapper: {
    flex: 1,
    height: ITEM_HEIGHT * VISIBLE_ITEMS,
    overflow: 'hidden',
    position: 'relative',
  },
  highlight: {
    position: 'absolute',
    top: ITEM_HEIGHT,
    left: 0,
    right: 0,
    height: ITEM_HEIGHT,
    backgroundColor: '#F0EBF8',
    borderRadius: 8,
    zIndex: 0,
  },
  item: { height: ITEM_HEIGHT, alignItems: 'center', justifyContent: 'center' },
  itemText: { fontSize: 18, color: '#BBBBBB', fontFamily: F.f4 },
  itemTextActive: { fontSize: 20, color: PURPLE, fontFamily: F.f2 },
});

function TimePicker({
  hour,
  minute,
  period,
  onHourChange,
  onMinuteChange,
  onPeriodChange,
  ready,
}) {
  return (
    <View style={tp.container}>
      <ScrollColumn
        data={HOURS}
        value={hour}
        onChange={onHourChange}
        ready={ready}
      />
      <Text style={tp.separator}>:</Text>
      <ScrollColumn
        data={MINUTES}
        value={minute}
        onChange={onMinuteChange}
        ready={ready}
      />
      <ScrollColumn
        data={PERIODS}
        value={period}
        onChange={onPeriodChange}
        ready={ready}
      />
    </View>
  );
}

const tp = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    gap: 4,
    marginVertical: 8,
  },
  separator: { fontSize: 22, fontFamily: F.f2, color: PURPLE, marginBottom: 2 },
});

// ── Main Modal ─────────────────────────────────────────────────────────────
export default function CheckInModal({
  visible,
  onYesComing,
  onCancelBooking,
  visibleData = {},
  navigation,
  setVisibles,
}) {
  // ✅ Single normalised data object — used everywhere below
  const data = useMemo(() => normalise(visibleData), [visibleData]);

  const startParsed = useMemo(
    () => parseFixed24h(data.startTime),
    [data.startTime],
  );
  const endParsed = useMemo(() => parseFixed24h(data.endTime), [data.endTime]);

  const initTime = getCurrentRoundedTime();

  const [step, setStep] = useState('checkin');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState('');
  const [hour, setHour] = useState(initTime.hour);
  const [minute, setMinute] = useState(initTime.minute);
  const [period, setPeriod] = useState(initTime.period);
  const [pickerReady, setPickerReady] = useState(false);

  // ── Date options — uses normalised startDate / endDate ──────────────────
  const buildDateOptions = useCallback(() => {
    if (!data.startDate || !data.endDate) return [];
    const start = moment(data.startDate, 'YYYY-MM-DD', true);
    const end = moment(data.endDate, 'YYYY-MM-DD', true);
    if (!start.isValid() || !end.isValid()) return [];
    const dates = [];
    const cursor = start.clone();
    while (cursor.isSameOrBefore(end, 'day')) {
      dates.push(cursor.format('YYYY-MM-DD'));
      cursor.add(1, 'day');
    }
    return dates;
  }, [data.startDate, data.endDate]);

  const dateOptions = useMemo(() => buildDateOptions(), [buildDateOptions]);
  const isMultiDate = dateOptions.length > 1;

  const [selectedDate, setSelectedDate] = useState(data.startDate ?? null);

  useEffect(() => {
    const options = buildDateOptions();
    if (options.length > 0) setSelectedDate(options[0]);
  }, [data.startDate, data.endDate]);

  // Auto-advance timer
  useEffect(() => {
    const interval = setInterval(() => {
      InteractionManager.runAfterInteractions(() => {
        const next = getCurrentRoundedTime();
        if (toMinsHelper(hour, minute, period) < next.total) {
          setHour(next.hour);
          setMinute(next.minute);
          setPeriod(next.period);
        }
      });
    }, 10000);
    return () => clearInterval(interval);
  }, [hour, minute, period]);

  // Reset on modal open
  useEffect(() => {
    if (visible) {
      const t = getCurrentRoundedTime();
      setStep('checkin');
      setReason('');
      setApiError('');
      setLoading(false);
      setPickerReady(false);
      setHour(t.hour);
      setMinute(t.minute);
      setPeriod(t.period);
      const options = buildDateOptions();
      if (options.length > 0) setSelectedDate(options[0]);
    }
  }, [visible]);

  // Picker ready after step transition
  useEffect(() => {
    if (step === 'arriving') {
      setPickerReady(false);
      const task = InteractionManager.runAfterInteractions(() =>
        setPickerReady(true),
      );
      return () => task.cancel();
    } else {
      setPickerReady(false);
    }
  }, [step]);

  useEffect(() => {
    const listener = DeviceEventEmitter.addListener(
      'BOOKING_ABSENT_NOTIFICATION',
      () => {
        onYesComing?.();
      },
    );
    return () => listener.remove();
  }, [onYesComing]);

  // ── formatDateLabel ──────────────────────────────────────────────────────
  const formatDateLabel = useCallback(iso => {
    if (!iso) return '';
    const d = moment(iso, 'YYYY-MM-DD', true);
    return d.isValid() ? d.format('MMM D, YYYY') : iso;
  }, []);

  // ── Validation — uses normalised startDate / endDate ────────────────────
  const selectedIsStartDate = selectedDate === data.startDate;
  const selectedIsEndDate = selectedDate === data.endDate;

  const isUnderMin = useCallback(() => {
    if (!selectedIsStartDate) return false;
    return (
      toMinsHelper(hour, minute, period) <
      toMinsHelper(startParsed.hour, startParsed.minute, startParsed.period)
    );
  }, [hour, minute, period, selectedIsStartDate, startParsed]);

  const isOverMax = useCallback(() => {
    if (!selectedIsEndDate) return false;
    return (
      toMinsHelper(hour, minute, period) >
      toMinsHelper(endParsed.hour, endParsed.minute, endParsed.period)
    );
  }, [hour, minute, period, selectedIsEndDate, endParsed]);

  const isTimeInvalid = useCallback(
    () => isUnderMin() || isOverMax(),
    [isUnderMin, isOverMax],
  );

  // ── getWarningText ───────────────────────────────────────────────────────
  const getWarningText = useCallback(() => {
    if (!selectedDate) return null;
    const now = moment();
    if (!now.isValid()) return null;
    const todayISO = now.format('YYYY-MM-DD');
    if (selectedDate === todayISO) {
      const currentTotalMins = now.hours() * 60 + now.minutes();
      if (toMinsHelper(hour, minute, period) < currentTotalMins)
        return 'Arrival time cannot be in the past';
    }
    if (isUnderMin())
      return `Earliest: ${startParsed.hour}:${startParsed.minute} ${startParsed.period}`;
    if (isOverMax())
      return `Latest: ${endParsed.hour}:${endParsed.minute} ${endParsed.period}`;
    return null;
  }, [
    selectedDate,
    hour,
    minute,
    period,
    isUnderMin,
    isOverMax,
    startParsed,
    endParsed,
  ]);

  // ── API: Confirm Arrival ──────────────────────────────────────────────────
  const calendarChoose = async () => {
    if (loading) return;
    setLoading(true);
    setApiError('');
    try {
      const isoDateTime = toISOString(selectedDate, hour, minute, period);
      if (!isoDateTime) {
        setApiError('Invalid date selected. Please try again.');
        return;
      }
      const payload = {
        booking_code: data.bookingCode,
        new_arrival_date_time: isoDateTime,
      };
      const res = await post(URLS.ABSENT_UNDERMIN, payload);
      if (res?.status === 'success') {
        setStep('confirmed');
      } else {
        // setApiError(res?.message || 'Something went wrong. Please try again.');
      }
    } catch (err) {
      console.log('calendarChoose ERROR', err);
      setApiError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // ── API: Cancel Booking ───────────────────────────────────────────────────
  const canceledBooking = async () => {
    if (loading) return;
    if (!reason.trim()) {
      setApiError('Reason is mandatory.');
      return;
    }
    setLoading(true);
    setApiError('');
    try {
      const res = await post(URLS.CANCEL_BOOKING, {
        booking_code: data.bookingCode,
        reason: reason.trim(),
      });
      if (res?.status === 'success') {
        setStep('cancelled');
      } else {
        // setApiError(res?.message || 'Something went wrong. Please try again.');
      }
    } catch (err) {
      console.log('canceledBooking ERROR', err);
      setApiError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  const dispatch = useDispatch();
  const reset = useCallback(() => {
    const t = getCurrentRoundedTime();
    setStep('checkin');
    setReason('');
    setApiError('');
    setLoading(false);
    setPickerReady(false);
    setSelectedDate(dateOptions[0] ?? data.startDate ?? null);
    setHour(t.hour);
    setMinute(t.minute);
    setPeriod(t.period);
  }, [dateOptions, data.startDate]);

  const handleGotItArrival = useCallback(() => {
    const snapDate = selectedDate;
    const snapHour = hour;
    const snapMinute = minute;
    const snapPeriod = period;
    reset();

    onYesComing?.({
      date: snapDate,
      time: `${snapHour}:${snapMinute} ${snapPeriod}`,
    });
    navigation.navigate('Booking', {
      selected: { name: 'Upcoming', color: C.PURPLE_BORDER },
    });
  }, [selectedDate, hour, minute, period, reset, onYesComing, navigation]);

  const handleGotItCancelled = useCallback(() => {
    const capturedReason = reason;
    reset();
    onCancelBooking?.(capturedReason);
    navigation.navigate('Booking', {
      selected: { name: 'Cancelled', color: C.RED },
    });
  }, [reason, reset, onCancelBooking, navigation]);

  const warningText = getWarningText();
  const handlerReset = async () => {
    try {
      await notifee.cancelAllNotifications();
      setVisibles();
      await notifee.cancelDisplayedNotifications();
      dispatch(resetFirstView());
      let payload = {
        booking_id: visibleData?.bookingId || visibleData?.booking_id,
        user_type: 'user',
      };
      const res = await post(URLS.OWNER_SEEN_RESPONSE, payload);
      console.log('SDASLDLASD', res);

      if (res?.status == 'success') {
        console.log('CLose');
      }
    } catch (err) {
      console.log('EERORCheckIN', err);
    }
  };

  useEffect(() => {
    if (step !== 'checkin') {
      console.log('step', step);

      return;
    }
    if (step === 'checkin' && visible) {
      const timer = setTimeout(() => {
        console.log('step222', step);

        if (step === 'checkin' && visible) {
          setVisibles();
        }
      }, 30000);

      return () => clearTimeout(timer);
    }
  }, [step, visible]);
  // ── formattedStartDate — uses normalised startDate ───────────────────────
  const formattedStartDate = useMemo(() => {
    if (!data.startDate) return '—';
    const d = moment(data.startDate, 'YYYY-MM-DD', true);
    return d.isValid() ? d.format('DD-MM-YYYY') : data.startDate;
  }, [data.startDate]);

  console.log('SKADKSAKA', data, visibleData);

  return (
    <Modal
      transparent
      animationType="fade"
      visible={visible}
      statusBarTranslucent
    >
      <KeyboardAvoidingView
        style={styles.overlay}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View style={[styles.card, { position: 'relative' }]}>
          <TouchableOpacity
            onPress={async () => {
              handlerReset();
            }}
            style={{
              position: 'absolute',
              top: 10,
              right: 10,
              borderWidth: 1,
              borderRadius: 90,
              padding: 0,
              paddingRight: 3,
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
              height: 25,
              width: 25,
            }}
          >
            <Text> X</Text>
          </TouchableOpacity>

          {/* STEP 1 — Initial Prompt */}
          {step === 'checkin' && (
            <>
              <Img src={PopUP_Absent_Icon} width={74} height={74} mb={5} />
              <Text style={styles.title}>
                Are you still planning to check-in?
              </Text>
              <Text style={styles.body}>
                Your reservation at{' '}
                <Text style={styles.bold}>{data.propertyName}</Text> was
                scheduled for{' '}
                <Text style={styles.bold}>{formattedStartDate}</Text>. Booking
                Code:{' '}
                <Text style={[styles.bold, { color: C.PURPLE }]}>
                  {visibleData?.bookingCode || visibleData?.booking_code}
                </Text>
              </Text>
              <View style={styles.actions}>
                <TouchableOpacity
                  style={styles.cancelBtn}
                  onPress={() => setStep('cancel')}
                >
                  <Text style={styles.cancelText}>Cancel Booking</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.confirmBtn}
                  onPress={() => setStep('arriving')}
                >
                  <Text style={styles.confirmText}>Yes, I'm Coming</Text>
                </TouchableOpacity>
              </View>
            </>
          )}

          {/* STEP 2 — Arrival Selection */}
          {step === 'arriving' && (
            <>
              <Text style={styles.title}>When will you arrive?</Text>

              {!isMultiDate ? (
                <View style={[styles.datePill, styles.datePillSelected]}>
                  <Text
                    style={[styles.datePillText, styles.datePillTextSelected]}
                  >
                    {formatDateLabel(selectedDate)}
                  </Text>
                </View>
              ) : (
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.dateSelectorRow}
                >
                  {dateOptions.map(d => (
                    <TouchableOpacity
                      key={d}
                      style={[
                        styles.datePill,
                        styles.datePillSelectable,
                        selectedDate === d && styles.datePillSelected,
                      ]}
                      onPress={() => setSelectedDate(d)}
                    >
                      <Text
                        style={[
                          styles.datePillText,
                          selectedDate === d && styles.datePillTextSelected,
                        ]}
                      >
                        {formatDateLabel(d)}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              )}

              <TimePicker
                hour={hour}
                minute={minute}
                period={period}
                onHourChange={setHour}
                onMinuteChange={setMinute}
                onPeriodChange={setPeriod}
                ready={pickerReady}
              />

              {warningText ? (
                <Text style={styles.timeWarning}>{warningText}</Text>
              ) : null}
              {apiError ? (
                <Text style={styles.timeWarning}>{apiError}</Text>
              ) : null}

              <View style={[styles.actions, { marginTop: 16 }]}>
                <TouchableOpacity
                  style={styles.cancelBtn}
                  onPress={() => setStep('checkin')}
                  disabled={loading}
                >
                  <Text style={styles.cancelText}>Back</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.confirmBtn,
                    (isTimeInvalid() || loading) && styles.confirmBtnDisabled,
                  ]}
                  disabled={isTimeInvalid() || loading}
                  onPress={calendarChoose}
                >
                  {loading ? (
                    <ActivityIndicator color="#fff" size="small" />
                  ) : (
                    <Text style={styles.confirmText}>Confirm</Text>
                  )}
                </TouchableOpacity>
              </View>
            </>
          )}

          {/* STEP 3 — Confirmed */}
          {step === 'confirmed' && (
            <>
              <Text style={styles.title}>Confirmed! Your room is ready</Text>
              <Text style={styles.body}>
                Arrival set for{' '}
                <Text style={styles.bold}>{formatDateLabel(selectedDate)}</Text>{' '}
                at{' '}
                <Text style={styles.bold}>
                  {hour}:{minute} {period}
                </Text>
                .
              </Text>
              <TouchableOpacity
                style={styles.gotItBtn}
                onPress={handleGotItArrival}
              >
                <Text style={styles.gotItText}>Got It</Text>
              </TouchableOpacity>
            </>
          )}

          {/* STEP 4 — Cancel Reason */}
          {step === 'cancel' && (
            <>
              <Text style={styles.title}>Reason for cancellation</Text>
              <TextInput
                style={styles.input}
                placeholder="e.g. Flight Delayed"
                placeholderTextColor="#AAAAAA"
                value={reason}
                onChangeText={text => {
                  setReason(text);
                  if (apiError) setApiError('');
                }}
                autoFocus
              />
              {apiError ? (
                <Text style={styles.timeWarning}>{apiError}</Text>
              ) : null}
              <View style={styles.actions}>
                <TouchableOpacity
                  style={styles.goBackBtn}
                  onPress={() => {
                    setApiError('');
                    setStep('checkin');
                  }}
                  disabled={loading}
                >
                  <Text style={styles.goBackText}>Go Back</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.confirmCancelBtn, loading && { opacity: 0.6 }]}
                  onPress={canceledBooking}
                  disabled={loading}
                >
                  {loading ? (
                    <ActivityIndicator color="#D94F3D" size="small" />
                  ) : (
                    <Text style={styles.confirmCancelText}>
                      Confirm Cancellation
                    </Text>
                  )}
                </TouchableOpacity>
              </View>
            </>
          )}

          {/* STEP 5 — Cancelled */}
          {step === 'cancelled' && (
            <>
              <Text style={styles.title}>Booking cancelled</Text>
              <Text style={styles.body}>
                Your reservation has been successfully cancelled.
              </Text>
              <TouchableOpacity
                style={styles.gotItBtn}
                onPress={handleGotItCancelled}
              >
                <Text style={styles.gotItText}>Got It</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
    height: SCREEN_HEIGHT,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 340,
    alignItems: 'center',
  },
  title: {
    fontSize: 14,
    fontFamily: F.f2,
    color: '#1A1A1A',
    textAlign: 'center',
    marginBottom: 12,
  },
  body: {
    fontSize: 14,
    color: '#555555',
    textAlign: 'center',
    fontFamily: F.f4,
    marginBottom: 24,
  },
  bold: { fontFamily: F.f2, color: '#333333' },
  datePill: {
    backgroundColor: '#EFEFEF',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginBottom: 8,
    alignSelf: 'stretch',
    alignItems: 'center',
  },
  datePillText: { fontSize: 15, fontFamily: F.f3, color: '#888888' },
  dateSelectorRow: {
    flexDirection: 'row',
    gap: 8,
    paddingVertical: 4,
    marginBottom: 8,
  },
  datePillSelectable: { alignSelf: 'auto', marginBottom: 0 },
  datePillSelected: { backgroundColor: PURPLE },
  datePillTextSelected: { color: '#FFFFFF' },
  timeWarning: {
    fontSize: 12,
    color: '#D94F3D',
    fontFamily: F.f4,
    marginTop: 4,
    marginBottom: 8,
    textAlign: 'center',
  },
  actions: { flexDirection: 'row', gap: 10, width: '100%' },
  cancelBtn: {
    flex: 1,
    paddingVertical: 13,
    borderRadius: 12,
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  cancelText: { fontSize: 14, fontFamily: F.f4, color: '#444444' },
  confirmBtn: {
    flex: 1,
    paddingVertical: 13,
    borderRadius: 12,
    alignItems: 'center',
    backgroundColor: PURPLE,
  },
  confirmBtnDisabled: { backgroundColor: '#C4B5E0' },
  confirmText: { fontSize: 14, fontFamily: F.f4, color: '#FFFFFF' },
  gotItBtn: {
    width: '100%',
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  gotItText: { fontSize: 15, fontFamily: F.f4, color: '#1A1A1A' },
  input: {
    width: '100%',
    borderBottomWidth: 1,
    borderBottomColor: '#DDDDDD',
    paddingVertical: 8,
    marginBottom: 8,
    fontFamily: F.f4,
    color: '#1A1A1A',
  },
  goBackBtn: { paddingVertical: 13, paddingHorizontal: 16 },
  goBackText: { fontSize: 15, fontFamily: F.f4, color: '#444444' },
  confirmCancelBtn: {
    flex: 1,
    paddingVertical: 13,
    borderRadius: 12,
    alignItems: 'center',
    backgroundColor: '#FDECEA',
  },
  confirmCancelText: { fontSize: 14, fontFamily: F.f4, color: '#D94F3D' },
});
