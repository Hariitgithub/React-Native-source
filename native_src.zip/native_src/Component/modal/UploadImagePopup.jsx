import React from 'react';
import { View, StyleSheet, TouchableOpacity, Modal } from 'react-native';
// import ImagePicker from 'react-native-image-crop-picker';
import Word from '../Word/Word';
import { C } from '../../Utils/ColorFonts';
import { HS, MS, VS } from '../../Utils/FontSize';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import { Toast } from '../../Utils/Constants';
import { requestCameraPermission } from '../Permissions/CameraPermission';
import { showSettingsAlert } from './DefaultAlert';
// import { requestImagePermission } from '../Permissions/ImagePermission';

const UploadImagePopup = ({
  visible,
  setImagePopup,
  onSelect,
  width,
  height,
  multiple,
  cropping,
  isVideo,
  Imagelimit,
}) => {
  const imageHandler = async type => {
    // setImagePopup?.(false);
    // the app that pics images only once use below
    if (type === 'camera') {
      // const cameraPermission = await requestCameraPermission();
      // if (!cameraPermission) {
      //   showSettingsAlert('camera');
      //   return;
      // }
      launchCamera(
        {
          mediaType: isVideo ? 'video' : 'photo',
          maxWidth: width ?? 300,
          maxHeight: height ?? 400,
          includeBase64: false,
          saveToPhotos: true,
          quality: 1,
        },
        ({ assets, didCancel }) => {
          if (didCancel) {
            setImagePopup?.(false);
            return;
          }
          let image = assets?.[0];
          console.log('camera', image);
          onSelect?.({
            uri: image.uri,
            type: image.type,
            name: image.fileName,
          });
          setImagePopup?.(false);
        },
      ).catch(err => {
        console.log(err);
      });
    } else {
      launchImageLibrary(
        {
          mediaType: isVideo ? 'video' : 'photo',
          maxWidth: width ?? 300,
          maxHeight: height ?? 400,
          selectionLimit: multiple ? Imagelimit ?? 1 : 5,
        },
        ({ assets, didCancel }) => {
          if (didCancel) {
            setImagePopup?.(false);
            return;
          }
          let images = assets?.map(image => ({
            uri: image.uri,
            type: image.type,
            name: image.fileName,
          }));
          console.log('gallery', assets);
          onSelect?.(multiple ? images : images?.[0]);
          setImagePopup?.(false);
        },
      ).catch(err => {
        console.log(err);
      });
    }

    // if the app that using images frequently  use below

    // if (type === 'camera') {
    //   const cameraPermission = await requestCameraPermission();
    //   if (!cameraPermission) {
    //     showSettingsAlert('camera');
    //     return;
    //   }
    //   ImagePicker.openCamera({
    //     width: width ?? 300,
    //     height: height ?? 400,
    //     cropping: cropping ?? true,
    //     multiple: multiple ?? false,
    //   })
    //     .then(image => {
    //       console.log('camera', image);
    //       onSelect?.({
    //         uri: image.path,
    //         type: image.mime,
    //         name: image.filename,
    //       });
    //       setImagePopup?.(false);
    //     })
    //     .catch(err => console.log('error while opening camera', err));
    // } else {
    //   const filePermission = await requestImagePermission();
    //   if (!filePermission) {
    //     showSettingsAlert('File ');
    //     return;
    //   }
    //   ImagePicker.openPicker({
    //     width: width ?? 300,
    //     height: height ?? 400,
    //     cropping: cropping ?? true,
    //     multiple: multiple ?? false,
    //   })
    //     .then(image => {
    //       console.log('gallery', image);
    //       onSelect?.({
    //         uri: image.path,
    //         type: image.mime,
    //         name: image.filename,
    //       });
    //       setImagePopup?.(false);
    //     })
    //     .catch(err => console.log('error while opening gallery', err));
    // }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setImagePopup?.(false)}
    >
      <View style={styles.modalContainer}>
        <TouchableOpacity
          style={styles.overlay}
          activeOpacity={1}
          onPress={() => setImagePopup?.(false)}
        />
        <View style={styles.popupContent}>
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={styles.button}
              onPress={() => {
                imageHandler('camera');
              }}
            >
              <Word text={'Choose Camera'} size={18} font={2} color={'black'} />
            </TouchableOpacity>
          </View>
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={styles.button}
              onPress={() => {
                imageHandler('gallery');
              }}
            >
              <Word text={'Choose File'} size={18} font={2} color={'black'} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
  },
  overlay: {
    flex: 1,
  },
  popupContent: {
    backgroundColor: C.PRIMARY1,
    borderTopLeftRadius: MS(30),
    borderTopRightRadius: MS(30),
    paddingVertical: VS(30),
    paddingHorizontal: HS(50),
    alignItems: 'center',
    gap: MS(20),
    paddingBottom: VS(55),
  },
  buttonContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  button: {
    height: VS(50),
    backgroundColor: C.WHITE,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: MS(10),
    elevation: 2,
    paddingHorizontal: HS(25),
  },
});

export default UploadImagePopup;
