/* eslint-disable react-native/no-inline-styles */
import { Modal, StyleSheet, TouchableOpacity, TouchableWithoutFeedback, View } from 'react-native';
import React, { useState } from 'react';
import { CommonActions, useNavigation } from '@react-navigation/native';
import Word from '../Word/Word';
import { fS } from '../../Utils/FontSize';
import { C } from '../../Utils/ColorFonts';
import Loader from '../Loaders/Loader';
import { mmkvStorage, Toast } from '../../Utils/Constants';
import { post } from '../../Redux/apiRequest/ApiHandler';
import { URLS } from '../../Redux/apiRequest/Constant';
import Img from '../img/Img';
// import { GrownModal } from '../../assets/images/imgIndex';

const AccountModal = ({
  visible,
  onClose,
  title,
  title_2,
  OnPressYes,
  loader,
  titleStyle,
  title_2Style,
}) => {
  return (
    <Modal
      visible={visible}
      onRequestClose={() => {
        onClose?.(false);
      }}
      transparent={true}
    >
      <TouchableWithoutFeedback onPress={() => onClose?.(false)}>
        <View style={styles.container}>

          {/* Prevent closing when clicking inside box */}
          <TouchableWithoutFeedback>
            <View style={styles.viewBox}>
              {/* <Img src={GrownModal} style={{ width: fS(55), height: fS(55) }} /> */}

              {title && (
                <Word
                  text={title || 'title 1'}
                  size={22}
                  font={3}
                  color={'#000'}
                  tc={'center'}
                  align={'center'}
                  style={titleStyle}
                  mt={20}
                />
              )}

              {title_2 && (
                <Word
                  text={title_2 || 'title 2'}
                  size={20}
                  font={1}
                  color={'#000'}
                  tc={'center'}
                  mt={10}
                  align={'center'}
                  style={title_2Style}
                />
              )}

              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: fS(20),
                  marginTop: fS(20),
                }}
              >
                <TouchableOpacity
                  style={styles.btn}
                  onPress={() => {
                    if (!loader) {
                      OnPressYes?.();
                    }
                  }}
                >
                  <Word
                    text={'Explore Plans'}
                    size={22}
                    font={2}
                    color={C.WHITE}
                    tc={'center'}
                  />
                </TouchableOpacity>
              </View>

            </View>
          </TouchableWithoutFeedback>

        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

export default AccountModal;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.2)',
    paddingHorizontal: fS(20),
    // alignSelf: 'center',
  },
  viewBox: {
    width: '98%',
    backgroundColor: C.WHITE,
    elevation: 3,
    shadowColor: C.BLACK,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.24,
    padding: fS(40),
    alignItems: 'center',
    borderRadius: fS(50),
  },
  btn: {
    width: '100%',
    height: fS(75),
    borderWidth: 1,
    borderColor: C.PURPLE,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: fS(15),
    backgroundColor: C.PURPLE,
  },
});
