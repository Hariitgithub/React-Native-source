import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { CommonActions } from '@react-navigation/native';
import { saveAlertMessage } from '../../Redux/Slice/alertMessage';
import { fS } from '../../Utils/FontSize';
import { C, F } from '../../Utils/ColorFonts';
import { mmkvStorage } from '../../Utils/Constants';
const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

const AlertComp = ({ navi }) => {
  const dispatch = useDispatch();
  const alrt = useSelector(state => state.alertMessage);

  const onClose = async () => {
    dispatch(saveAlertMessage(''));
    if (alrt?.msg === 'Unauthenticated') {
      mmkvStorage.clearAll();
      navi.dispatch(
        CommonActions.reset({ index: 0, routes: [{ name: 'login' }] }),
      );
    }
  };

  return (
    <View style={styles.alertTlBox}>
      <View style={styles.alertBoxInner}>
        {alrt?.msg && <Text style={styles.msgText}>{alrt?.msg}</Text>}
        <TouchableOpacity style={styles.closeBtn} onPress={onClose}>
          <Text style={styles.closeText}>Close</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  alertTlBox: {
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: 'rgba(0,0,0,0.7)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 11111111,
  },
  alertBoxInner: {
    width: '75%',
    padding: 20,
    minHeight: fS(200),
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeBtn: {
    width: fS(150),
    height: fS(50),
    backgroundColor: C.PRIMARY,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15,
  },
  closeText: {
    fontFamily: F.f2,
    color: C.WHITE,
    fontSize: fS(24),
  },
  msgText: {
    fontFamily: F.f3,
    lineHeight: fS(27),
    color: '#000',
    fontSize: fS(18),
    textAlign: 'center',
  },
});

export default AlertComp;
