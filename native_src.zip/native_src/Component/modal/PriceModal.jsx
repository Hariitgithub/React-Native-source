/* eslint-disable react-native/no-inline-styles */
import {
  Modal,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import { HS, MS, VS } from '../../Utils/FontSize';
import { C, F, inrSymbol } from '../../Utils/ColorFonts';
import Word from '../Word/Word';
import Img from '../img/Img';
import {
  person_purple,
  room_symbol,
  unCheck,
  check,
  CheckInIcon,
  CheckOutIcon,
  child_icon,
  ChildIcon,
} from '../../assets/images/imgIndex';
import { paddingHV } from '../../Utils/Constants';
import CommonButton from '../Buttons/CommonButton';
import dayjs from 'dayjs';
import { CommonActions, useNavigation } from '@react-navigation/native';
import moment from 'moment';

const PriceModal = ({
  visible,
  onClose,
  priceObj,
  slot,
  selectedDate,
  priceDetails,
  priceOptions,
  setPriceOptions,
  bookProperty,
  BookingDetails,
  setBookingDetails,
  loader,
  paymentType,
  tdsPercent,
  BookingDetailsLoader,
  setBookingDetailsLoader,
}) => {

  console.log("final priceDetails --->", priceDetails);
  console.log("final bookProperty --->", bookProperty);
  console.log("final BookingDetails --->", BookingDetails);
  console.log("final priceObj --->", priceObj);
  console.log("final priceOptions --->", priceOptions);
  console.log("final paymentType --->", paymentType);





  const navigation = useNavigation();
  let start = dayjs(slot?.start_time, 'HH:mm:ss').format('hh:mm A');
  let end = dayjs(slot?.end_time, 'HH:mm:ss').format('hh:mm A');
  let data = [
    priceObj?.room?.length,
    priceObj?.totalAdult,
    priceObj?.totalChild,
  ];
  let priceDataobj = {};
  priceDetails?.forEach(i => {
    if (i?.name?.includes('S.D Room price') && i?.hide) return;
    priceDataobj[
      i?.name?.split('*')?.[0]?.replaceAll(' ', '').replaceAll('.', '')
    ] = i.price;
  });

  // --- NEW ALGORITHM IMPLEMENTATION ---
  let totalAmount = priceDetails?.[priceDetails?.length - 1]?.price;
  let totalCommission = (priceObj?.propertyCommission || 0) + (priceObj?.ExtraPersonCommission || 0);
  let tipsAmount = priceOptions.tips ? Number(priceDataobj?.Tips || 0) : 0;

  // 1. Target Advance
  let targetAdvance = totalCommission + tipsAmount;

  // 2. Read the precisely capped discounts from the parent, ONLY IF CHECKED
  let appliedCoupon = priceOptions?.coupon ? Math.abs(Number(priceDataobj?.Coupon || 0)) : 0;
  let appliedWallet = priceOptions?.wallet ? Math.abs(Number(priceDataobj?.Walletmoney || 0)) : 0;


  // 3. Exact Razorpay calculation
  let razorpayBalance = Math.max(0, Math.round((targetAdvance - appliedCoupon - appliedWallet) * 100) / 100);
  let isAdv = paymentType === 4;
  // ------------------------------------



  const handleSelect = name => {
    setPriceOptions(prev => ({ ...prev, [name]: !prev?.[name] }));
  };

  const partialPay = amount => {
    let half = Math.ceil(Number(amount) / 2);
    let partial = (amount % 100) + Math.ceil(half / 100) * 100;
    return partial > amount ? amount : partial;
  };
  console.log('slot', slot?.timeslot_color_code);
  const date = new Date(priceObj?.selectedDates?.checkOut);
  date.setDate(date.getDate() + 1);
  const from = new Date(priceObj && priceObj?.selectedDates?.from);

  //const to = new Date(priceObj && priceObj?.selectedDates?.to);

  const to = new Date(priceObj && priceObj?.selectedDates?.checkOut);

  const options = { weekday: 'short' }; // Sun, Mon, Tue...
  const option = { weekday: 'long' }; // Sun, Mon, Tue...

  const startDay = from.toLocaleDateString('en-US', options);
  const endDay =
    from.toDateString() === to.toDateString() && slot?.timeslot_name == '22 hrs'
      ? date.toLocaleDateString('en-US', options)
      : to.toLocaleDateString('en-US', options);

  const dayDisplay =
    from.toDateString() === to.toDateString() &&
      slot?.timeslot_name !== '22 hrs'
      ? new Date(priceObj && priceObj?.selectedDates?.from).toLocaleDateString(
        'en-US',
        option,
      )
      : `${startDay} - ${endDay}`;

  const toDate =
    slot?.timeslot_name === '22 hrs' && from.toDateString() == to.toDateString()
      ? date.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      : new Date(priceObj?.selectedDates?.checkOut).toLocaleDateString(
        'en-GB',
        {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
        },
      );
  console.log('====================================');
  console.log('dayDisplaydayDisplay', BookingDetailsLoader);
  console.log('====================================');
  return (
    <Modal
      key={priceDetails}
      visible={visible}
      onRequestClose={onClose}
      transparent={true}
    >
      <View style={styles.container}>
        <View style={styles.priceCont}>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: 1,
              paddingBottom: 10,
            }}
          >
            <View
              style={{
                backgroundColor: slot?.timeslot_color_code || '#FFDC2B',
                padding: MS(10),
                borderRadius: 9,
                paddingHorizontal: HS(9),
              }}
            >
              <Text
                allowFontScaling={false}
                style={{
                  fontSize: 12,
                  fontFamily: F.f3,
                  color:
                    slot?.timeslot_color_code == '#F7D21F' ? '#000' : '#fff',
                }}
              >
                {slot?.timeslot_displayname} - {/* {slot?.timeslot_name}  */}(
                {/* {moment(slot?.start_time).format('DD-MM-YYYY ')} -{' '}
              {slot?.end_time} */}
                {moment(slot?.start_time, 'HH:mm:ss').format('hh:mm A')} -{' '}
                {moment(slot?.end_time, 'HH:mm:ss').format('hh:mm A')})
              </Text>
            </View>
            <View>
              <Text
                allowFontScaling={false}
                style={{ fontSize: 12, fontFamily: F.f3, marginRight: 10 }}
              >
                {dayDisplay}
              </Text>
            </View>
          </View>
          <View
            style={{
              borderWidth: 1,
              borderColor: C.BG_GRAY,
              width: '100%',
              height: 1,
              marginBottom: 10,
            }}
          />
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginBottom: VS(10),
            }}
          >
            <View>
              <View style={{ flexDirection: 'row', gap: 4 }}>
                <Img src={CheckInIcon} width={30} height={30} />
                <Text allowFontScaling={false} style={{ fontFamily: F.f4 }}>
                  Check In
                </Text>
              </View>
              <Text
                allowFontScaling={false}
                style={{ fontFamily: F.f2, fontSize: 14, marginTop: 3 }}
              >
                {new Date(
                  priceObj && priceObj?.selectedDates?.from,
                ).toLocaleDateString('en-GB', {
                  day: '2-digit',
                  month: 'short',
                  year: 'numeric',
                })}
              </Text>
            </View>
            <View>
              <View style={{ flexDirection: 'row', gap: 4 }}>
                <Img src={CheckOutIcon} width={30} height={30} />
                <Text style={{ fontFamily: F.f4 }} allowFontScaling={false}>
                  Check Out
                </Text>
              </View>
              <Text
                style={{ fontFamily: F.f2, fontSize: 14, marginTop: 3 }}
                allowFontScaling={false}
              >
                {toDate}
              </Text>
            </View>
          </View>
          <View
            style={{
              borderWidth: 1,
              borderColor: C.BG_GRAY,
              width: '100%',
              height: 1,
              marginBottom: 10,
            }}
          />
          <View
            style={[
              styles.row,
              { justifyContent: 'space-between', paddingHorizontal: HS(10) },
            ]}
          >
            {data.map((item, ind) => {
              return (
                <View key={ind} style={styles.row}>
                  <Img
                    src={
                      ind == 0
                        ? room_symbol
                        : ind === 1
                          ? person_purple
                          : ChildIcon
                    }
                    height={25}
                    width={25}
                  />

                  <Word
                    text={`${item} ${ind === 0 ? 'Room' : ind === 1 ? 'Adult' : 'Child'
                      }`}
                    font={4}
                    mt={5}
                  />
                </View>
              );
            })}
          </View>
          <View
            style={{
              borderWidth: 1,
              borderColor: C.BG_GRAY,
              width: '100%',
              height: 1,
              marginBottom: 10,
              marginTop: 10,
            }}
          />

          {BookingDetails?.id
            ? Object.entries(BookingDetails).map((key, ind) => {
              if (key[0] === 'id') return;
              console.log('KKKKKKDASKKSA', key);

              return (
                <View
                  key={ind}
                  style={[
                    styles.priceOptions,
                    {
                      backgroundColor:
                        key[0] === 'Advance paid'
                          ? C.PURPLE
                          : key[0] === 'Balance amount'
                            ? '#909090'
                            : C.WHITE,

                      borderTopWidth: key[0] === 'Total Amount' ? 2 : 0,
                      borderTopColor: C.BG_GRAY || C.BG_GRAY,
                      borderRadius: 29,
                      marginTop:
                        key[0] === 'Balance amount'
                          ? 15
                          : key[0] === 'Advance paid'
                            ? 15
                            : 0,
                      marginHorizontal:
                        key[0] === 'Balance amount' ||
                          key[0] === 'Advance paid'
                          ? 15
                          : 0,
                    },
                  ]}
                >
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: MS(10),
                    }}
                  >
                    <Word
                      font={1}
                      size={Platform.OS == 'ios' ? 18 : 22}
                      text={key[0]}
                      color={
                        key[0] === 'Advance paid' ||
                          key[0] === 'Balance amount'
                          ? C.WHITE
                          : C.BLACK
                      }
                    />

                    {key[0] === 'Tips' &&
                      ((BookingDetails?.Coupon &&
                        BookingDetails?.Coupon !== 0) ||
                        (BookingDetails?.['Wallet money'] &&
                          BookingDetails['Wallet money'] !== 0)) && (
                        <Word
                          font={1}
                          size={12}
                          text={'(Applied From Wallet/Coupon)'}
                          color={C.PURPLE_BORDER}
                        />
                      )}
                  </View>

                  <Word
                    font={2}
                    size={Platform.OS == 'ios' ? 18 : 22}
                    color={
                      key[0] === 'Advance paid' || key[0] === 'Balance amount'
                        ? C.WHITE
                        : C.BLACK
                    }
                    text={`${key[1] === 'Fully Paid' ? '' : inrSymbol} ${key[0] == 'Wallet money' ? '-' : ''
                      }${key[1]}`}
                  />
                </View>
              );
            })
            : priceDetails?.map((item, ind) => {
              if (
                item?.hide ||
                (item?.name === 'Tips' && !priceOptions?.tips) ||
                (item?.name === 'Wallet money' && !priceOptions?.wallet) ||
                (item?.name === 'Coupon' && !priceOptions?.coupon)
              )
                return;

              return (
                <View key={ind}>
                  {item?.name === 'Total Amount' && (
                    <View
                      style={{
                        height: 1,
                        backgroundColor: '#E0E0E0',
                        // marginVertical: 10,
                      }}
                    />
                  )}

                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      paddingVertical: VS(12),
                      backgroundColor: '#fff',
                    }}
                  >
                    <View
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        gap: MS(10),
                      }}
                    >
                      <Word font={1} size={22} text={item.name} />
                      {/* {(item.name === 'Wallet money' ||
                          item.name === 'Tips' ||
                          item.name === 'Coupon') && (
                          <TouchableOpacity
                            activeOpacity={0.8}
                            onPress={() => {
                              let accessor =
                                item?.name === 'Tips'
                                  ? 'tips'
                                  : item?.name === 'Wallet money'
                                  ? 'wallet'
                                  : 'coupon';
                              // handleSelect(accessor);
                            }}
                          >
                            <Img
                              src={checked ? check : unCheck}
                              height={25}
                              width={25}
                            />
                          </TouchableOpacity>
                        )} */}
                      {item?.name === 'Tips' &&
                        razorpayBalance !== targetAdvance && (
                          <Word
                            font={1}
                            size={12}
                            text={'(Applied From Wallet/Coupon)'}
                            color={C.PURPLE_BORDER}
                          />
                        )}
                    </View>
                    {/* <Word font={1} size={22} text={item.name} /> */}

                    <Word
                      font={2}
                      size={22}
                      text={`${item.price < 0 ? '- ' : ''}₹ ${Math.abs(Number(item.price)).toFixed(0)}`}
                    />
                  </View>
                </View>
              );
            })}
          <View style={styles.btnCont}>
            {!BookingDetails?.id && (
              <View>
                {totalAmount !== 0 && (
                  <CommonButton
                    loader={loader === 'full'}
                    title={
                      isAdv
                        ? `Balance Pay at hotel ${Number(
                          Math.round((totalAmount - razorpayBalance) * 100) /
                          100,
                        ).toFixed(0)}`
                        : `Full pay ${Number(totalAmount).toFixed(0)}`
                    }
                    bgColor={'#AAAAAA'}
                    titleStyle={{
                      fontSize: Platform.OS == 'ios' ? MS(20) : MS(28),
                    }}
                    btnStyle={{
                      // borderWidth: 1,
                      // borderColor: C.PURPLE_BORDER,
                      borderRadius: MS(90),
                    }}
                    onPress={() => {
                      if (!loader && !isAdv)
                        bookProperty?.(Number(totalAmount).toFixed(0), 1);
                    }}
                  />
                )}

                {(totalAmount === 0 || paymentType !== 1) && (
                  <CommonButton
                    loader={loader === 'partial'}
                    titleStyle={{
                      fontSize: Platform.OS == 'ios' ? MS(20) : MS(28),
                    }}
                    title={
                      totalAmount == 0
                        ? 'Confirm'
                        : paymentType === 4
                          ? razorpayBalance == 0
                            ? 'Confirm'
                            : ` Advance Pay ${Number(razorpayBalance).toFixed(0)}`
                          : `Partial pay ${Number(partialPay(totalAmount)).toFixed(0)}`
                    }
                    btnStyle={{
                      // borderWidth: 1,
                      // borderColor: C.PURPLE_BORDER,
                      borderRadius: MS(90),
                    }}
                    onPress={() => {
                      if (!loader)
                        bookProperty?.(
                          paymentType === 4
                            ? Number(razorpayBalance).toFixed(0)
                            : partialPay(totalAmount),
                          totalAmount == 0 ? 1 : paymentType === 4 ? 4 : 2,
                        );
                    }}
                  />
                )}
              </View>
            )}

            <CommonButton
              loader={BookingDetailsLoader === 'partial'}
              title={
                BookingDetails?.id
                  ? 'Okay'
                  : BookingDetailsLoader
                    ? 'Loading...'
                    : 'Cancel'
              }
              bgColor={C.WHITE}
              titleStyle={{ fontSize: Platform.OS == 'ios' ? MS(20) : MS(28) }}
              titleColor={BookingDetails?.id ? C.BLACK : C.PURPLE_BORDER}
              btnStyle={{
                borderWidth: 1,
                borderColor: BookingDetails?.id ? C.BLACK : C.PURPLE_BORDER,
                borderRadius: MS(90),
              }}
              onPress={() => {
                if (!BookingDetailsLoader) {
                  setBookingDetails(true);
                  onClose(false);
                  if (BookingDetails?.id)
                    navigation.dispatch(
                      CommonActions.reset({
                        index: 1,
                        routes: [{ name: 'home' }, { name: 'Booking' }],
                      }),
                    );
                }
              }}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default PriceModal;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.85)',
    paddingHorizontal: HS(20),
  },
  priceCont: {
    width: '85%',
    backgroundColor: C.WHITE,
    borderRadius: MS(30),
    paddingVertical: VS(30),
    paddingHorizontal: HS(10),
  },
  mid: {
    backgroundColor: '#DDBFFF',
    paddingHorizontal: HS(20),
    paddingVertical: VS(10),
    marginVertical: VS(15),
    gap: MS(10),
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: MS(5),
  },
  rowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: HS(20),
    paddingVertical: VS(10),
  },
  bottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    ...paddingHV(20, 10),
  },
  btnCont: {
    paddingHorizontal: HS(20),
  },
  priceOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: HS(20),
    paddingVertical: VS(10),
  },
});
