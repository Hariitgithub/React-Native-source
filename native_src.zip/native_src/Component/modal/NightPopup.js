import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Modal,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { CommonActions } from '@react-navigation/native';
import { saveAlertMessage } from '../../Redux/Slice/alertMessage';
import { HS, MS, VS } from '../../Utils/FontSize';
import { C, F } from '../../Utils/ColorFonts';
import { mmkvStorage } from '../../Utils/Constants';
const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

const NightPopup = ({ navi, show }) => {
  const dispatch = useDispatch();
  const alrt = useSelector(state => state.alertMessage);

  const onClose = async () => {
    dispatch(saveAlertMessage(''));
    if (alrt?.msg === 'Unauthenticated') {
      let home_data = mmkvStorage.getString('home');
      let location_data = mmkvStorage.getString('location');
      mmkvStorage.clearAll();
      mmkvStorage.set('home', home_data);
      mmkvStorage.set('location', location_data);
      navi.navigate('login');
      // navi.dispatch(
      //   CommonActions.reset({ index: 0, routes: [{ name: 'login' }] }),
      // );
    }
  };

  return (
    <Modal visible={show} transparent={true} animationType="fade">
      <View style={styles.alertTlBox}>
        <View style={styles.alertBoxInner}>
          {alrt?.msg && (
            <Text style={styles.msgText} allowFontScaling={false}>
              {alrt?.msg}
            </Text>
          )}
          <TouchableOpacity style={styles.closeBtn} onPress={onClose}>
            <Text style={styles.closeText} allowFontScaling={false}>
              Close
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  alertTlBox: {
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: 'rgba(0,0,0,0.3)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 11111111,
  },
  alertBoxInner: {
    width: '75%',
    padding: 20,
    minHeight: VS(200),
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeBtn: {
    width: HS(150),
    height: VS(50),
    backgroundColor: C.PRIMARY,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15,
  },
  closeText: {
    fontFamily: F.f2,
    color: C.WHITE,
    fontSize: MS(24),
  },
  msgText: {
    fontFamily: F.f3,
    lineHeight: VS(27),
    color: '#000',
    fontSize: MS(18),
    textAlign: 'center',
  },
});

export default NightPopup;
