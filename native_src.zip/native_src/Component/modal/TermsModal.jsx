import {
  Modal,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { HS, MS, VS } from '../../Utils/FontSize';
import { C, F } from '../../Utils/ColorFonts';
import CommonButton from '../Buttons/CommonButton';
import Word from '../Word/Word';

const TermsModal = ({ visible, onUpdate, data = [] }) => {
  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.box}>
          <Text allowFontScaling={false} style={styles.title}>
            Terms & Conditions
          </Text>
          <ScrollView
            contentContainerStyle={{ paddingBottom: 30, paddingRight: 15 }}
            style={{
              height: VS(350),
              borderWidth: 1,
              borderColor: '#8B95A0',
              borderRadius: 10,
              padding: MS(15),
              marginVertical: VS(15),
            }}
          >
            {data.map((i, ind) => {
              return (
                <View style={styles.row} key={ind}>
                  <Word text={'●'} />
                  <Word text={i?.message} />
                </View>
              );
            })}
          </ScrollView>
          <View
            style={{
              display: 'flex',
              justifyContent: 'center',
              flexDirection: 'row',
            }}
          >
            <View style={{ width: HS(120) }}>
              <CommonButton
                title={'Ok'}
                onPress={onUpdate}
                btnStyle={{
                  // borderWidth: 1,
                  // borderColor: BookingDetails?.id ? C.BLACK : C.PURPLE_BORDER,
                  borderRadius: MS(105),
                }}
              />
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default TermsModal;

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  box: {
    width: '80%',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
  },
  title: {
    fontSize: 18,
    fontFamily: F.f2,
    alignSelf: 'center',
  },
  desc: {
    marginVertical: 12,
    fontSize: 14,
    fontFamily: F.f3,
  },
  btn: {
    backgroundColor: C.PRIMARY1,
    padding: 12,
    borderRadius: 6,
    alignItems: 'center',
    width: HS(200),
    alignSelf: 'center',
    marginTop: VS(20),
  },
  btnText: {
    color: '#fff',
  },
  row: {
    flexDirection: 'row',
    gap: HS(10),
    marginVertical: VS(15),
  },
});
