/* eslint-disable react-native/no-inline-styles */
import { Modal, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React from 'react';
import { VS, HS, MS } from '../../Utils/FontSize';
import { C, F, inrSymbol } from '../../Utils/ColorFonts';
import Word from '../Word/Word';
import Img from '../img/Img';
import {
  person_purple,
  room_symbol,
  unCheck,
  check,
} from '../../assets/images/imgIndex';
import { paddingHV } from '../../Utils/Constants';
import CommonButton from '../Buttons/CommonButton';
import dayjs from 'dayjs';
import { CommonActions, useNavigation } from '@react-navigation/native';

const PriceModal = ({
  visible,
  onClose,
  priceObj,
  slot,
  selectedDate,
  priceDetails,
  priceOptions,
  setPriceOptions,
  bookProperty,
  BookingDetails,
  setBookingDetails,
  loader,
  paymentType,
  tdsPercent,
}) => {
  const navigation = useNavigation();
  let start = dayjs(slot?.start_time, 'HH:mm:ss').format('hh:mm A');
  let end = dayjs(slot?.end_time, 'HH:mm:ss').format('hh:mm A');
  let data = [
    priceObj?.room?.length,
    priceObj?.totalAdult,
    priceObj?.totalChild,
  ];
  let priceDataobj = {};
  priceDetails?.forEach(i => {
    if (i?.name?.includes('S.D Room price') && i?.hide) return;
    priceDataobj[
      i?.name?.split('*')?.[0]?.replaceAll(' ', '').replaceAll('.', '')
    ] = i.price;
  });

  //total commission to pay
  let totalAmount = priceDetails?.[priceDetails?.length - 1]?.price;
  let totalCommission =
    priceObj?.propertyCommission + priceObj?.ExtraPersonCommission;
  let totalTdsAmount =
    ((priceObj?.totalAmount - totalCommission) / 100) * tdsPercent;
  let tipsAmount = priceOptions.tips ? priceDataobj?.Tips : 0;
  let advanceAmount = totalCommission + totalTdsAmount + Number(tipsAmount);

  //advance payment calculation
  let isAdv = paymentType === 4;
  let couponAmount = Number(priceDataobj?.Coupon) * -1;
  let advCoupon = priceOptions.coupon
    ? couponAmount > advanceAmount
      ? advanceAmount
      : couponAmount
    : 0;
  let walletMoney = Number(priceDataobj?.Walletmoney);
  let balanceAdv = advanceAmount - advCoupon;
  let advWallet =
    priceOptions.wallet && balanceAdv > 0
      ? walletMoney > balanceAdv
        ? balanceAdv
        : walletMoney
      : 0;
  let razorpayBalance =
    Math.round((advanceAmount - advCoupon - advWallet) * 100) / 100;

  const handleSelect = name => {
    setPriceOptions(prev => ({ ...prev, [name]: !prev?.[name] }));
  };
  console.log('price details', priceDetails, razorpayBalance, advanceAmount);
  const partialPay = amount => {
    let half = Math.ceil(Number(amount) / 2);
    let partial = (amount % 100) + Math.ceil(half / 100) * 100;
    return partial > amount ? amount : partial;
  };

  return (
    <Modal
      key={priceDetails}
      visible={visible}
      onRequestClose={onClose}
      transparent={true}
    >
      <View style={styles.container}>
        <View style={styles.priceCont}>
          {/* {BookingDetails?.length !== 0 && (
            <View style={styles.rowBetween}>
              <Word
                text={'Room Booking'}
                font={2}
                size={16}
                color={'#8D8989'}
              />
              <Word
                text={`Booked date: ${dayjs(selectedDate).format(
                  'DD-MM-YYYY',
                )}`}
                font={2}
                size={16}
                color={'black'}
              />
            </View>
          )} */}
          <Text
            style={{
              color: C.BLACK,
              fontSize: MS(23),
              fontFamily: F.f3,
              paddingHorizontal: HS(20),
            }}
            allowFontScaling={false}
          >
            {dayjs(selectedDate).format('dddd')} /
            {` ${slot?.timeslot_name} Slot / `}
            <Text style={{ color: '#858585' }} allowFontScaling={false}>
              {slot?.timeslot_displayname || slot?.timeslot_type}
            </Text>
          </Text>

          <View style={styles.mid}>
            <Word
              text={`Check in Time : ${dayjs(
                priceObj?.selectedDates?.from,
              ).format('DD-MM-YYYY')}, ${start}`}
              font={2}
              size={18}
              color={'black'}
            />
            <Word
              text={`Check Out Time : ${dayjs(priceObj?.selectedDates?.to)
                .add(slot?.timeslot_name?.includes('22') ? 1 : 0, 'day')
                .format('DD-MM-YYYY')}, ${end}`}
              font={2}
              size={18}
              color={'black'}
            />
          </View>

          <View
            style={[
              styles.row,
              { justifyContent: 'space-between', paddingHorizontal: HS(10) },
            ]}
          >
            {data.map((item, ind) => {
              return (
                <View key={ind} style={styles.row}>
                  <Img
                    src={ind > 0 ? person_purple : room_symbol}
                    height={25}
                    width={25}
                  />

                  <Word
                    text={`${item} ${ind === 0 ? 'Room' : ind === 1 ? 'Adult' : 'Children'
                      }`}
                    font={4}
                    mt={5}
                  />
                </View>
              );
            })}
          </View>
          {BookingDetails?.id
            ? Object.entries(BookingDetails).map((key, ind) => {
              if (key[0] === 'id') return;
              return (
                <View
                  key={ind}
                  style={[
                    styles.priceOptions,
                    {
                      backgroundColor:
                        key[0] === 'Total Amount' ||
                          key[0] === 'Balance amount'
                          ? C.BG_TEXT
                          : C.WHITE,
                    },
                  ]}
                >
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: MS(10),
                    }}
                  >
                    <Word font={1} size={22} text={key[0]} />
                    {key[0] === 'Tips' &&
                      ((BookingDetails?.Coupon &&
                        BookingDetails?.Coupon !== 0) ||
                        (BookingDetails?.['Wallet money'] &&
                          BookingDetails['Wallet money'] !== 0)) && (
                        <Word
                          font={1}
                          size={12}
                          text={'(Applied From Wallet/Coupon)'}
                          color={C.PURPLE_BORDER}
                        />
                      )}
                  </View>
                  <Word
                    font={2}
                    size={22}
                    text={`${key[1] === 'Fully Paid' ? '' : inrSymbol} ${key[1]
                      }`}
                  />
                </View>
              );
            })
            : priceDetails?.map((item, ind) => {
              let checked =
                item?.name === 'Tips'
                  ? priceOptions.tips
                  : item?.name === 'Wallet money'
                    ? priceOptions.wallet
                    : priceOptions?.coupon;

              if (
                item?.hide ||
                (item?.name === 'Tips' && !priceOptions?.tips) ||
                (item?.name === 'Wallet money' && !priceOptions?.wallet) ||
                (item?.name === 'Coupon' && !priceOptions?.coupon)
              )
                return;
              return (
                <View
                  key={ind}
                  style={[
                    styles.priceOptions,
                    {
                      backgroundColor: C.WHITE,
                    },
                  ]}
                >
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: MS(10),
                    }}
                  >
                    <Word font={1} size={22} text={item.name} />
                    {(item.name === 'Wallet money' ||
                      item.name === 'Tips' ||
                      item.name === 'Coupon') && (
                        <TouchableOpacity
                          activeOpacity={0.8}
                          onPress={() => {
                            let accessor =
                              item?.name === 'Tips'
                                ? 'tips'
                                : item?.name === 'Wallet money'
                                  ? 'wallet'
                                  : 'coupon';
                            // handleSelect(accessor);
                          }}
                        >
                          <Img
                            src={checked ? check : unCheck}
                            height={25}
                            width={25}
                          />
                        </TouchableOpacity>
                      )}
                    {item?.name === 'Tips' &&
                      razorpayBalance !== advanceAmount && (
                        <Word
                          font={1}
                          size={12}
                          text={'(Applied From Wallet/Coupon)'}
                          color={C.PURPLE_BORDER}
                        />
                      )}
                  </View>
                  <Word font={2} size={22} text={item.price} />
                </View>
              );
            })}
          <View style={styles.btnCont}>
            {!BookingDetails?.id && (
              <View>
                {totalAmount !== 0 && (
                  <CommonButton
                    loader={loader === 'full'}
                    title={
                      isAdv
                        ? `Balance Pay at hotel ${Math.round((totalAmount - razorpayBalance) * 100) /
                        100
                        }`
                        : `Full pay ${totalAmount}`
                    }
                    bgColor={'#AAAAAA'}
                    onPress={() => {
                      if (!loader && !isAdv) bookProperty?.(totalAmount, 1);
                    }}
                  />
                )}

                {(totalAmount === 0 || paymentType !== 1) && (
                  <CommonButton
                    loader={loader === 'partial'}
                    title={
                      totalAmount == 0
                        ? 'Confirm'
                        : paymentType === 4
                          ? razorpayBalance == 0
                            ? 'Confirm'
                            : `Pay Advance ${razorpayBalance}`
                          : `Partial pay ${partialPay(totalAmount)}`
                    }
                    onPress={() => {
                      if (!loader)
                        bookProperty?.(
                          paymentType === 4
                            ? razorpayBalance
                            : partialPay(totalAmount),
                          totalAmount == 0 ? 1 : paymentType === 4 ? 4 : 2,
                        );
                    }}
                  />
                )}
              </View>
            )}

            <CommonButton
              title={BookingDetails?.id ? 'Ok' : 'Cancel'}
              bgColor={C.WHITE}
              titleColor={C.PURPLE_BORDER}
              btnStyle={{
                borderWidth: 1,
                borderColor: C.PURPLE_BORDER,
              }}
              onPress={() => {
                setBookingDetails(true);
                onClose(false);
                if (BookingDetails?.id)
                  navigation.dispatch(
                    CommonActions.reset({
                      index: 1,
                      routes: [{ name: 'home' }, { name: 'Booking' }],
                    }),
                  );
              }}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default PriceModal;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.85)',
    paddingHorizontal: HS(20),
  },
  priceCont: {
    width: '85%',
    backgroundColor: C.WHITE,
    borderRadius: MS(30),
    paddingVertical: VS(30),
  },
  mid: {
    backgroundColor: '#DDBFFF',
    paddingHorizontal: HS(20),
    paddingVertical: VS(10),
    marginVertical: VS(15),
    gap: MS(10),
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: MS(5),
  },
  rowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: HS(20),
    paddingVertical: VS(10),
  },
  bottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    ...paddingHV(HS(20), VS(10)),
  },
  btnCont: {
    paddingHorizontal: HS(20),
  },
  priceOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: HS(20),
    paddingVertical: VS(10),
  },
});
