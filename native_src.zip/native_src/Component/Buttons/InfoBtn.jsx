import { StyleSheet, TouchableOpacity, View } from 'react-native';
import React, { useState } from 'react';
import Word from '../Word/Word';
import { commonStyles } from '../../assets/style/CommonStyles';
import { HS, MS, VS } from '../../Utils/FontSize';
import { C } from '../../Utils/ColorFonts';

const InfoBtn = ({ info, TextStyle, popupStyle, timer }) => {
  const [showInfo, setShowInfo] = useState(false);
  return (
    <View>
      {showInfo && (
        <View style={[commonStyles.shadow, styles.infoPopup, popupStyle]}>
          <Word
            style={TextStyle}
            text={info ?? 'Info popup'}
            font={2}
            size={16}
            color={'text'}
          />
        </View>
      )}
      <TouchableOpacity
        activeOpacity={0.8}
        onPress={() => {
          if (!showInfo) {
            setShowInfo(true);
            setTimeout(() => {
              setShowInfo(false);
            }, timer || 1500);
          }
        }}
        style={styles.infoBtn}
      >
        <Word text={'i'} font={2} size={16} color={'black'} />
      </TouchableOpacity>
    </View>
  );
};

export default InfoBtn;

const styles = StyleSheet.create({
  infoBtn: {
    borderWidth: 1,
    borderRadius: MS(30),
    height: VS(30),
    width: HS(30),
    alignItems: 'center',
    justifyContent: 'center',
  },
  infoPopup: {
    width: HS(200),
    paddingVertical: VS(15),
    position: 'absolute',
    zIndex: 1,
    top: VS(-60),
    borderRadius: 10,
    right: 0,
    backgroundColor: C.WHITE,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
