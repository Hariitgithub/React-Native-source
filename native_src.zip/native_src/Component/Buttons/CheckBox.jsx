import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React from 'react';
import { C } from '../../Utils/ColorFonts';
import Word from '../Word/Word';
import { HS, VS } from '../../Utils/FontSize';

const CheckBox = ({ value, onPress, btnColor }) => {
  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={() => {
        onPress?.();
      }}
      style={{
        borderWidth: 1,
        borderColor: btnColor ?? C.PURPLE_BORDER,
        backgroundColor: value ? btnColor ?? C.PURPLE_BORDER : C.WHITE,
        alignItems: 'center',
        justifyContent: 'center',
        height: VS(30),
        width: HS(30),
      }}
    >
      <Word text={'✔'} font={2} size={16} color={'white'} />
    </TouchableOpacity>
  );
};

export default CheckBox;

const styles = StyleSheet.create({});
