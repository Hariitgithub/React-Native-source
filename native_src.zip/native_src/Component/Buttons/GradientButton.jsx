import { StyleSheet, Text, TouchableOpacity } from 'react-native';
import React from 'react';
import { MS, VS } from '../../Utils/FontSize';
import { C, F } from '../../Utils/ColorFonts';
import LinearGradient from 'react-native-linear-gradient';

const GradientButton = ({
  title,
  btnStyle,
  titleStyle,
  bgColors,
  titleColor,
}) => {
  return (
    <LinearGradient
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 0 }}
      colors={bgColors?.length >= 2 ? [...bgColors] : ['#C175F5', '#9A36E6']}
    >
      <TouchableOpacity style={[styles.button, btnStyle]}>
        <Text
          style={[styles.text, titleStyle, { color: titleColor ?? C.WHITE }]}
        >
          {title ?? 'Submit'}
        </Text>
      </TouchableOpacity>
    </LinearGradient>
  );
};

export default GradientButton;

const styles = StyleSheet.create({
  button: {
    height: VS(70),
    borderRadius: 10,
    width: '94%',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: VS(20),
  },
  text: {
    fontSize: MS(23),
    fontFamily: F.f3,
    color: C.WHITE,
    textAlign: 'center',
    textAlignVertical: 'center',
  },
});
