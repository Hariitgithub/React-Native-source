/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { HS } from '../../Utils/FontSize';
import { C } from '../../Utils/ColorFonts';

const ToggleBtn = ({
  value = false,
  onPress,
  readOnly = false,

  // Colors
  activeToggleColor = C.WHITE,
  activeSlideColor = '#58D7BF',
  deactiveToggleColor = C.WHITE,
  deactiveSlideColor = '#D9D9D9',

  // Size Props
  width = 65,
  height = 30,
  thumbSize = 20,
  padding = 5,
  borderRadius,
  style,
}) => {
  const switchWidth = HS(width);
  const switchHeight = HS(height);
  const thumb = HS(thumbSize);
  const innerPadding = HS(padding);

  const thumbLeft = value
    ? switchWidth - thumb - innerPadding
    : innerPadding;

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      disabled={readOnly}
      onPress={onPress}
      style={[
        styles.switch,
        {
          width: switchWidth,
          height: switchHeight,
          borderRadius: borderRadius
            ? HS(borderRadius)
            : switchHeight / 2,
          backgroundColor: value
            ? activeSlideColor
            : deactiveSlideColor,
          paddingHorizontal: innerPadding,
        },
        style,
      ]}>
      <View
        style={[
          styles.thumb,
          {
            width: thumb,
            height: thumb,
            borderRadius: thumb / 2,
            backgroundColor: value
              ? activeToggleColor
              : deactiveToggleColor,
            left: thumbLeft,
          },
        ]}
      />
    </TouchableOpacity>
  );
};

export default ToggleBtn;

const styles = StyleSheet.create({
  switch: {
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.15,
    shadowRadius: 3,
    elevation: 2,
  },

  thumb: {
    position: 'absolute',
  },
});