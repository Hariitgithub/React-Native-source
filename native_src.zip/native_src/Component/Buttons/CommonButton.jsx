import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React from 'react';
import { HS, MS, VS } from '../../Utils/FontSize';
import { C, F } from '../../Utils/ColorFonts';
import Loader from '../Loaders/Loader';
import Img from '../img/Img';

const CommonButton = ({
  title,
  btnStyle,
  titleStyle,
  bgColor,
  titleColor,
  onPress,
  onLongPress,
  loader,
  loaderColor,
  opacity,
  icon,

}) => {
  return (
    <TouchableOpacity
      activeOpacity={opacity ? opacity : 0.5}
      onPress={() => {
        if (!loader) {
          onPress?.();
        }
      }}
      onLongPress={() => {
        if (!loader) {
          onLongPress?.();
        }
      }}
      style={[
        styles.button,
        btnStyle,
        { backgroundColor: bgColor ?? C.PRIMARY1 },
      ]}
    >
      {loader ? (
        <Loader color={loaderColor ?? '#fff'} />
      ) : (
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Text
            style={[styles.text, titleStyle, { color: titleColor ?? C.DARK1 }]}
            allowFontScaling={false}
          >
            {title ?? 'Submit'}
          </Text>
          {icon && (
            <Img
              src={icon}
              style={{
                borderRadius: 1,
                height: VS(30),
                width: HS(30),
                marginLeft: HS(5),
              }}
            />
          )}
        </View>
      )}
    </TouchableOpacity>
  );
};

export default CommonButton;

const styles = StyleSheet.create({
  button: {
    height: VS(51),
    backgroundColor: C.PRIMARY1,
    borderRadius: 10,
    width: '100%',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: VS(20),
  },
  text: {
    fontSize: MS(18),
    fontFamily: F.f3,
    color: C.WHITE,
    textAlign: 'center',
    textAlignVertical: 'center',
    bottom: VS(1),
  },
});
