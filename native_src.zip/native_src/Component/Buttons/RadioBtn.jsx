/* eslint-disable react-native/no-inline-styles */
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import React from 'react';
import Word from '../Word/Word';
import { HS, VS } from '../../Utils/FontSize';
import { C } from '../../Utils/ColorFonts';

const RadioBtn = ({
  onPress,
  value,
  title,
  readOnly,
  mr,
  mt,
  ml,
  mb,
  btnColor,
}) => {
  return (
    <TouchableOpacity
      style={[
        styles.Container,
        {
          marginRight: HS(mr),
          marginLeft: HS(ml),
          marginBottom: VS(mb),
          marginTop: VS(mt),
        },
      ]}
      activeOpacity={0.8}
      onPress={() => {
        if (!readOnly) {
          onPress?.();
        }
      }}
    >
      <View
        style={[
          styles.RadioContainer,
          { borderColor: value ? btnColor ?? C.PRIMARY1 : 'gray' },
        ]}
      >
        {value && (
          <View
            style={[
              styles.radioBtn,
              { backgroundColor: btnColor ?? C.PRIMARY1 },
            ]}
          />
        )}
      </View>
      <Word text={title} font={1} size={16} color={'black'} />
    </TouchableOpacity>
  );
};

export default RadioBtn;

const styles = StyleSheet.create({
  Container: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  RadioContainer: {
    height: VS(17),
    width: HS(17),
    borderWidth: 1,
    borderRadius: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: HS(10),
  },
  radioBtn: {
    backgroundColor: C.PRIMARY1,
    borderRadius: '100%',
    height: VS(12),
    width: HS(12),
  },
});
