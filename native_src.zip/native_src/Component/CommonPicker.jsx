import React, { useMemo, useState } from 'react';
import {
    FlatList,
    Modal,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from 'react-native';
import Word from './Word/Word';
import Img from './img/Img';
import { downArrow } from '../assets/images/imgIndex';
import { C, F } from '../Utils/ColorFonts';
import { HS, MS, VS } from '../Utils/FontSize';

const CommonPicker = ({
    label,
    data = [],
    value,
    placeholder = 'Select',
    onSelect,
}) => {
    const [visible, setVisible] = useState(false);
    const [search, setSearch] = useState('');

    const filteredData = useMemo(() => {
        return data.filter(item =>
            item.label.toLowerCase().includes(search.toLowerCase()),
        );
    }, [search, data]);

    const selectItem = item => {
        onSelect(item);
        setVisible(false);
        setSearch('');
    };

    return (
        <>
            {label && <Word text={label} style={styles.label} />}

            <TouchableOpacity
                activeOpacity={0.8}
                style={styles.input}
                onPress={() => setVisible(true)}>
                <Text style={value ? styles.value : styles.placeholder}>
                    {value?.label || placeholder}
                </Text>

                <Img src={downArrow} width={15} height={15} />
            </TouchableOpacity>

            <Modal
                visible={visible}
                animationType="fade"
                transparent>
                <TouchableOpacity
                    activeOpacity={1}
                    style={styles.overlay}
                    onPress={() => {
                        setVisible(false);
                        setSearch('');
                    }}>
                    <TouchableOpacity
                        activeOpacity={1}
                        style={styles.modal}>
                        <TextInput
                            placeholder="Search..."
                            value={search}
                            onChangeText={setSearch}
                            style={styles.search}
                        />

                        <FlatList
                            keyboardShouldPersistTaps="handled"
                            data={filteredData}
                            keyExtractor={item => item.value.toString()}
                            renderItem={({ item }) => (
                                <TouchableOpacity
                                    style={styles.item}
                                    onPress={() => selectItem(item)}>
                                    <Word text={item.label} style={styles.itemText} />
                                </TouchableOpacity>
                            )}
                            ListEmptyComponent={
                                <Word text={'No Data Found'} style={styles.empty} />
                            }
                        />
                    </TouchableOpacity>
                </TouchableOpacity>
            </Modal>
        </>
    );
};

export default CommonPicker;

const styles = StyleSheet.create({
    label: {
        fontSize: MS(15),
        marginBottom: HS(8),
        color: '#222',
    },

    input: {
        height: HS(52),
        borderColor: C.BORDER,
        borderWidth: 1,
        borderRadius: MS(15),
        paddingHorizontal: HS(15),
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },

    value: {
        color: '#222',
        fontSize: MS(15),
        fontFamily: F.f3,
    },

    placeholder: {
        color: '#999',
        fontSize: MS(15),
        fontFamily: F.f3,
    },

    arrow: {
        fontSize: MS(22),
        color: '#333',
    },

    overlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.3)',
        justifyContent: 'center',
        padding: MS(20),
    },

    modal: {
        backgroundColor: '#fff',
        borderRadius: MS(10),
        maxHeight: '70%',
        padding: MS(15),
    },

    search: {
        height: VS(45),
        borderWidth: HS(1),
        borderColor: '#ddd',
        borderRadius: MS(8),
        paddingHorizontal: HS(12),
        marginBottom: VS(12),
        fontFamily: F.f3,
    },

    item: {
        paddingVertical: VS(14),
        borderBottomWidth: 1,
        borderBottomColor: '#eee',
    },

    itemText: {
        fontSize: MS(15),
        color: '#222',
    },

    empty: {
        textAlign: 'center',
        marginTop: MS(20),
        color: '#999',
    },
});