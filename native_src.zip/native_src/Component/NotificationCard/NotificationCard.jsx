import { StyleSheet, TouchableOpacity, View } from 'react-native';
import React, { memo } from 'react';
import { HS, MS, VS } from '../../Utils/FontSize';
import Word from '../Word/Word';
import dayjs from 'dayjs';
import isToday from 'dayjs/plugin/isToday';
import isYesterday from 'dayjs/plugin/isYesterday';
import { C } from '../../Utils/ColorFonts';
import { useNavigation } from '@react-navigation/native';

dayjs.extend(isToday);
dayjs.extend(isYesterday);

const NotificationCard = ({ item }) => {
  if (!item || Object.keys(item).length === 0) {
    return null;
  }
  const navigation = useNavigation();
  const notificationDate = dayjs(item?.created_at);

  const getFormattedDate = () => {
    return notificationDate.format('hh:mm A');
  };

  const isRead = item?.is_read;
  const handlerNav = async ite => {
    console.log('sadjksjalda', ite);
    switch (ite?.reference_type) {
      case 2:
        navigation.navigate('PropertyDetails', {
          property_id: ite?.reference_id,
          service_id: ite?.property_service_id,
          category_id: ite?.property_category_id,
        });
        break;
      case 4:
        navigation.navigate('ReferList');
        break;
      case 3:
        navigation.navigate('Booking-detail', {
          booking_id: ite?.reference_id,
        });
        break;

      default:
        return;
    }
  };
  return (
    <TouchableOpacity onPress={() => handlerNav(item)}>
      <View
        style={[
          styles.main,
          {
            backgroundColor: !isRead ? C.BG_TEXT : '#fff',
          },
        ]}
      >
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Word text={item?.title} font={2} />
          <Word text={getFormattedDate()} font={2} color={'#777'} />
        </View>

        <Word text={item?.message} font={3} />
      </View>

      <View
        style={{
          borderBottomWidth: 1,
          borderColor: '#D9D9D9',
          paddingHorizontal: HS(15),
          marginBottom: VS(10),
        }}
      />
    </TouchableOpacity>
  );
};

export default memo(NotificationCard);

const styles = StyleSheet.create({
  main: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    padding: MS(15),
    borderRadius: 8,
  },
});
