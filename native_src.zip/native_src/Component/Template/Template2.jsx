/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import { SCREEN_HEIGHT, SCREEN_WIDTH } from '../../Utils/Constants';
import { C } from '../../Utils/ColorFonts';
import { SafeAreaView } from 'react-native-safe-area-context';

const Template2 = ({ children }) => {
  return (
    <SafeAreaView
      style={{
        flex: 1,
        width: SCREEN_WIDTH,
        height: SCREEN_HEIGHT,
        backgroundColor: C.WHITE,
        position: 'relative',
      }}
    >
      {children}
    </SafeAreaView>
  );
};

export default Template2;
