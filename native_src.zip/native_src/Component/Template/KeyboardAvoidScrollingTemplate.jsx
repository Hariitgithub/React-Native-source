/* eslint-disable react-native/no-inline-styles */
import React, {
  useState,
  useCallback,
  forwardRef,
  useEffect,
  useRef,
} from 'react';
import {
  SafeAreaView,
  RefreshControl,
  View,
} from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useFocusEffect } from '@react-navigation/native';
import { C } from '../../Utils/ColorFonts';

const KeyboardAvoidScrollingTemplate = forwardRef(
  ({ children, onRefresh }, ref) => {
    const [refreshing, setRefreshing] = useState(false);
    const scrollViewRef = useRef(null);

    useEffect(() => {
      if (ref) {
        ref.current = scrollViewRef.current;
      }
    }, [ref]);

    useFocusEffect(
      useCallback(() => {
        const timer = setTimeout(() => {
          scrollViewRef.current?.scrollTo({
            x: 0,
            y: 0,
            animated: false,
          });
        }, 50);

        return () => clearTimeout(timer);
      }, [])
    );


    const handleRefresh = useCallback(async () => {
      if (!onRefresh) return;

      setRefreshing(true);

      try {
        await onRefresh();
      } catch (err) {
        console.log('Refresh failed:', err);
      } finally {
        setRefreshing(false);
      }
    }, [onRefresh]);

    return (
      <SafeAreaView
        style={{
          flex: 1,
          backgroundColor: C.WHITE,
        }}>
        <View style={{ flex: 1 }}>
          <KeyboardAwareScrollView
            innerRef={(node) => {
              scrollViewRef.current = node;
            }}
            enableOnAndroid
            enableAutomaticScroll
            extraScrollHeight={180}
            keyboardOpeningTime={0}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ flexGrow: 1 }}
            refreshControl={
              onRefresh ? (
                <RefreshControl
                  refreshing={refreshing}
                  onRefresh={handleRefresh}
                  colors={[C.PRIMARY1]}
                />
              ) : null
            }>
            {children}
          </KeyboardAwareScrollView>
        </View>
      </SafeAreaView>
    );
  },
);

export default KeyboardAvoidScrollingTemplate;