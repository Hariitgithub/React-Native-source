/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import { SCREEN_HEIGHT, SCREEN_WIDTH } from '../../Utils/Constants';
import { C } from '../../Utils/ColorFonts';
import { SafeAreaView } from 'react-native-safe-area-context';
import BottomNavigator from '../../Screens/Common/BottomNavigator';
import { StatusBar, View } from 'react-native';

const Template = ({ children }) => {
  console.log('Template Rendering');
  return (
    <SafeAreaView
      style={{
        flex: 1,
        width: SCREEN_WIDTH,
        height: SCREEN_HEIGHT,
        backgroundColor: C.WHITE,
        position: 'relative',
      }}
    >
      {children}
      <View style={{
        position: 'absolute',
        bottom: 0,
        width: SCREEN_WIDTH,
        backgroundColor: C.WHITE,
      }}>
        <BottomNavigator />
      </View>
    </SafeAreaView>
  );
};

export default Template;
