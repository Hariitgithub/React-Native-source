import { Platform } from 'react-native';
import { PERMISSIONS, request } from 'react-native-permissions';

export const requestCameraPermission = async () => {
  let permission =
    Platform.OS === 'ios' ? PERMISSIONS.IOS.CAMERA : PERMISSIONS.ANDROID.CAMERA;

  try {
    const result = await request(permission);
    if (result === 'granted' || result === 'limited') {
      return true;
    } else {
      return false;
    }
  } catch (error) {
    console.warn('Permission error:', error);
    return false;
  }
};
