import { Platform } from 'react-native';
import { PERMISSIONS, request } from 'react-native-permissions';

export const requestImagePermission = async () => {
  let permission;
  try {
    if (Platform.OS === 'android') {
      permission =
        Platform.Version >= 33
          ? PERMISSIONS.ANDROID.READ_MEDIA_IMAGES
          : PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE;

      const result = await request(permission);

      if (result === 'granted' || result === 'limited') {
        return true;
      } else {
        return false;
      }
    }
  } catch (error) {
    console.log('error while asking file access permission', error);
    return false;
  }
  return true; // iOS doesn't need permission for this
};
