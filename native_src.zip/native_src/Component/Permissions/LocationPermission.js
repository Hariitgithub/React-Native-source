import { PermissionsAndroid, Platform } from 'react-native';
import { PERMISSIONS, request } from 'react-native-permissions';

export const requestLocationPermission = async () => {
  try {
    if (Platform.OS === 'ios') {
      const result = await request(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE);
      console.log('iOS Location Permission:', result);
      if (result === 'granted' || result === 'limited') {
        return true;
      } else {
        return false;
      }
    } else {
      const result = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      );
      //   console.log('Android Location Permission:', result);
      if (result === 'granted') {
        return true;
      } else {
        return false;
      }
    }
  } catch (error) {
    console.log('error in location permission');
    return false;
  }
};
