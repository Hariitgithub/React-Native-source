/* eslint-disable react-native/no-inline-styles */
import { StyleSheet, Text, TextInput, View } from 'react-native';
import React from 'react';
import { C, F } from '../../Utils/ColorFonts';
import { HS, MS, VS } from '../../Utils/FontSize';
import Img from '../img/Img';
Text.defaultProps = Text.defaultProps || {};
Text.defaultProps.allowFontScaling = false;

TextInput.defaultProps = TextInput.defaultProps || {};
TextInput.defaultProps.allowFontScaling = false;
const InputComponent = ({
  ref,
  onChangeText,
  customInputStyle,
  customContainerStyle,
  placeholder,
  value,
  editable,
  placeholderTextColor,
  readOnly,
  secureTextEntry,
  keyboardType,
  multiline,
  numberOfLines,
  ErrorText,
  align,
  inputColor,
  maxLength,
  cursorColor,
  autoFocus,
  title,
  titleColor,
  mt,
  mb,
  important,
  countryCode,
  img,
  mv,
  mh,
  ps,
  pe,
  pv,
  ms,
  me,
  ph,
  height,
  width,

}) => {
  return (
    <View
      style={[
        styles.Container,
        { marginBottom: VS(mb), marginTop: VS(mt) },
        customContainerStyle,
      ]}
    >
      {title && (
        <Text
          style={{
            marginBottom: VS(10),
            color: titleColor ?? C.TEXT,
            fontSize: MS(14),
            fontFamily: F.f3,
            marginTop: VS(10),
          }}
          allowFontScaling={false}
        >
          {title}
          {important && (
            <Text
              style={{ color: C.RED, textAlignVertical: 'top' }}
              allowFontScaling={false}
            >
              {' '}
              *
            </Text>
          )}
        </Text>
      )}
      <View
        style={[
          styles.innerInputbox,
          { marginVertical: mv ? VS(mv) : 0 },
          { marginVertical: mv ? VS(mv) : 0 },
          { marginLeft: ms ? VS(ms) : 0 },
          { marginRight: me ? VS(me) : 0 },
          { paddingHorizontal: ph ? VS(ph) : VS(0) },
          { paddingVertical: pv ? VS(pv) : VS(0) },
          { paddingLeft: ps ? VS(ps) : 0 },
          { paddingRight: pe ? VS(pe) : 0 },
          { width: width ? width : '100%' },
          { height: height }
        ]}>
        {countryCode && (
          <View style={styles.countryCode}>
            <Text
              style={{
                fontSize: MS(16),
                fontFamily: F.f1,
                color: C.INPUT,
                textAlign: 'center',
              }}
              allowFontScaling={false}
            >
              {countryCode}
            </Text>
          </View>
        )}
        <TextInput
          autoFocus={autoFocus}
          cursorColor={cursorColor ?? C.PRIMARY1}
          ref={ref}
          allowFontScaling={false}
          style={[
            styles.inputContainer,
            styles.shadow,
            {
              height: VS(multiline ? 120 : 51),
              color: inputColor ?? readOnly ? C.READ_ONLY_TEXT : C.INPUT,
              paddingLeft: HS(countryCode ? 60 : 15),
              fontSize: MS(16),
              width: img ? null : '100%',
            },
            customInputStyle,
          ]}
          placeholder={placeholder}
          placeholderTextColor={placeholderTextColor ?? C.TEXT}
          onChangeText={e => {
            onChangeText?.(e);
          }}
          textAlign={align ?? 'left'}
          textAlignVertical={multiline ? 'top' : 'center'}
          value={value}
          keyboardType={keyboardType === 'number' ? 'numeric' : 'default'}
          editable={editable}
          readOnly={readOnly}
          secureTextEntry={secureTextEntry}
          multiline={multiline}
          numberOfLines={numberOfLines}
          maxLength={maxLength}
        />
        {img && <Img src={img} width={22} height={22} />}
      </View>
      {ErrorText && (
        <Text style={styles.ErrorText} allowFontScaling={false}>
          * {ErrorText} *
        </Text>
      )}
    </View>
  );
};

export default InputComponent;

const styles = StyleSheet.create({
  Container: { paddingBottom: VS(15) },
  inputContainer: {
    fontFamily: F.f1,
    fontSize: MS(16),
    paddingRight: HS(15),
    borderRadius: MS(15),
  },
  countryCode: {
    position: 'absolute',
    height: VS(50),
    width: HS(70),
    zIndex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: C.BORDER,
    borderRadius: MS(15),
    borderRightWidth: 0,
    borderTopRightRadius: 0,
    borderBottomRightRadius: 0,
  },
  ErrorText: {
    color: C.RED,
    fontSize: MS(12),
    fontFamily: F.f3,
    textAlign: 'right',
    position: 'absolute',
    right: 0,
    bottom: 0,
  },
  shadow: {
    backgroundColor: '#FFFFFF',
    shadowColor: '#E4E5E73D',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5, // For Android
  },
  innerInputbox: {
    borderRadius: MS(15),
    borderColor: '#ccc',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: C.BORDER,
    height: VS(51),
    color: C.INPUT,
  },
});
