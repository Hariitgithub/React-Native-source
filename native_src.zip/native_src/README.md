# npm

[**paste the below line in the command prompt**]

    npm i @react-native-community/netinfo @react-navigation/native @react-navigation/native-stack @reduxjs/toolkit lottie-react-native react-native-reanimated react-native-safe-area-context react-native-screens react-native-worklets
    react-redux react-native-mmkv react-native-shimmer-placeholder react-native-linear-gradient

# APP.tsx

[**Replace the File with below code**]

import { StatusBar, StyleSheet, useColorScheme } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Provider, useSelector } from 'react-redux';
import store from './src/Redux/store/store';
import NoInternet from './src/Component/NoInternet/NoInternet';
import { useNetInfo } from '@react-native-community/netinfo';
import { NavigationContainer } from '@react-navigation/native';
import AlertComp from './src/Component/modal/AlertComp';
import { useRef } from 'react';
import StackNavigator from './src/Component/Navigator/StackNavigator';

const AppContent = () => {
const isDarkMode = useColorScheme() === 'dark';
const navigationRef = useRef(null);
const alert = useSelector(state => state?.alertMessage);
const netInfo = useNetInfo();

return (
<SafeAreaProvider style={styles.container}>
{netInfo.isConnected ? (
<>
{alert?.msg && <AlertComp navi={navigationRef.current} />}
<StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
<NavigationContainer ref={navigationRef}>
<StackNavigator />
</NavigationContainer>
</>
) : (
<NoInternet />
)}
</SafeAreaProvider>
);
};

const App = () => {
return (
<Provider store={store}>
<AppContent />
</Provider>
);
};

const styles = StyleSheet.create({
container: {
flex: 1,
},
});

export default App;

# libraries

# localStorage = react-native mmkv

we used the react-native mmkv for asyncStorage import **mmkvStorage** from the Constants
`storing data` mmkvStorage.set('keyname',value)
`fetching data` mmkvStorage.getstring('keyname')

refer The react native mmmkv here `https://github.com/mrousavy/react-native-mmkv?tab=readme-ov-file#readme`

//To save data in mmkv

// String
mmkvStorage.set('username', 'JohnDoe')

// Number
mmkvStorage.set('age', 25)

// Boolean
mmkvStorage.set('isLoggedIn', true)

// Object / Array (convert to JSON)
const user = { id: 1, name: 'John', skills: ['React', 'Node'] }
mmkvStorage.set('user', JSON.stringify(user))

//To get data in mmkv

// String
const username = mmkvStorage.getString('username')

// Number
const age = mmkvStorage.getNumber('age')

// Boolean
const isLoggedIn = mmkvStorage.getBoolean('isLoggedIn')

// Object
const userStr = mmkvStorage.getString('user') ?? '{}'
const user = userStr ? JSON.parse(userStr) : null

//To delete specific data in mmkv
mmkvStorage.delete('username')

//To clear entire data in mmkv
mmkvStorage.clearAll()

//To verify
const exists = storage.contains('username') // true/false

//To get all keys
const keys = storage.getAllKeys()
console.log(keys) // ['username', 'age', 'isLoggedIn', 'user']
