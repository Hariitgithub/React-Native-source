/* eslint-disable react-native/no-inline-styles */
/* eslint-disable react-hooks/exhaustive-deps */
import { Linking, Platform, StyleSheet, View } from 'react-native';
import React, { useEffect } from 'react';
import { CommonActions, useNavigation } from '@react-navigation/native';
import Img from '../../Component/img/Img';
import { logo } from '../../assets/images/imgIndex';
import { mmkvStorage, SCREEN_HEIGHT, SCREEN_WIDTH } from '../../Utils/Constants';
import LinearGradient from 'react-native-linear-gradient';

const SplashScreen = () => {
  const navigation = useNavigation();
  const token = mmkvStorage.getString('token');

  useEffect(() => {
    const init = async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));

      await navigateTo();
    };

    init();
  }, []);

  const navigateTo = async () => {
    const initialUrl = await Linking.getInitialURL();

    const hasDeepLink = !!initialUrl;
    const isLoggedIn = !!token;

    if (hasDeepLink && !isLoggedIn) {

      navigation.dispatch(
        CommonActions.reset({
          index: 1,
          routes: [{ name: 'home' }, { name: 'login' }],
        }),
      );
      return;
    }

    if (isLoggedIn || Platform.OS == "ios") {
      // User is logged in → go straight to home
      navigation.dispatch(
        CommonActions.reset({
          index: 0,
          routes: [{ name: 'home' }],
        }),
      );
    } else {
      // No token → go to login
      navigation.dispatch(
        CommonActions.reset({
          index: 0,
          routes: [{ name: 'login' }],
        }),
      );
    }
  };

  return (
    <View style={{ flex: 1 }}>
      <LinearGradient
        style={styles.container}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        colors={['#ffffff', '#ffffff']}
      >
        <Img
          src={logo}
          height={SCREEN_HEIGHT}
          width={SCREEN_WIDTH / 1.2}
          resize={'contain'}
        />
      </LinearGradient>
    </View>
  );
};

export default SplashScreen;

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
});
