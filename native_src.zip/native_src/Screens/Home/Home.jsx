import { StyleSheet, Text, View } from 'react-native'
import React from 'react';
import Template from '../../Component/Template/Template';
import Word from '../../Component/Word/Word';
import { SCREEN_HEIGHT } from '../../Utils/Constants';
import { C } from '../../Utils/ColorFonts';

const Home = () => {
    return (
        <Template>
            <View style={styles.container}>
                <Word text={'home'} />
            </View>
        </Template>
    )
}

export default Home;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: C.WHITE,
    },
})