/* eslint-disable react-native/no-inline-styles */
/* eslint-disable eqeqeq */
import { Image, StyleSheet, TouchableOpacity, View } from 'react-native';
import React from 'react';
import {
  StackActions,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { mmkvStorage, SCREEN_WIDTH } from '../../Utils/Constants';
import Img from '../../Component/img/Img';
import { C } from '../../Utils/ColorFonts';
import { MS, VS } from '../../Utils/FontSize';
import {
  bookings,
  notification,
  homeIocn,
  profilePic,
} from '../../assets/images/imgIndex';

const BottomNavigator = () => {
  const bottomNav = [
    { id: 1, icon: homeIocn, navigation: 'home' },
    {
      id: 2,
      icon: bookings,
      navigation: 'Booking',
    },
    { id: 3, icon: notification, navigation: 'Filter' },
    { id: 5, icon: profilePic, navigation: 'profile' },
  ];
  const navigation = useNavigation();

  const route = useRoute();

  // const handleClick = routename => {
  //   let tempUser = {};
  //   try {
  //     tempUser = JSON.parse(mmkvStorage.getString('user') ?? '{}');
  //   } catch (e) {
  //     console.log('BottomNavigator User Parse Error:', e);
  //   }

  //   if (
  //     !tempUser?.id &&
  //     (routename === 'Booking' || routename === 'wishlist')
  //   ) {
  //     navigation.navigate('login');
  //     return;
  //   }
  //   const previousRoutes = navigation.getState();
  //   let alreadyavailable = previousRoutes?.routes?.some(
  //     item => item.name == routename,
  //   );

  //   if (alreadyavailable) {
  //     navigation.dispatch(StackActions.popTo(routename));
  //   } else navigation.navigate(routename); // Navigate to item's screen
  // };


  const handleClick = routename => {
    navigation.navigate(routename);
  };


  return (
    <View style={styles.Container}>
      <View style={styles.IconContainer}>
        {bottomNav?.map(item => {
          return (
            <TouchableOpacity
              activeOpacity={0.8}
              key={item?.id}
              onPress={() => handleClick(item.navigation)}
              style={{
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <View
                style={{
                  padding: MS(10),
                  // backgroundColor:
                  //   route?.name == item?.navigation ? C.PURPLE_BORDER : C.WHITE,
                }}
              >


                <Img
                  src={item?.icon}
                  width={25}
                  height={25}
                  resize={'contain'}
                  color={route?.name == item?.navigation ? C.PRIMARY1 : C.TEXT_3}
                />
              </View>

            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
};

export default BottomNavigator;

const styles = StyleSheet.create({
  Container: {
    width: SCREEN_WIDTH,
    zIndex: 99,
    backgroundColor: '#ffffff',
    showdowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  IconContainer: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    paddingVertical: VS(10),
  },
});
