/* eslint-disable react-native/no-inline-styles */
import { Image, StyleSheet, TouchableOpacity, View } from 'react-native';
import React, { useState } from 'react';
import { HS, MS, VS } from '../../Utils/FontSize';
import { calenderImg, thin_arrow } from '../../assets/images/imgIndex';
import Word from '../../Component/Word/Word';
import { useNavigation } from '@react-navigation/native';
import { commonStyles } from '../../assets/style/CommonStyles';
import DatePicker from '../../Component/DatePicker/DatePicker';
import dayjs from 'dayjs';

const CalenderHeader = ({ hideBack, name, mt, mb, onSelect, date }) => {
  const navigation = useNavigation();
  const [show, setShow] = useState(false);
  return (
    <View style={styles.main}>
      <View
        style={[
          styles.Container,
          {
            marginTop: VS(mt),
            marginBottom: VS(mb),
          },
        ]}
      >
        {!hideBack && (
          <TouchableOpacity
            activeOpacity={0.8}
            hitSlop={{
              bottom: VS(10),
              top: VS(10),
              left: HS(10),
              right: HS(10),
            }}
            onPress={() => {
              navigation.goBack();
            }}
          >
            <Image
              source={{ uri: thin_arrow }}
              style={styles.arrowImg}
              resizeMode="contain"
            />
          </TouchableOpacity>
        )}
        {name && (
          <Word
            text={name}
            size={26}
            font={2}
            color={'black'}
            alignVertical={'center'}
          />
        )}
      </View>
      <TouchableOpacity
        onPress={() => setShow(true)}
        activeOpacity={0.8}
        style={[
          commonStyles.shadow,
          {
            marginRight: HS(25),
            height: VS(60),
            width: HS(60),
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: MS(10),
          },
        ]}
        hitSlop={{
          top: VS(20),
          bottom: VS(20),
          left: HS(20),
          right: HS(20),
        }}
      >
        <Image
          source={{ uri: calenderImg }}
          style={styles.calImg}
          resizeMode="contain"
        />
      </TouchableOpacity>

      <DatePicker
        showPicker={show}
        setShowPicker={setShow}
        onSelect={d => {
          onSelect?.(dayjs(d).format('YYYY-MM-DD'));
          setShow(false);
        }}
        hidePastDates={true}
        value={date}
      />
    </View>
  );
};

export default React.memo(CalenderHeader);

const styles = StyleSheet.create({
  Container: {
    height: VS(80),
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingHorizontal: '3%',
    backgroundColor: '#fff',
  },
  arrowImg: {
    height: VS(25),
    width: HS(25),
    tintColor: '#000',
    marginRight: HS(20),
  },
  calImg: {
    height: VS(45),
    width: HS(45),
    // marginRight: HS(25)
  },
  main: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
