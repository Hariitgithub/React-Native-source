import { Image, StyleSheet, TouchableOpacity, View } from 'react-native';
import React from 'react';
import { HS, VS } from '../../Utils/FontSize';
import { leftArrow } from '../../assets/images/imgIndex';
import Word from '../../Component/Word/Word';
import { useNavigation } from '@react-navigation/native';
import Img from '../../Component/img/Img';
import { SCREEN_WIDTH } from '../../Utils/Constants';
import { C } from '../../Utils/ColorFonts';

const Header = ({
  hideBack,
  name,
  mt,
  mb,
  backFunc,
  bgNeed = true,
  wordColor = 'black',
  rightbtn,
}) => {
  const navigation = useNavigation();
  return (
    <View>
      <View
        style={[
          styles.Container,
          {
            marginTop: VS(mt),
            marginBottom: VS(mb),
            backgroundColor: bgNeed ? C.PRIMARY1 : 'none',
          },
        ]}
      >
        {!hideBack && (
          <TouchableOpacity
            activeOpacity={0.8}
            hitSlop={{
              bottom: VS(10),
              top: VS(10),
              left: HS(10),
              right: HS(10),
            }}
            onPress={() => {
              if (typeof backFunc === 'function') backFunc?.();
              else navigation.goBack();
            }}
          >
            <Img
              src={leftArrow}
              style={[styles.arrowImg, { tintColor: wordColor || '#000' }]}
              resize="contain"
            />

          </TouchableOpacity>
        )}
        {name && (
          <Word
            text={name}
            size={20}
            font={2}
            color={wordColor || '#000'}
            alignVertical={'center'}
          />
        )}
        {rightbtn ? (rightbtn) : (
          <View style={{ width: HS(30) }} />
        )}
      </View>
    </View>
  );
};

export default Header;

const styles = StyleSheet.create({
  Container: {
    width: SCREEN_WIDTH,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: '3%',
    paddingVertical: VS(10),
  },
  arrowImg: {
    height: VS(20),
    width: HS(20),
    marginRight: HS(20),
  },
});
