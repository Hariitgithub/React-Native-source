import RazorpayCheckout from 'react-native-razorpay';
import { C } from '../../Utils/ColorFonts';
import {
  handlePaymentFailure,
  mmkvStorage,
  RAZORPAY_KEY,
} from '../../Utils/Constants';
import { post } from '../../Redux/apiRequest/ApiHandler';
import { URLS } from '../../Redux/apiRequest/Constant';

let additionalpayload = null;

export const razorpayPayment = async (
  d,
  extraPayload,
  setBookingDetailsLoader,
  setLoader,
  razpayKey,
) => {
  console.log('razpayKey', razpayKey, d.razorpay_key);

  additionalpayload = extraPayload;
  let user = JSON.parse(mmkvStorage.getString('user') ?? '{}');
  var options = {
    description: 'Booking',
    image:
      'https://test-iye.blr1.digitaloceanspaces.com/images/Vow-Square-logo.jpg',
    currency: 'INR',
    key: d.razorpay_key,
    amount: Number(d?.amount),
    name: 'Vow',
    order_id: d?.order_id,
    prefill: {
      email: user?.email,
      contact: user?.mobile,
      name: user?.name,
    },
    theme: { color: C.PRIMARY },
    timeout: 600,
  };
  try {
    const data = await RazorpayCheckout.open(options);
    console.log('confirm payment', data);
    const confirmRes = await confirmPayment({
      ...data,
      transaction_id: d?.transaction_id,
    });
    return {
      status: confirmRes?.status,
      message: confirmRes.message,
    };
  } catch (error) {
    console.log(
      'confirm payment error',
      error,
      d?.transaction_id,
      extraPayload,
      setBookingDetailsLoader,
      setLoader,
    );
    handlePaymentFailure(d?.transaction_id);
    return {
      status: 'error',
      error: error,
      message: error?.error?.reason ?? 'Failed While Processing Payment',
    };
  }
};

const confirmPayment = async ({
  razorpay_order_id,
  razorpay_payment_id,
  razorpay_signature,
  transaction_id,
}) => {
  var payload = {
    razorpay_order_id: razorpay_order_id,
    razorpay_payment_id: razorpay_payment_id,
    transaction_id: transaction_id,
    razorpay_signature: razorpay_signature,
  };
  if (additionalpayload) payload = { ...payload, ...additionalpayload };

  const res = await post(URLS.VERIFY_BOOKING_PAYMENT, payload);
  console.log('res?.status');
  return res;
  // if (res?.status === 'pending') {
  //   return res;
  // }
  // if (res?.status === 'success') {
  //   return res;
  // } else {
  //   return { status: 'error', error: 'Error Accured While Verifying Payment' };
  // }
};
