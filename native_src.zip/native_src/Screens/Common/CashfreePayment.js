import { CFPaymentGatewayService } from 'react-native-cashfree-pg-sdk';
// MUST import builder classes from the contract package, not the core SDK
import {
  CFDropCheckoutPayment,
  CFEnvironment,
  CFPaymentComponentBuilder,
  CFPaymentModes,
  CFSession,
  CFThemeBuilder,
} from 'cashfree-pg-api-contract';

import { C } from '../../Utils/ColorFonts';
import { post } from '../../Redux/apiRequest/ApiHandler';
import { URLS } from '../../Redux/apiRequest/Constant';
import { handlePaymentFailure } from '../../Utils/Constants';

let additionalpayloadCF = null;

export const cashfreePayment = (d, extraPayload) => {
  console.log('SDKASKDKSADK', d);

  return new Promise(resolve => {
    additionalpayloadCF = extraPayload;

    const paymentSessionId = d?.cashfree_payment_session_id;
    const orderId = d?.order_id;

    if (!paymentSessionId || !orderId) {
      resolve({
        status: 'error',
        message: 'Missing Cashfree session ID or Order ID from backend.',
      });
      return;
    }

    try {
      // const env = ;
      //
      const env =
        d.razorpay_key == 'sandbox'
          ? CFEnvironment.SANDBOX
          : CFEnvironment.PRODUCTION;
      console.log(
        'envenv',
        env,
        d.razorpay_key == 'sandbox',
        d.razorpay_key,
        d,
      );

      const session = new CFSession(paymentSessionId, orderId, env);

      const theme = new CFThemeBuilder()
        .setNavigationBarBackgroundColor(C.PRIMARY || '#6200EE')
        .setNavigationBarTextColor('#FFFFFF')
        .setButtonBackgroundColor(C.PRIMARY || '#6200EE')
        .setButtonTextColor('#FFFFFF')
        .setPrimaryTextColor('#212121')
        .setSecondaryTextColor('#757575')
        .build();

      const paymentComponent = new CFPaymentComponentBuilder()
        .add(CFPaymentModes.UPI)
        .add(CFPaymentModes.CARD)
        .add(CFPaymentModes.NB)
        .add(CFPaymentModes.WALLET)
        .build();

      const dropPayment = new CFDropCheckoutPayment(
        session,
        paymentComponent,
        theme,
      );

      CFPaymentGatewayService.setCallback({
        onVerify: async cfOrderId => {
          console.log('Cashfree payment success, verifying...', cfOrderId);
          CFPaymentGatewayService.removeCallback();
          const confirmRes = await confirmCashfreePayment({
            cashfree_order_id: cfOrderId,
            transaction_id: d?.transaction_id,
          });
          console.log('DASDASDASd', confirmRes);
          resolve({
            status: confirmRes?.status,
            message: confirmRes?.message || 'Payment Successful',
          });
        },
        onError: (error, cfOrderId) => {
          console.log('Cashfree payment failed', error, cfOrderId);
          CFPaymentGatewayService.removeCallback();
          handlePaymentFailure(d?.transaction_id);

          resolve({
            status: 'error',
            error: error,
            message:
              error?.message ?? 'Failed While Processing Cashfree Payment',
          });
        },
      });

      // 7. Trigger the SDK
      CFPaymentGatewayService.doPayment(dropPayment);
    } catch (error) {
      console.log('Cashfree SDK setup error:', error);
      handlePaymentFailure(d?.transaction_id);

      resolve({
        status: 'error',
        error: error,
        message: 'Failed to initialize Cashfree SDK',
      });
    }
  });
};

const confirmCashfreePayment = async ({
  cashfree_order_id,
  transaction_id,
}) => {
  // backend common key like razer pay
  let payload = {
    razorpay_order_id: cashfree_order_id,
    transaction_id: transaction_id,
    //razorpay_payment_id:
    // razorpay_signature:
  };

  if (additionalpayloadCF) {
    payload = { ...payload, ...additionalpayloadCF };
  }

  console.log('cashfree VERIFY_BOOKING_PAYMENT payload', payload);

  try {
    const res = await post(URLS.VERIFY_BOOKING_PAYMENT, payload);
    console.log('SDLSADLASLDSALDa', res);
    return res;
  } catch (err) {
    return {
      status: 'error',
      message: 'Error Occurred While Verifying Payment',
    };
  }
};
