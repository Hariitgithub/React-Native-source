import React, { useCallback, useState } from 'react';
import {
    StyleSheet,
    View,
    TouchableOpacity,
    FlatList,
} from 'react-native';
import KeyboardAvoidScrollingTemplate from '../../Component/Template/KeyboardAvoidScrollingTemplate';
import Header from '../Common/Header';
import Img from '../../Component/img/Img';
import Word from '../../Component/Word/Word';
import { C } from '../../Utils/ColorFonts';
import { MS, VS } from '../../Utils/FontSize';
import {
    addHome,
    officeBag,
    personal,
    rightArrow,
    phoneIcon,
    pickUpCode,
    connection,
    walletIcon,
    docs,
} from '../../assets/images/imgIndex';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { get } from '../../Redux/apiRequest/ApiHandler';
import { URLS } from '../../Redux/apiRequest/Constant';

const Profile = () => {
    const navigation = useNavigation();

    const [formData, setFormData] = useState({
        name: '',
        mobile: '',
        profile_image: '',
    });

    const getData = async () => {
        const res = await get(URLS.VIEW_PROFILE);

        if (res?.data) {
            setFormData({
                name: res.data?.name,
                mobile: res.data?.mobile,
                profile_image: res.data?.profile_image,
            });
        }
    };

    useFocusEffect(
        useCallback(() => {
            getData();
        }, []),
    );

    const sections = [
        {
            title: 'Account',
            data: [
                {
                    title: 'Personal Profile',
                    icon: personal,
                    navigateTo: 'profileView',
                },
                {
                    title: 'Document & Vehicle',
                    icon: docs,
                    navigateTo: 'documentDetails',
                },
                {
                    title: 'Refer & Earn',
                    icon: connection,
                    navigateTo: 'myReferral',
                },
                {
                    title: 'Wallet',
                    icon: walletIcon,
                    navigateTo: 'wallet',
                },
            ],
        },
        {
            title: 'Address',
            data: [
                {
                    title: 'Favourite Address',
                    icon: addHome,
                    navigateTo: 'favouriteAccount',
                },

            ],
        },
        {
            title: 'Trip Safety',
            data: [
                {
                    title: 'Emergency Contacts',
                    icon: phoneIcon,
                    navigateTo: 'emergencyContact',
                },
                {
                    title: 'Pick Up Code',
                    icon: pickUpCode,
                    navigateTo: 'enableOTP',
                },
            ],
        },
    ];

    const renderRow = ({ item }) => (
        <TouchableOpacity
            activeOpacity={0.8}
            style={styles.row}
            onPress={() =>
                item.navigateTo && navigation.navigate(item.navigateTo)
            }>
            <View style={styles.left}>
                <Img
                    src={item.icon}
                    width={20}
                    height={20}
                    color={C.BLACK}
                />

                <Word
                    text={item.title}
                    ml={15}
                />
            </View>

            <Img
                src={rightArrow}
                width={18}
                height={18}
            />
        </TouchableOpacity>
    );

    const renderSection = ({ item }) => (
        <View>
            <View style={styles.sectionHeader}>
                <Word
                    text={item.title}
                />
            </View>

            <View style={styles.card}>
                <FlatList
                    data={item.data}
                    keyExtractor={(i, idx) => idx.toString()}
                    renderItem={renderRow}
                    scrollEnabled={false}
                />
            </View>
        </View>
    );

    const renderHeader = () => (
        <View style={styles.profileContainer}>
            <Img
                src={
                    formData.profile_image
                        ? { uri: formData.profile_image }
                        : {
                            uri: 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png',
                        }
                }
                width={100}
                height={100}
                radius={50}
                resize="cover"
            />

            <Word
                text={formData.name || 'SATHISH R'}
                mt={12}
                font={2}
            />

            <Word
                text={formData.mobile || 'xxx xxx xxxx'}
                mt={5}
                font={1}
                color="#666"
            />
        </View>
    );

    return (
        <>
            <Header name="Profile" />
            <KeyboardAvoidScrollingTemplate>
                <View style={styles.container}>
                    <FlatList
                        data={sections}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={renderSection}
                        ListHeaderComponent={renderHeader}
                        showsVerticalScrollIndicator={false}
                        contentContainerStyle={styles.contentContainer}
                    />
                </View>
            </KeyboardAvoidScrollingTemplate>
        </>
    );
};

export default Profile;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: C.WHITE,
    },

    contentContainer: {
        paddingBottom: VS(30),
    },

    profileContainer: {
        alignItems: 'center',
        marginTop: VS(20),
        marginBottom: VS(20),
    },

    sectionHeader: {
        backgroundColor: '#F2F2F2',
        paddingHorizontal: MS(20),
        paddingVertical: MS(10),
    },

    card: {
        backgroundColor: C.WHITE,
        marginBottom: VS(10),
    },

    row: {
        height: 55,
        paddingHorizontal: MS(18),
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },

    left: {
        flexDirection: 'row',
        alignItems: 'center',
    },
});