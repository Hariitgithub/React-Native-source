import React, { useEffect, useState } from 'react';
import {
    StyleSheet,
    View,
    FlatList,
    TouchableOpacity,
    Image,
    Pressable,
} from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';
import KeyboardAvoidScrollingTemplate from '../../Component/Template/KeyboardAvoidScrollingTemplate';
import Word from '../../Component/Word/Word';
import { get, post } from '../../Redux/apiRequest/ApiHandler';
import { URLS } from '../../Redux/apiRequest/Constant';
import { C } from '../../Utils/ColorFonts';
import Header from '../Common/Header';
import Img from '../../Component/img/Img';
import { checks, editText, upload } from '../../assets/images/imgIndex';
import { HS, MS, VS } from '../../Utils/FontSize';
import CommonButton from '../../Component/Buttons/CommonButton';
import { Toast } from '../../Utils/Constants';
import ImagePreviewModal from '../../Component/modal/ImagePreviewModal';

const MAX_IMAGES = 5;

const Documents = () => {
    const [documents, setDocuments] = useState([]);
    const [editable, setEditable] = useState(false);
    const [editable2, setEditable2] = useState(false);
    const [loader, setLoader] = useState(false);
    const [imagePreview, setImagePreview] = useState(false);
    const [image, setImage] = useState(null);

    useEffect(() => {
        getData();
    }, []);


    const getData = async () => {
        try {
            const res = await get(URLS.GETDOCUMENT);
            const isInitialUpload = res?.data?.some(item => item.uploaded);

            console.log("isInitialUpload", isInitialUpload);

            if (!isInitialUpload) {
                setEditable(true);
                setEditable2(false);
            }

            if (!res?.data) return;


            const formatted = res.data.map(item => {
                let files = [];

                // API returns array
                if (Array.isArray(item.file)) {
                    files = item.file;
                }
                else if (typeof item.file === "string") {
                    try {
                        files = JSON.parse(item.file);
                    } catch (e) {
                        files = [item.file];
                    }
                }

                const images = files.map(url => ({
                    uri: String(url).replace(/\\\//g, "/"),
                    type: "image/jpeg",
                    fileName: url.split("/").pop(),
                    isUploaded: true,
                }));

                return {
                    ...item,
                    images,
                };
            });

            console.log("formatted =>", formatted);

            setDocuments(formatted);
        } catch (err) {
            console.log(err);
        }
    };

    const pickImage = (index) => {
        launchImageLibrary(
            {
                mediaType: 'photo',
                selectionLimit: 1,
            },
            response => {
                if (response.didCancel || response.errorCode) {
                    return;
                }

                const image = response.assets?.[0];

                if (!image) return;

                setDocuments(prev => {
                    const data = [...prev];

                    if (data[index].images.length >= MAX_IMAGES) {
                        return data;
                    }

                    data[index].images.push(image);

                    return [...data];
                });
            },
        );
    };

    const removeImage = (docIndex, imgIndex) => {
        const temp = [...documents];
        temp[docIndex].images.splice(imgIndex, 1);
        setDocuments(temp);
    };


    const handleUpload = async () => {
        setLoader(true);
        try {
            const formData = new FormData();

            documents.forEach((doc, docIndex) => {
                if (doc.images.length > 0) {
                    // documents[0][document_id]
                    formData.append(
                        `documents[${docIndex}][document_id]`,
                        String(doc.id),
                    );

                    // documents[0][file][]
                    doc.images.forEach((image) => {
                        formData.append(
                            `documents[${docIndex}][file][]`,
                            {
                                uri: image.uri,
                                type: image.type || 'image/jpeg',
                                name:
                                    image.fileName ||
                                    `image_${Date.now()}.jpg`,
                            },
                        );
                    });
                }
            });

            // Debug
            console.log("formData", formData);

            const res = await post(
                `${URLS.GETDOCUMENT}/upload-document`,
                formData,
                {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    },
                },
            );

            if (res?.status) {
                setEditable(false);
                setEditable2(false);
                setLoader(false);
                Toast(res?.message || 'Upload Success');
                getData();
            } else {
                setLoader(false);
            }
        } catch (error) {
            setLoader(false);
            console.log('Upload Error:', error);
        }
    };

    const handleSingleUpload = async (item) => {
        try {
            if (!item?.id) {
                Toast('Document id missing');
                return;
            }

            if (!item?.images?.length) {
                Toast('Please select an image');
                return;
            }

            const formData = new FormData();

            formData.append('document_id', String(item.id));

            item.images.forEach((image) => {
                formData.append('file[]', {
                    uri: image.uri,
                    type: image.type || 'image/jpeg',
                    name:
                        image.fileName ||
                        image.name ||
                        `image_${Date.now()}.jpg`,
                });
            });

            console.log("singleformData", formData);


            const res = await post(
                `${URLS.GETDOCUMENT}/upload-single-document`,
                formData,
            );

            if (res?.status) {
                setEditable(false);
                setEditable2(false);
                Toast(res?.message || 'Upload Success');
                getData();
            }
        } catch (error) {
            console.log('Single Upload Error:', error);
        }
    }

    const renderUploadSlots = (item, index) => {
        return (
            <View style={styles.imageContainer}>

                {item.images.map((img, imgIndex) => (
                    <Pressable onPress={() => { setImage(img.uri); setImagePreview(true) }} key={imgIndex} style={styles.imageWrapper}>
                        <Image
                            source={{ uri: img.uri }}
                            style={styles.image}
                        />
                        {editable &&
                            <TouchableOpacity
                                style={styles.remove}
                                onPress={() => removeImage(index, imgIndex)}>
                                <Word text="✕" size={10} color={C.WHITE} />
                            </TouchableOpacity>}
                    </Pressable>
                ))}

                {editable &&
                    item.images.length < MAX_IMAGES && (
                        <TouchableOpacity
                            style={styles.uploadBox}
                            onPress={() => pickImage(index)}
                        >
                            <Word text="+" size={30} color={C.PRIMARY} />
                        </TouchableOpacity>
                    )}

            </View>
        );
    };

    const renderItem = ({ item, index }) => (
        <View style={styles.card}>

            <Word
                text={item.document_type}
                size={16}
                font={3}
                color={C.BLACK}
            />

            <View style={styles.container}>

                {renderUploadSlots(item, index)}

                {editable2 ? (
                    <Pressable onPress={() => handleSingleUpload(item)} style={styles.uploadhandle}>
                        <Img src={upload} width={20} height={20} />
                    </Pressable>
                ) :
                    (<View style={styles.statusContainer}>

                        <View
                            style={[
                                styles.statusDot,
                                {
                                    backgroundColor: item?.status_text === 'Rejected' ? '#E74C3C' : item?.status_text === 'Accepted' ? '#39B54A' : C.YELLOW,
                                },
                            ]}>

                            {item?.status_text === 'Rejected' ? (
                                <Word text="✕" size={10} color={C.WHITE} />
                            ) : item?.status_text === 'Accepted' ? (
                                <Img
                                    src={checks}
                                    width={10}
                                    height={10}
                                />
                            ) : (<Word text="◯" size={14} color={C.WHITE} />)}

                        </View>

                        <Word
                            text={item?.status_text}
                            size={12}
                            color={C.BLACK}
                        />

                    </View>)}

            </View>

        </View>
    );


    return (
        <>
            <Header name={'Documents'} rightbtn={
                !editable &&
                <Pressable onPress={() => {
                    setEditable(true);
                    setEditable2(true);
                }}>
                    <Img src={editText} width={25} height={25} />
                </Pressable>
            } />
            <KeyboardAvoidScrollingTemplate onRefresh={() => {
                getData();
                setEditable(false);
                setEditable2(false);
            }} >
                <FlatList
                    data={documents}
                    keyExtractor={item => item.id.toString()}
                    renderItem={renderItem}
                    contentContainerStyle={{ padding: MS(15), paddingBottom: VS(70) }}
                />
                {editable && !editable2 &&
                    <View style={{ width: '100%', position: 'absolute', bottom: VS(0), padding: MS(25) }}>
                        <CommonButton
                            title={"Submit"}
                            onPress={handleUpload}
                            loader={loader}
                        />
                    </View>}
                <ImagePreviewModal
                    visible={imagePreview}
                    image={image}
                    onClose={() => setImagePreview(false)}
                />
            </KeyboardAvoidScrollingTemplate>
        </>
    );
};

export default Documents;

const styles = StyleSheet.create({
    card: {
        marginBottom: (20),
    },
    container: {
        backgroundColor: '#F5F5F5',
        borderRadius: 10,
        padding: 12,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',

    },
    imageContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        alignItems: 'center',
        flex: 1,
    },

    uploadBox: {
        width: HS(60),
        height: VS(60),
        borderRadius: MS(8),
        borderWidth: 1,
        borderStyle: 'dashed',
        borderColor: '#CFCFCF',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#FFF',
        marginRight: HS(10),
        marginBottom: VS(10),
    },
    uploadhandle: {
        width: HS(40),
        height: VS(40),
        borderRadius: MS(8),
        backgroundColor: C.WHITE,
        alignItems: 'center',
        justifyContent: 'center',
    },
    imageWrapper: {
        marginRight: HS(10),
        marginBottom: VS(10),
        position: 'relative',
    },

    image: {
        width: HS(60),
        height: VS(60),
        borderRadius: MS(8),
    },

    remove: {
        position: 'absolute',
        top: -6,
        right: -6,
        width: HS(18),
        height: VS(18),
        borderRadius: 20,
        backgroundColor: '#FF3B30',
        justifyContent: 'center',
        alignItems: 'center',
    },

    statusContainer: {
        alignItems: 'center',
        marginLeft: HS(10),
    },

    statusDot: {
        width: HS(22),
        height: VS(22),
        borderRadius: MS(11),
        marginBottom: VS(5),
        alignItems: 'center',
        justifyContent: 'center'
    },
});
