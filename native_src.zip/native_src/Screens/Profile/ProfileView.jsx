import { Pressable, StyleSheet, TouchableOpacity, View } from 'react-native'
import React, { useEffect, useState } from 'react';
import KeyboardAvoidScrollingTemplate from '../../Component/Template/KeyboardAvoidScrollingTemplate';
import Img from '../../Component/img/Img';
import { deleteIcon, editIcon, editText, leftArrow, logoutLogo, rightArrow } from '../../assets/images/imgIndex';
import { HS, MS, VS } from '../../Utils/FontSize';
import Word from '../../Component/Word/Word';
import InputComponent from '../../Component/InputComponent/InputComponent';
import CommonButton from '../../Component/Buttons/CommonButton';
import { useNavigation } from '@react-navigation/native';
import RadioBtn from '../../Component/Buttons/RadioBtn';
import Header from '../Common/Header';
import UploadImagePopup from '../../Component/modal/UploadImagePopup';
import { URLS } from '../../Redux/apiRequest/Constant';
import { get, post } from '../../Redux/apiRequest/ApiHandler';
import { mmkvStorage, Toast } from '../../Utils/Constants';
import LogoutModal from '../../Component/modal/LogoutModal';
import { C } from '../../Utils/ColorFonts';

const ProfileView = () => {
    const navigation = useNavigation();
    const [image, setImage] = useState(null);
    const [loader, setLoader] = useState(false);
    const [showUploadPopup, setShowUploadPopup] = useState(false);
    const [gender, setGender] = useState(1);
    const [editable, setEditable] = useState(false);
    const [openLogout, setOpenLogout] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        address: '',
    });

    const openModel = () => setOpenLogout(true);
    const hideModel = () => setOpenLogout(false);

    const getData = async () => {
        const res = await get(URLS.VIEW_PROFILE);
        const data = res?.data;
        if (res?.status) {
            setFormData({
                name: data?.name,
                email: data?.email,
                address: data?.address,
            });
            setGender(data?.gender);
            setImage({ uri: data?.profile_image });
        }
    }

    useEffect(() => {
        getData();
    }, []);

    const updateData = async () => {

        const payload = new FormData();

        payload.append('name', formData.name);
        payload.append('email', formData.email);
        payload.append('gender', gender);
        payload.append('address', formData.address);

        if (image?.uri) {
            payload.append('profile_image', {
                uri: image.uri,
                type: image.type || 'image/jpeg',
                name: image.name || image.fileName || 'profile.jpg',
            });
        }

        console.log('Payload:', payload);
        setLoader(true);

        const res = await post(URLS.VIEW_PROFILE, payload);
        if (res?.status) {
            setEditable(false);
            setLoader(false);
            Toast(res?.message);
        } else {
            setLoader(false);
        }
    }



    const handleImageSelect = data => {
        console.log('Selected Image:', data);
        setImage(data);
    };

    const handleLogout = async () => {
        const res = await post(URLS.LOGOUT);
        if (res?.status) {
            await mmkvStorage.clearAll();
            navigation.navigate('login');
        }
    }

    return (
        <KeyboardAvoidScrollingTemplate>
            <View style={{ width: '100%' }}>
                <Header name="Profile"
                    rightbtn={
                        <Pressable onPress={() => setEditable(true)}>
                            <Img src={editText} width={25} height={25} />
                        </Pressable>
                    }
                />
                <View style={styles.inputContainer}>
                    <View style={{ alignSelf: 'center', marginBottom: VS(30), position: 'relative', width: HS(110), }}>
                        <Img
                            src={
                                image?.uri
                                    ? { uri: image.uri }
                                    : {
                                        uri: 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png',
                                    }
                            }
                            width={100}
                            height={100}
                            radius={50}
                            resize="cover"
                        />
                        {editable &&
                            <Pressable onPress={() => setShowUploadPopup(true)} style={styles.imageContainer}>
                                <Img src={editIcon} width={20} height={20} />
                            </Pressable>}
                    </View>

                    <InputComponent
                        placeholder='Enter your name'
                        value={formData.name}
                        onChangeText={text => setFormData({ ...formData, name: text })}
                        readOnly={!editable}
                    />
                    <InputComponent
                        placeholder='Enter your email'
                        value={formData.email}
                        onChangeText={text => setFormData({ ...formData, email: text })}
                        readOnly={!editable}
                    />
                    <View style={styles.radioContainer}>
                        <RadioBtn
                            title="Male"
                            value={gender === 1}
                            onPress={() => setGender(1)}
                            readOnly={!editable}
                        />

                        <RadioBtn
                            title="Female"
                            value={gender === 2}
                            onPress={() => setGender(2)}
                            readOnly={!editable}
                        />
                        <RadioBtn
                            title="Others"
                            value={gender === 3}
                            onPress={() => setGender(3)}
                            readOnly={!editable}
                        />
                    </View>
                    <InputComponent
                        mt={20}
                        placeholder='Enter your address'
                        multiline
                        numberOfLines={4}
                        value={formData.address}
                        onChangeText={text => setFormData({ ...formData, address: text })}
                        readOnly={!editable}
                    />
                </View>
            </View>
            <View style={{ width: '100%', position: 'absolute', bottom: VS(0), padding: 25 }}>
                {editable &&
                    <CommonButton
                        title={'Save'}
                        onPress={updateData}
                        loader={loader}
                    />
                }

                {!editable &&
                    <>
                        <TouchableOpacity onPress={openModel} style={styles.row}>
                            <View style={styles.left}>
                                <Img
                                    src={logoutLogo}
                                    width={18}
                                    height={18}
                                />
                                <Word
                                    text="Log out"
                                    ml={15}
                                    size={16}
                                />
                            </View>
                            <Img
                                src={rightArrow}
                                width={18}
                                height={18}
                            />
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => navigation.navigate('deleteAccount')} style={styles.row}>
                            <View style={styles.left}>
                                <Img
                                    src={deleteIcon}
                                    width={18}
                                    height={18}
                                />
                                <Word
                                    text="Delete account"
                                    ml={15}
                                    size={16}
                                />
                            </View>
                            <Img
                                src={rightArrow}
                                width={18}
                                height={18}
                            />
                        </TouchableOpacity>
                    </>
                }
            </View>
            {showUploadPopup &&
                <UploadImagePopup
                    visible={showUploadPopup}
                    setImagePopup={setShowUploadPopup}
                    onSelect={handleImageSelect}
                />
            }
            <LogoutModal
                title="Are you sure you want to logout?"
                title_2="You will need to sign in again to access your account."
                visible={openLogout}
                onClose={hideModel}
                OnPressYes={handleLogout}
            />
        </KeyboardAvoidScrollingTemplate>
    )
}

export default ProfileView;

const styles = StyleSheet.create({
    header: {
        width: '100%',
        height: HS(40),
        paddingHorizontal: HS(15),
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    inputContainer: {
        width: '100%',
        paddingHorizontal: HS(15),
        marginTop: HS(20),
    },
    radioContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: VS(20),
        gap: HS(10),
    },
    imageContainer: {
        position: 'absolute',
        bottom: VS(-5), right: 0,
        backgroundColor: '#fff',
        borderRadius: 50, padding: 5
    },
    row: {
        height: VS(55),
        paddingHorizontal: MS(18),
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: C.PRIMARY1,
        borderRadius: MS(10),
        marginBottom: VS(10)
    },
    left: {
        flexDirection: 'row',
        alignItems: 'center',
    },
})