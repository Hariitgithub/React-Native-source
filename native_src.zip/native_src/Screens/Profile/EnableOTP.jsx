import { StyleSheet, Text, View } from 'react-native';
import React, { useState } from 'react';
import KeyboardAvoidScrollingTemplate from '../../Component/Template/KeyboardAvoidScrollingTemplate';
import Header from '../Common/Header';
import ToggleBtn from '../../Component/Buttons/ToggleBtn';
import Word from '../../Component/Word/Word';
import { MS, VS } from '../../Utils/FontSize';
import { C } from '../../Utils/ColorFonts';

const EnableOTP = () => {
    const [toggle, setToggle] = useState(false);

    const handleToggle = () => {
        setToggle(!toggle);
    }

    return (
        <>
            <Header name={'OTP'} />
            <KeyboardAvoidScrollingTemplate>
                <View style={{ padding: MS(20) }}>
                    <View style={{ gap: MS(20) }}>
                        <Word text={'Pick-up code'} size={16} />
                        <Word text={'Verify each trip by matching a unique code with your driver'} size={14} color={C.TEXT_2} />
                        <Word text={"Feel safer knowing you're in the right vehicle with the right driver"} size={14} color={C.TEXT_2} />
                        <Word text={"Prevent someone else from taking your ride by mistake"} size={14} color={C.TEXT_2} />
                    </View>
                    <View style={styles.toggleContainer}>
                        <ToggleBtn
                            activeToggleColor={C.WHITE}
                            activeSlideColor={C.PRIMARY1}
                            onPress={handleToggle}
                            value={toggle}
                            width={120}
                            height={55}
                            thumbSize={45}
                        />
                        <Word text={'Enable OTP'} size={24} color={C.BLACK} />
                    </View>
                </View>

            </KeyboardAvoidScrollingTemplate>
        </>
    )
}

export default EnableOTP

const styles = StyleSheet.create({
    toggleContainer: {
        alignItems: 'center',
        marginTop: VS(30),
        gap: MS(20)
    }
});