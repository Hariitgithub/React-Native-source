import React from 'react';
import { StyleSheet, View, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';

import KeyboardAvoidScrollingTemplate from '../../Component/Template/KeyboardAvoidScrollingTemplate';
import Word from '../../Component/Word/Word';
import Img from '../../Component/img/Img';

import { VS } from '../../Utils/FontSize';
import { C } from '../../Utils/ColorFonts';

import {
    rightArrow,
    officeBag,
    addHome,
    carIcon,
    docs,
} from '../../assets/images/imgIndex';
import Header from '../Common/Header';

const DocumentDetails = () => {
    const navigation = useNavigation();

    const menuList = [
        {
            id: 1,
            title: 'Documents',
            icon: docs,
            navigateTo: 'documents',
        },
        {
            id: 2,
            title: 'Vehicle',
            icon: carIcon,
            navigateTo: 'vehicle',
        },

    ];

    return (
        <KeyboardAvoidScrollingTemplate>
            <Header name={'Document Details'} />
            <View style={styles.container}>
                {menuList.map(item => (
                    <TouchableOpacity
                        key={item.id}
                        activeOpacity={0.8}
                        style={styles.navCard}
                        onPress={() => navigation.navigate(item.navigateTo)}>
                        <View style={styles.left}>
                            <Img
                                src={item.icon}
                                width={20}
                                height={20}
                                color={C.BLACK}
                            />

                            <Word
                                text={item.title}
                                ml={15}
                            />
                        </View>

                        <Img
                            src={rightArrow}
                            width={18}
                            height={18}
                        />
                    </TouchableOpacity>
                ))}
            </View>
        </KeyboardAvoidScrollingTemplate>
    );
};

export default DocumentDetails;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: C.WHITE,
    },

    navCard: {
        height: VS(55),
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        borderBottomWidth: 1,
        borderBottomColor: C.BG_GRAY,
    },

    left: {
        flexDirection: 'row',
        alignItems: 'center',
    },
});