import { StyleSheet, Text, View, TouchableOpacity, Pressable } from 'react-native'
import React, { useState } from 'react';
import KeyboardAvoidScrollingTemplate from '../../Component/Template/KeyboardAvoidScrollingTemplate';
import { C } from '../../Utils/ColorFonts';
import Header from '../Common/Header';
import { CopyIcon, facebook, leftArrow, mailicon, referStick, share, whatsapp, yellowRebben } from '../../assets/images/imgIndex';
import Img from '../../Component/img/Img';
import { useNavigation } from '@react-navigation/native';
import { HS, MS, VS } from '../../Utils/FontSize';
import Word from '../../Component/Word/Word';
import CommonButton from '../../Component/Buttons/CommonButton';

const MyReferral = () => {

    const navigation = useNavigation();
    const [loader, setLoader] = useState(false);
    const [shareItems, setShareitems] = useState([
        {
            img: whatsapp,
            link: ''
        },
        {
            img: facebook,
            link: ''
        },
        {
            img: mailicon,
            link: ''
        },
        {
            img: share,
            link: ''
        },
    ]);

    const submitHandler = () => {
        setLoader(true);
        setTimeout(() => {
            setLoader(false);
        }, 2000)
    }

    return (
        <>
            <KeyboardAvoidScrollingTemplate>

                <View style={styles.container}>

                    <TouchableOpacity
                        activeOpacity={0.8}
                        style={{
                            top: VS(20),
                            left: HS(20),
                        }}
                        onPress={() => navigation.goBack()}
                    >
                        <Img
                            src={leftArrow}
                            style={[styles.arrowImg, { tintColor: '#ffffff' }]}
                            resize="contain"
                        />

                    </TouchableOpacity>

                    <View style={styles.centerContain}>
                        <Img src={referStick} width={200} height={180} />
                        <Word text={'Invite friend and earn rewards'} mb={10} color={C.WHITE} font={2} />
                        <Img src={yellowRebben} width={650} height={50} style={{ top: MS(20), right: HS(2.5), zIndex: 99 }} />
                        <View style={styles.whitebg}>
                            <Word size={14} style={{ transform: [{ skewX: '-15deg' }], }} mt={40} color={C.TEXT_2} text={'Your Referral Code'} />
                            <View style={styles.flexChange}>
                                <Word text={'ASDAFFF'} size={30} font={2} color={C.BLACK} />
                                <Pressable>
                                    <Img src={CopyIcon} width={20} height={20} />
                                </Pressable>
                            </View>
                            <View style={styles.shareRow}>
                                {shareItems.map((item, index) => (
                                    <Pressable style={styles.shareContain} key={index}>
                                        <Img src={item.img} width={40} height={40} />
                                    </Pressable>
                                ))}
                            </View>
                        </View>
                        <Word text={'Refer friends, earn rewards, enjoy benefits, unlimited referrals, start today! 🎉'} align={'center'} mb={10} mt={30} color={C.WHITE} font={2} />
                    </View>
                </View>
            </KeyboardAvoidScrollingTemplate>
            <View
                style={{
                    width: '100%',
                    position: 'absolute',
                    bottom: VS(0),
                    padding: MS(25),
                }}>
                <CommonButton title="Invite Friend" loader={loader} onPress={submitHandler} />
            </View>
        </>
    )
}

export default MyReferral;

const styles = StyleSheet.create({
    container: {
        backgroundColor: C.BLACK,
        height: '100%',

    },
    arrowImg: {
        height: VS(20),
        width: HS(20),
        marginRight: HS(20),
        alignSelf: 'flex-start'
    },

    centerContain: {
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    whitebg: {
        backgroundColor: C.WHITE,
        height: VS(250),
        width: '80%',
        borderBottomLeftRadius: MS(30),
        borderBottomRightRadius: MS(30),
        alignItems: "center",
        gap: MS(15)
    },
    flexChange: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: MS(15)
    },
    shareRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: MS(18),
        width: '100%',
    },
    shareContain: {
        alignItems: 'center',
        justifyContent: 'center',
        width: MS(44),
        height: MS(44),
        zIndex: 1,
    }
})
