import React, { useState } from 'react';
import {
    StyleSheet,
    View,
} from 'react-native';

import KeyboardAvoidScrollingTemplate from '../../Component/Template/KeyboardAvoidScrollingTemplate';
import Header from '../Common/Header';
import InputComponent from '../../Component/InputComponent/InputComponent';
import CommonButton from '../../Component/Buttons/CommonButton';
import CommonPicker from '../../Component/CommonPicker';
import { C } from '../../Utils/ColorFonts';
import { MS, VS } from '../../Utils/FontSize';

const Vehicle = () => {
    const [formData, setFormData] = useState({
        vehicleType: 'Sedan',
        vehicleName: 'Nissan',
        vehicleModel: 'NissanCO2',
        vehicleColour: 'Green',
        vehiclePlate: 'TNI234567',
    });

    const vehicleTypes = [
        { label: 'Sedan', value: 'Sedan' },
        { label: 'SUV', value: 'SUV' },
        { label: 'Minivan', value: 'Minivan' },
        { label: 'Three Wheeler', value: 'Three Wheeler' },
        { label: 'Motorcycle', value: 'Motorcycle' },
    ];

    const [vehicleType, setVehicleType] = useState(vehicleTypes[0]);

    const handleUpload = () => {
        console.log(formData);
    };

    return (
        <>
            <Header name="Vehicle" />

            <KeyboardAvoidScrollingTemplate>

                <View style={styles.pickerContainer}>
                    <CommonPicker
                        label="Vehicle Type"
                        data={vehicleTypes}
                        value={vehicleType}
                        placeholder="Select Vehicle"
                        onSelect={item => setVehicleType(item)}
                    />




                    <InputComponent
                        title={'Vehicle Name'}
                        titleColor={C.BLACK}
                        placeholder="Vehicle Name"
                        value={formData.vehicleName}
                        onChangeText={text =>
                            setFormData({
                                ...formData,
                                vehicleName: text,
                            })
                        }
                    />



                    <InputComponent
                        title={'Vehicle Colour'}
                        titleColor={C.BLACK}
                        placeholder="Vehicle Model"
                        value={formData.vehicleModel}
                        onChangeText={text =>
                            setFormData({
                                ...formData,
                                vehicleModel: text,
                            })
                        }
                    />



                    <InputComponent
                        titleColor={C.BLACK}
                        title={'Vehicle Colour'}
                        placeholder="Vehicle Colour"
                        value={formData.vehicleColour}
                        onChangeText={text =>
                            setFormData({
                                ...formData,
                                vehicleColour: text,
                            })
                        }
                    />



                    <InputComponent
                        title={'Vehicle Plate Number'}
                        titleColor={C.BLACK}
                        placeholder="Vehicle Plate Number"
                        value={formData.vehiclePlate}
                        autoCapitalize="characters"
                        onChangeText={text =>
                            setFormData({
                                ...formData,
                                vehiclePlate: text.toUpperCase(),
                            })
                        }
                    />
                </View>
                <View style={{ height: VS(120) }} />
            </KeyboardAvoidScrollingTemplate>

            <View style={styles.buttonContainer}>
                <CommonButton
                    title="SAVE"
                    onPress={handleUpload}
                />
            </View>
        </>
    );
};

export default Vehicle;

const styles = StyleSheet.create({
    container: {
        paddingHorizontal: MS(18),
        paddingTop: VS(15),
        paddingBottom: VS(20),
    },

    label: {
        fontSize: 15,
        color: C.BLACK,
        marginBottom: VS(8),
        marginTop: VS(18),
    },

    pickerContainer: {
        padding: MS(20),
    },

    buttonContainer: {
        position: 'absolute',
        bottom: VS(0),
        width: '100%',
        paddingHorizontal: MS(18),
        paddingVertical: VS(18),
        backgroundColor: '#fff',
    },
});