import React, { useCallback, useState } from 'react';
import { StyleSheet, View, TouchableOpacity } from 'react-native';
import { useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import KeyboardAvoidScrollingTemplate from '../../Component/Template/KeyboardAvoidScrollingTemplate';
import Word from '../../Component/Word/Word';
import Img from '../../Component/img/Img';
import { VS } from '../../Utils/FontSize';
import { C } from '../../Utils/ColorFonts';

import {
    rightArrow,
    officeBag,
    addHome,
} from '../../assets/images/imgIndex';
import Header from '../Common/Header';

const FavouriteAccount = () => {
    const navigation = useNavigation();
    const route = useRoute();
    const [savedLocations, setSavedLocations] = useState({});
    const menuList = [
        {
            id: 1,
            title: 'Add Home',
            icon: addHome,
            type: 'home',
        },
        {
            id: 2,
            title: 'Add Office',
            icon: officeBag,
            type: 'office',
        },
        {
            id: 3,
            title: 'Others',
            icon: addHome,
            type: 'others',
        },
    ];

    useFocusEffect(useCallback(() => {
        const selectedLocation = route.params?.selectedLocation;
        const selectedType = route.params?.selectedType;

        if (selectedLocation && selectedType) {
            setSavedLocations(prev => ({
                ...prev,
                [selectedType]: selectedLocation,
            }));
            navigation.setParams({
                selectedLocation: undefined,
                selectedType: undefined,
            });
        }
    }, [navigation, route.params?.selectedLocation, route.params?.selectedType]));

    const handleAddLocation = useCallback((item) => {
        navigation.navigate('mapScreen', {
            selectedType: item.type,
            title: item.title.replace('Add ', ''),
            returnScreen: 'favouriteAccount',
        });
    }, [navigation]);

    return (
        <KeyboardAvoidScrollingTemplate>
            <Header name={'Favourite Address'} />
            <View style={styles.container}>
                {menuList.map(item => (
                    <TouchableOpacity
                        key={item.id}
                        activeOpacity={0.8}
                        style={styles.navCard}
                        onPress={() => handleAddLocation(item)}>
                        <View style={styles.left}>
                            <Img
                                src={item.icon}
                                width={20}
                                height={20}
                                color={C.BLACK}
                            />

                            <View style={styles.textContainer}>
                                <Word
                                    text={item.title}
                                />
                                {!!savedLocations[item.type]?.address && (
                                    <Word
                                        text={savedLocations[item.type].address}
                                        mt={3}
                                        size={16}
                                        color="#666"
                                        line={1}
                                    />
                                )}
                            </View>
                        </View>
                        <Img
                            src={rightArrow}
                            width={18}
                            height={18}
                        />
                    </TouchableOpacity>
                ))}
            </View>
        </KeyboardAvoidScrollingTemplate>
    );
};

export default FavouriteAccount;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: C.WHITE,
    },

    navCard: {
        height: VS(55),
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        borderBottomWidth: 1,
        borderBottomColor: C.BG_GRAY,
    },

    left: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        paddingRight: 12,
    },

    textContainer: {
        flex: 1,
        marginLeft: 15,
    },
});
