import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Modal,
    TextInput,
    Pressable,
    SafeAreaView,
} from 'react-native';
import { C } from '../../Utils/ColorFonts';
import Word from '../../Component/Word/Word';
import InputComponent from '../../Component/InputComponent/InputComponent';
import CommonButton from '../../Component/Buttons/CommonButton';
import KeyboardAvoidScrollingTemplate from '../../Component/Template/KeyboardAvoidScrollingTemplate';
import Header from '../Common/Header';
import { HS, MS, VS } from '../../Utils/FontSize';

const WalletScreen = () => {
    const [walletBalance] = useState('₹2,540');
    const [modalVisible, setModalVisible] = useState(false);
    const [amount, setAmount] = useState('');

    const submitAmount = () => {
        console.log(amount);

        setModalVisible(false);
        setAmount('');
    };

    return (
        <SafeAreaView
            style={{
                flex: 1,
                backgroundColor: C.WHITE,
            }}>
            <Header name={'Wallet'} />
            <View style={styles.walletCard}>
                <Word text={'My Wallet'} style={styles.walletTitle} />

                <Word text={walletBalance} style={styles.balance} />

                <Word text={'Available Balance'} style={styles.balanceText} />


                <View style={styles.actionRow}>
                    <TouchableOpacity style={styles.primaryButton}>
                        <Word text={'Wallet'} color={C.BLACK} />
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={styles.secondaryButton}
                        onPress={() => setModalVisible(true)}>
                        <Word text={'+ Add Money'} style={styles.secondaryText} />
                    </TouchableOpacity>
                </View>
            </View>

            {/* Other Buttons */}

            <View style={styles.bottomButtons}>
                <TouchableOpacity style={styles.menuCard}>
                    <Word text={'💳'} style={styles.menuIcon} />
                    <Word text={'Transactions'} style={styles.menuText} />
                </TouchableOpacity>

                <TouchableOpacity style={styles.menuCard}>
                    <Word text={'🎁'} style={styles.menuIcon} />
                    <Word text={'Rewards'} style={styles.menuText} />
                </TouchableOpacity>
            </View>

            {/* Popup */}

            <Modal
                visible={modalVisible}
                transparent
                animationType="fade">

                <View style={styles.overlay}>
                    <View style={styles.modalBox}>

                        <Word text={'Add Money'} style={styles.popupTitle} />



                        <InputComponent
                            placeholder="Enter Amount"
                            keyboardType="number"
                            value={amount}
                            onChangeText={setAmount}
                            style={styles.input}
                        />
                        <CommonButton
                            onPress={submitAmount}
                            title={'Submit'}
                        />

                        <CommonButton
                            onPress={() => setModalVisible(false)}
                            title={'Cancel'}
                            btnStyle={styles.cancel}
                            bgColor={C.WHITE}
                        />



                    </View>
                </View>

            </Modal>
        </SafeAreaView>
    );
};

export default WalletScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5F7FB',
    },

    walletCard: {
        height: '42%',
        backgroundColor: C.PRIMARY1,
        margin: MS(20),
        borderRadius: MS(28),
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 8,
    },

    walletTitle: {
        color: C.BLACK,
        fontSize: MS(22),
    },

    balance: {
        color: C.BLACK,
        fontSize: MS(42),
        marginTop: VS(15),
    },

    balanceText: {
        color: '#5b6478',
        marginTop: VS(5),
        fontSize: MS(16),
    },

    actionRow: {
        flexDirection: 'row',
        marginTop: VS(35),
    },

    primaryButton: {
        backgroundColor: '#fff',
        paddingHorizontal: HS(28),
        paddingVertical: VS(12),
        borderRadius: MS(14),
        marginHorizontal: HS(8),
    },

    secondaryButton: {
        borderWidth: 1,
        borderColor: C.BLACK,
        paddingHorizontal: HS(24),
        paddingVertical: VS(12),
        borderRadius: MS(14),
        marginHorizontal: HS(8),
    },



    secondaryText: {
        color: C.BLACK,
    },

    bottomButtons: {
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        marginTop: VS(25),
    },

    menuCard: {
        width: '42%',
        height: VS(120),
        backgroundColor: '#fff',
        borderRadius: MS(22),
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 5,
    },

    menuIcon: {
        fontSize: MS(34),
    },

    menuText: {
        marginTop: VS(10),
        fontSize: MS(16),
    },

    overlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.45)',
        justifyContent: 'center',
        alignItems: 'center',
    },

    modalBox: {
        width: '88%',
        backgroundColor: '#fff',
        borderRadius: 25,
        padding: MS(25),
    },

    popupTitle: {
        fontSize: MS(22),
        marginBottom: VS(20),
        textAlign: 'center',
    },

    input: {
        height: VS(55),
        borderWidth: 1,
        borderColor: '#E1E1E1',
        borderRadius: MS(15),
        paddingHorizontal: HS(15),
        fontSize: MS(18),
    },

    submitButton: {
        backgroundColor: '#2D6CDF',
        height: VS(52),
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: MS(15),
        marginTop: VS(22),
    },

    submitText: {
        color: '#fff',
        fontSize: MS(17),
    },

    cancel: {
        textAlign: 'center',
        borderColor: C.BG_GRAY,
        borderWidth: 1,
        marginTop: VS(18),
        fontSize: MS(16),
    },
});