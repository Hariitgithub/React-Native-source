import axios from 'axios';
import { MAP_KEY } from '../../../Utils/Constants';

const hasValidMapKey = MAP_KEY && MAP_KEY !== 'DUMMY_MAP_KEY';

export const PlacesAutoComplete = async query => {
  const GOOGLE_URL = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${query}`;

  if (!query || !hasValidMapKey) {
    return { status: 'error' };
  }

  try {
    const response = await axios.get(GOOGLE_URL, {
      params: {
        key: MAP_KEY,
        limit: 5,
      },
    });
    // console.log('google places res', response);
    let placeswithDetails = [];
    if (response.data && response.data.predictions) {
      let detailPromises = response.data.predictions?.map(async item => {
        const detailres = await googlePlaceDetails(item?.place_id);
        if (detailres.status === 'success') {
          return detailres.data;
        } else {
          return null;
        }
      });

      const result = await Promise.all(detailPromises);
      placeswithDetails = result.filter(Boolean);
      // console.log('places res with details', placeswithDetails);
      return { status: 'success', data: placeswithDetails };
    }
  } catch (error) {
    console.log('Error searching for address:', error);
    return { status: 'error' };
  }
};

export const googlePlaceDetails = async placeId => {
  if (!placeId || !hasValidMapKey) {
    return { status: 'error' };
  }

  try {
    const response = await axios.get(
      `https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&key=${MAP_KEY}&language=en`,
    );

    if (response.data) {
      return { status: 'success', data: response.data?.result };
    }
  } catch (error) {
    console.log('Error searching for address:', error);
    return { status: 'error' };
  }
};

export const reverseGeocode = async (latitude, longitude) => {
  if (!latitude || !longitude) {
    return { status: 'error' };
  }
  if (!hasValidMapKey) {
    return {
      status: 'success',
      address: `Lat: ${Number(latitude).toFixed(6)}, Lng: ${Number(longitude).toFixed(6)}`,
    };
  }
  try {
    const res = await axios.get(
      `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${MAP_KEY}`,
    );
    console.log('reverse geocode response', res.data);
    if (res?.data) {
      return {
        status: 'success',
        address: res.data?.results?.[0]?.formatted_address,
      };
    }
  } catch (error) {
    console.log('reverse geocode error', error);
    return { status: 'error' };
  }
};
