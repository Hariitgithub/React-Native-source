/* eslint-disable react-native/no-inline-styles */
/* eslint-disable react-hooks/exhaustive-deps */
import {
  AppState,
  Keyboard,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React, { useCallback, useRef, useState } from 'react';
import { C, F } from '../../../Utils/ColorFonts';
import Geolocation from '@react-native-community/geolocation';
import { requestLocationPermission } from '../../../Component/Permissions/LocationPermission';
import { useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import AllowLocationPop from '../../../Component/modal/AllowLocationPop';
import CommonButton from '../../../Component/Buttons/CommonButton';
import { fS, HS, MS, VS } from '../../../Utils/FontSize';
import Word from '../../../Component/Word/Word';
import {
  pointer_img,
} from '../../../assets/images/imgIndex';
import { Toast } from '../../../Utils/Constants';
import Img from '../../../Component/img/Img';
import { PlacesAutoComplete, reverseGeocode } from './PlacesAutoComplete';
import MapView from 'react-native-maps';
import Header from '../../Common/Header';
import { location_img } from '../../../assets/images/imgIndex';
import { SafeAreaView } from 'react-native-safe-area-context';

const MapScreen = ({ open, setOpen, onConfirm }) => {
  const mapRef = useRef(null);
  const navigation = useNavigation();
  const route = useRoute();
  const isOpen = open ?? true;
  const selectedType = route.params?.selectedType;
  const returnScreen = route.params?.returnScreen;
  const title = route.params?.title;
  const [showLocationPop, setShowLocationPop] = useState(false);
  const [search, setSearch] = useState('');
  const [placesList, setPlacesList] = useState([]);
  const [location, setLocation] = useState({
    latitude: '',
    longitude: '',
    address: '',
  });

  useFocusEffect(
    useCallback(() => {
      if (!isOpen) return;
      let appstatelistener = AppState.addEventListener('change', e => {
        CheckLocationPermission();
      });
      CheckLocationPermission();
      return () => {
        appstatelistener.remove();
      };
    }, [isOpen]),
  );

  const CheckLocationPermission = async () => {
    const result = await requestLocationPermission();
    if (!result) {
      setShowLocationPop(true);
      return;
    }
    setShowLocationPop(false);
    getCurrentLocation();
  };

  const getCurrentLocation = async () => {
    Geolocation.getCurrentPosition(
      position => {
        console.log('location', position.coords);
        const { latitude, longitude } = position.coords;
        changeRegion(latitude, longitude);
        setLocation(prev => ({
          ...prev,
          latitude: latitude,
          longitude: longitude,
        }));
      },
      error => {
        if (error.code === 2 && isOpen) {
          Toast('TurnOn Location');
        }
        console.log('location fetch error', error.code, error.message);
      },
      {
        enableHighAccuracy: false, // Changed to false for better reliability
        timeout: 30000,
        maximumAge: 10000,
        forceRequestLocation: true,
      },
    );
  };

  const getAddress = async (latitude, longitude) => {
    const res = await reverseGeocode(latitude, longitude);
    // console.log('reverse map res', res);
    if (res?.status === 'success') {
      setLocation({
        address: res?.address,
        latitude: latitude,
        longitude: longitude,
      });
    }
  };

  const changeRegion = (latitude, longitude) => {
    if (mapRef.current) {
      mapRef.current.animateToRegion(
        {
          latitude: latitude,
          longitude: longitude,
          latitudeDelta: 0.015,
          longitudeDelta: 0.0121,
        },
        1500,
      );
    }
  };

  const fetchGooglePlaceSuggestions = async placeText => {
    if (!placeText) {
      setPlacesList([]);
      return;
    }
    const res = await PlacesAutoComplete(placeText);
    // console.log('places res map screen suggestionsRes', res);
    if (res?.status === 'success') {
      let placesArray = [];
      res?.data?.map((item, ind) => {
        let obj = {
          address: item?.formatted_address,
          icon: item?.icon,
          latitude: item?.geometry?.location?.lat,
          longitude: item?.geometry?.location?.lng,
          heading: item?.name,
        };
        placesArray.push(obj);
      });
      setPlacesList(placesArray);
    } else {
      setPlacesList([]);
    }
  };

  const handleBack = () => {
    if (setOpen) {
      setOpen(false);
      return;
    }
    navigation.goBack();
  };

  const handleConfirmLocation = () => {
    if (!location?.latitude || !location?.longitude) {
      Toast('Please select location');
      return;
    }

    if (onConfirm) {
      onConfirm(location);
      return;
    }

    if (returnScreen) {
      const params = {
        selectedLocation: location,
        selectedType,
      };

      if (navigation.popTo) {
        navigation.popTo(returnScreen, params);
      } else {
        navigation.navigate(returnScreen, params);
      }
      return;
    }

    navigation.goBack();
  };

  return (
    <SafeAreaView style={styles.container}>
      <MapView
        initialRegion={{
          latitude: 13.048628,
          longitude: 80.207858,
          latitudeDelta: 0.02,
          longitudeDelta: 0.02,
        }}
        ref={mapRef}
        style={{ flex: 1 }}
        followsUserLocation={true}
        tintColor="#000"
        pinColor="#000"
        showsCompass={false}
        showsScale={true}
        showsPointsOfInterest={true}
        scrollEnabled={true}
        showsUserLocation={true}
        showsUserLocationButton={true}
        showsIndoors={true}
        showsTraffic={false}
        showsBuildings={true}
        showsIndoorsButton={false}
        showsTrafficButton={false}
        showsBuildingsButton={false}
        zoomEnabled={true}
        rotateEnabled={true}
        pitchEnabled={true}
        onRegionChangeComplete={({ latitude, longitude }) => {
          getAddress(latitude, longitude);
        }}
        onMapReady={() => {
          requestLocationPermission();
        }}
      />
      <View style={{ position: 'absolute', top: 0, left: 10, right: 0 }}>
        <Header
          name={title ? `${title} Location` : 'Delivery Location'}
          bgNeed={false}
          isHome={false}
          backFunc={handleBack}
        />
      </View>
      <View style={styles.searchContainer}>
        <TouchableOpacity
          onPress={() => setOpen?.(false)}
          style={styles.backButton}
        />

        <View style={styles.searchBar}>
          {/* <Img src={searchIcon} height={20} width={20} resizeMode="contain" color={"#000"} /> */}
          <Img
            src={location_img}
            height={25}
            width={25}
            resizeMode="contain"
            color={'#000'}
          />
          <TextInput
            placeholder="Search Your Location"
            placeholderTextColor={'#909090'}
            value={search}
            onChangeText={e => {
              setSearch(e);
              fetchGooglePlaceSuggestions(e);
            }}
            style={[styles.searchInput, { marginTop: search ? 9 : 10 }]}
          />
        </View>
      </View>

      {/* <TouchableOpacity 
        style={styles.myLocationButton} 
        onPress={() => CheckLocationPermission()}
      >
        <Img
          src={my_location}
          height={30}
          width={30}
          resize={'contain'}
        />
      </TouchableOpacity> */}

      <View style={styles.SuggestionContainer}>
        {placesList?.map((item, ind) => {
          return (
            <TouchableOpacity
              onPress={() => {
                setPlacesList([]);
                Keyboard.dismiss();
                setSearch('');
                setLocation({
                  address: item?.address,
                  latitude: item?.latitude,
                  longitude: item?.longitude,
                });
                changeRegion(item?.latitude, item?.longitude);
              }}
              style={{
                borderBottomWidth: ind + 1 === placesList?.length ? 0 : 1,
                borderColor: '#828DA6',
                paddingVertical: VS(15),
                marginHorizontal: HS(20),
              }}
            >
              <Word
                text={item?.address}
                font={1}
                size={22}
                ml={10}
                color={'black'}
                align={'left'}
                line={1}
              />
            </TouchableOpacity>
          );
        })}
      </View>

      <View style={styles.centerMarkerContainer} pointerEvents="none">
        <Img
          src={pointer_img}
          style={styles.centerMarker}
          resize={"contain"}
        />
      </View>
      <View style={styles.bottomContainer}>
        <Word text={title ? `${title} Location` : 'Delivery Location'} font={2} size={22} color={C.PRIMARY1} />
        <View style={styles.AddressContainer}>
          <Word text={location?.address} font={1} size={22} color={'black'} />
        </View>
        <CommonButton title={'Confirm'} onPress={handleConfirmLocation} />
      </View>
      <AllowLocationPop showPopup={showLocationPop} />
    </SafeAreaView>
  );
};

export default MapScreen;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent', marginTop: VS(20) },
  centerMarkerContainer: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    marginTop: -fS(40),
    marginLeft: -fS(20),
    zIndex: 1,
  },
  centerMarker: {
    width: HS(40),
    height: VS(40),
    tintColor: '#FC8019',
  },
  bottomContainer: {
    zIndex: 1,
    padding: MS(20),
    backgroundColor: 'rgba(144,144,144,0.55)',
    borderTopLeftRadius: MS(24),
    borderTopRightRadius: MS(24),
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.07)',
  },
  searchContainer: {
    width: '100%',
    position: 'absolute',
    top: '10%',
    paddingHorizontal: HS(20),
    flexDirection: 'row',
    alignItems: 'center',
    zIndex: 10,
  },
  backButton: {
    marginRight: HS(10),
  },
  searchBar: {
    flex: 1,
    height: VS(60),
    borderRadius: MS(30),
    borderWidth: 1,
    borderColor: '#909090',
    backgroundColor: '#fff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 15,
  },
  searchInput: {
    flex: 1,
    marginLeft: HS(10),
    fontFamily: F.f1,
    fontSize: MS(22),
    color: '#000',
    height: '100%',
  },
  myLocationButton: {
    position: 'absolute',
    right: HS(20),
    bottom: VS(250),
    backgroundColor: '#fff',
    padding: MS(10),
    borderRadius: MS(30),
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: MS(3.84),
    zIndex: 5,
  },
  AddressContainer: {
    minHeight: VS(40),
    borderRadius: MS(20),
    paddingHorizontal: HS(20),
    paddingVertical: VS(10),
    backgroundColor: '#FFFFFF',
    marginTop: VS(10)
  },
  SuggestionContainer: {
    position: 'absolute',
    zIndex: 20,
    top: '18%',
    left: HS(20),
    right: HS(20),
    borderRadius: MS(10),
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5, // For Android
  },
});
