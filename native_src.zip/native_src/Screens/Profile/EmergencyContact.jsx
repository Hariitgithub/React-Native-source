import React, { useEffect, useState } from 'react';
import {
    Pressable,
    StyleSheet,
    View,
    TouchableOpacity,
    Alert,
} from 'react-native';

import KeyboardAvoidScrollingTemplate from '../../Component/Template/KeyboardAvoidScrollingTemplate';
import CommonButton from '../../Component/Buttons/CommonButton';
import InputComponent from '../../Component/InputComponent/InputComponent';
import Header from '../Common/Header';
import Img from '../../Component/img/Img';

import { MS, VS } from '../../Utils/FontSize';
import { Userplus } from '../../assets/images/imgIndex';
import Word from '../../Component/Word/Word';
import { C } from '../../Utils/ColorFonts';
import { URLS } from '../../Redux/apiRequest/Constant';
import { mmkvStorage, Toast } from '../../Utils/Constants';
import { deletes, get, post, put } from '../../Redux/apiRequest/ApiHandler';
import LogoutModal from '../../Component/modal/LogoutModal';

// import Toast from '../../Utils/Toast';
// import { post } from '../../Api/api';
// import URLS from '../../Api/Urls';

const EmergencyContact = () => {
    const [deleteData, setDeleteData] = useState()
    const [blukSubmit, setBulkSubmit] = useState(true);
    const [contacts, setContacts] = useState([
        {
            name: '',
            mobile: '',
            email: '',
        },
    ]);
    const [openLogout, setOpenLogout] = useState(false);

    const openModel = () => setOpenLogout(true);
    const hideModel = () => setOpenLogout(false);
    const userData = JSON.parse(mmkvStorage.getString('userdata'));

    useEffect(() => {
        getData();
    }, []);

    const getData = async () => {
        try {
            const res = await get(URLS.EMERGENCY);

            if (res?.status) {
                if (res?.data?.length > 0) {
                    setBulkSubmit(false);
                    setContacts(
                        res.data.map(item => ({
                            id: item.id,
                            name: item.name || '',
                            mobile: item.mobile || '',
                            email: item.email || '',
                            isNew: false,
                        })),
                    );
                } else {
                    setContacts([
                        {
                            name: '',
                            mobile: '',
                            email: '',
                            isNew: true,
                        },
                    ]);
                }
            }
        } catch (e) {
            console.log(e);
        }
    };

    // Add Contact
    const handleAdd = () => {
        setBulkSubmit(true)
        setContacts(prev => [
            ...prev,
            {
                name: '',
                mobile: '',
                email: '',
                isNew: true,
            },
        ]);
    };
    console.log("deleteData", deleteData);

    // Remove Contact
    const handleRemove = async (index) => {
        const selectedContact = contacts[index];
        try {
            // New contact (not saved in API)
            if (selectedContact.isNew) {
                const updatedContacts = [...contacts];
                updatedContacts.splice(index, 1);

                if (updatedContacts.length === 0) {
                    updatedContacts.push({
                        name: "",
                        mobile: "",
                        email: "",
                        isNew: true,
                    });
                }

                setContacts(updatedContacts);
                return;
            }

            // Existing contact
            const res = await deletes(
                `${URLS.EMERGENCY}/${selectedContact.id}`
            );

            if (res?.status) {
                Toast(res.message);
                hideModel();
                const updatedContacts = [...contacts];
                updatedContacts.splice(index, 1);

                if (updatedContacts.length === 0) {
                    updatedContacts.push({
                        name: "",
                        mobile: "",
                        email: "",
                        isNew: true,
                    });
                    setBulkSubmit(true);
                }

                setContacts(updatedContacts);

            } else {
                Toast(res?.message || "Unable to delete contact.");
            }
        } catch (error) {
            console.log(error);
            Toast("Something went wrong.");
        }


    };

    // Update Field
    const handleChange = (index, key, value) => {
        setContacts(prev =>
            prev.map((item, i) =>
                i === index ? { ...item, [key]: value } : item,
            ),
        );
    };

    const submitHandler = async () => {
        const newContacts = contacts.filter(item => item.isNew);

        if (newContacts.length === 0) {
            Toast("No new contacts to save.");
            return;
        }

        for (let i = 0; i < newContacts.length; i++) {
            const item = newContacts[i];

            if (!item.name.trim()) {
                Toast(`Please enter name for Contact ${i + 1}`);
                return;
            }

            if (!item.mobile.trim() && !item.email.trim()) {
                Toast(`Please enter mobile number or email for Contact ${i + 1}`);
                return;
            }
        }

        const payload = {
            contacts: newContacts.map(item => ({
                type: 1,
                user_id: userData?.user?.id,
                name: item.name.trim(),
                ...(item.mobile.trim()
                    ? { mobile: item.mobile.trim() }
                    : {}),
                ...(item.email.trim()
                    ? { email: item.email.trim() }
                    : {}),
            })),
        };

        try {
            const res = await post(URLS.EMERGENCY_CONTACT, payload);

            if (res?.status) {
                Toast(res.message);
                getData();
            } else {
                Toast(res?.message);
            }
        } catch (e) {
            console.log(e);
        }
    };

    const handleSingleUpdate = async data => {
        if (data.isNew) {
            Toast("New contact will be saved when you click Confirm.");
            return;
        }

        if (!data.name.trim()) {
            Toast("Enter name");
            return;
        }

        if (!data.mobile.trim() && !data.email.trim()) {
            Toast("Enter mobile or email");
            return;
        }

        try {
            const postData = {
                type: 2,
                user_id: userData?.user?.id,
                name: data.name.trim(),
                ...(data.mobile.trim()
                    ? { mobile: data.mobile.trim() }
                    : {}),
                ...(data.email.trim()
                    ? { email: data.email.trim() }
                    : {}),
            };

            const res = await put(`${URLS.EMERGENCY}/${data.id}`, postData);

            if (res?.status) {
                Toast(res.message);
            } else {
                Toast(res?.message);
            }
        } catch (e) {
            console.log(e);
        }
    };
    console.log("userDatas", userData);

    return (
        <>
            <Header
                name="Emergency Contact"
                rightbtn={
                    <Pressable onPress={handleAdd}>
                        <Img src={Userplus} width={22} height={22} />
                    </Pressable>
                }
            />

            <KeyboardAvoidScrollingTemplate >

                <View style={{ padding: MS(20), marginBottom: VS(30) }}>
                    {contacts.map((item, index) => (
                        <View key={index} style={styles.card}>
                            {contacts.length > 1 && (
                                <TouchableOpacity
                                    style={styles.removeBtn}
                                    onPress={() => { setDeleteData(index); openModel() }}>
                                    <Word text={'X'} size={13} ml={1} />
                                </TouchableOpacity>
                            )}

                            <InputComponent
                                placeholder="Enter Name"
                                value={item.name}
                                onChangeText={text => handleChange(index, 'name', text)}
                            />

                            <InputComponent
                                placeholder="Enter Mobile Number"
                                keyboardType="number"
                                maxLength={10}
                                value={item.mobile}
                                onChangeText={text => handleChange(index, 'mobile', text)}
                            />

                            <InputComponent
                                placeholder="Enter Email (Optional)"
                                keyboardType="email-address"
                                value={item.email}
                                onChangeText={text => handleChange(index, 'email', text)}
                            />
                            {!item.isNew &&
                                <CommonButton
                                    title={"Update"}
                                    onPress={() => handleSingleUpdate(item)}
                                />}
                        </View>
                    ))}
                </View>

                <LogoutModal title={'Delete Contact'}
                    title_2={'Are you sure you want to delete this emergency contact?'}
                    visible={openLogout}
                    onClose={hideModel}
                    OnPressYes={() => handleRemove(deleteData)}
                />
            </KeyboardAvoidScrollingTemplate>
            <View
                style={{
                    width: '100%',
                    position: 'absolute',
                    bottom: VS(0),
                    padding: MS(25),
                }}>
                {blukSubmit &&
                    <CommonButton title="Confirm" onPress={submitHandler} />
                }
            </View>
        </>
    );
};

export default EmergencyContact;

const styles = StyleSheet.create({
    card: {

        borderRadius: 10,
        padding: MS(15),
    },

    removeBtn: {
        alignSelf: 'flex-end',
        width: 25,
        height: 25,
        borderRadius: 14,
        borderWidth: 1,
        borderColor: C.BLACK,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: VS(10),
    },

    crossHorizontal: {
        width: 14,
        height: 2,
        backgroundColor: '#fff',
    },
});