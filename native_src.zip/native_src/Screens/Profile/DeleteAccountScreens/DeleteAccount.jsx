import { StyleSheet, Text, View } from 'react-native'
import React, { useCallback, useState } from 'react';
import KeyboardAvoidScrollingTemplate from '../../../Component/Template/KeyboardAvoidScrollingTemplate';
import Header from '../../Common/Header';
import { VS } from '../../../Utils/FontSize';
import { URLS } from '../../../Redux/apiRequest/Constant';
import { get } from '../../../Redux/apiRequest/ApiHandler';
import Word from '../../../Component/Word/Word';
import { C } from '../../../Utils/ColorFonts';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import Img from '../../../Component/img/Img';
import CommonButton from '../../../Component/Buttons/CommonButton';


const DeleteAccount = () => {
    const navigation = useNavigation();
    const [loader, setLoader] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        mobile: '',
        profile_image: '',
    });

    const getData = async () => {
        const res = await get(URLS.VIEW_PROFILE);
        const data = res?.data
        setFormData({
            name: data?.name,
            mobile: data?.mobile,
            profile_image: data?.profile_image,
        })
    }

    useFocusEffect(
        useCallback(() => {
            getData();
        }, [])
    );

    const handleDelete = () => {
        navigation.navigate('deletionReason');
    }

    return (
        <>
            <Header name={'Delete account'} />
            <KeyboardAvoidScrollingTemplate>
                <View style={styles.profileContainer}>
                    <Img
                        src={
                            formData?.profile_image
                                ? { uri: formData?.profile_image }
                                : {
                                    uri: 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png',
                                }
                        }
                        width={100}
                        height={100}
                        radius={50}
                        resize="cover"
                    />

                    <Word
                        text={formData?.name || "SATHISH R"}
                        mt={12}
                        font={2}
                    />

                    <Word
                        text={formData?.mobile || "xxx xxx xxxx"}
                        mt={5}
                        font={1}
                        color="#666"
                    />
                </View>
                <Word align={'center'} ml={20} me={20} size={14} color={C.BLACK} text={'Are you sure you want to delete your account? Please note that your account will be temporarily deactivated for 2 months.And will fully be deleted, if you don’t reactivate your account within that period.'} />
            </KeyboardAvoidScrollingTemplate>
            <View style={{ width: '100%', position: 'absolute', bottom: VS(0), padding: 25 }}>
                <CommonButton
                    title={'Delete'}
                    onPress={handleDelete}
                    loader={loader}
                />
            </View>
        </>
    )
}

export default DeleteAccount

const styles = StyleSheet.create({
    profileContainer: {
        alignItems: 'center',
        marginTop: VS(20),
        marginBottom: VS(20),
    },
})