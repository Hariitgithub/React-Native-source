/* eslint-disable react-native/no-inline-styles */
import React, { useEffect, useState } from 'react';
import {
    SafeAreaView,
    StyleSheet,
    TouchableOpacity,
    View,
    TextInput,
    Alert,
} from 'react-native';
import KeyboardAvoidScrollingTemplate from '../../../Component/Template/KeyboardAvoidScrollingTemplate';
import Word from '../../../Component/Word/Word';
import CommonButton from '../../../Component/Buttons/CommonButton';
import { C } from '../../../Utils/ColorFonts';
import { HS, VS, MS } from '../../../Utils/FontSize';
import Img from '../../../Component/img/Img';
import { checks } from '../../../assets/images/imgIndex';
import InputComponent from '../../../Component/InputComponent/InputComponent';
import { useNavigation } from '@react-navigation/native';
import { get } from '../../../Redux/apiRequest/ApiHandler';
import { URLS } from '../../../Redux/apiRequest/Constant';



const DeletionReason = () => {
    const navigation = useNavigation();
    const [loader, setLoader] = useState(false);
    const [selectedReason, setSelectedReason] = useState(
        "Don't need it any longer",
    );
    const [otherReason, setOtherReason] = useState('');
    const [reasons, setReasons] = useState([
        'Not useful',
        "Don't need it any longer",
        'No service available in my area',
        'Driver not at pickup point',
        'Driver asked to cancel',
        'Other',
    ]);

    const getData = async () => {
        const res = await get(`${URLS.DELETEREASON}?type=1`);
        if (res?.status) {
            // setReasons(res?.data || []);
        }
    }

    useEffect(() => {
        getData();
    }, []);

    const onSelectReason = reason => {
        setSelectedReason(reason);

        // Clear textarea when selecting another option
        if (reason !== 'Other') {
            setOtherReason('');
        }
    };

    const submitHandler = () => {
        setLoader(true);
        if (selectedReason === 'Other' && otherReason.trim() === '') {
            Alert.alert('Validation', 'Please enter the reason.');
            return;
        }

        const finalReason =
            selectedReason === 'Other'
                ? otherReason.trim()
                : selectedReason;

        console.log('Reason :', finalReason);
        setLoader(false);
        navigation.navigate('deleteOTP', { isDelete: true });
    };

    return (
        <KeyboardAvoidScrollingTemplate>
            <View style={styles.card}>
                <Word
                    text={'Why do you want to delete\nyour account ?'}
                    size={26}
                    fontFamily="Poppins-Bold"
                    color={C.BLACK}
                    mb={VS(30)}
                />

                {reasons.map(item => {
                    const selected = selectedReason === item;

                    return (
                        <View key={item}>
                            <TouchableOpacity
                                activeOpacity={0.8}
                                style={styles.row}
                                onPress={() => onSelectReason(item)}>
                                <View
                                    style={[
                                        styles.radio,
                                        selected && styles.radioSelected,
                                    ]}>
                                    {selected && (
                                        <Img
                                            src={checks}
                                            width={10}
                                            height={10}
                                        />
                                    )}
                                </View>

                                <Word
                                    text={item}
                                    size={18}
                                    color={C.BLACK}
                                    ml={HS(12)}
                                />
                            </TouchableOpacity>

                            {selected && item === 'Other' && (
                                <InputComponent
                                    style={styles.textArea}
                                    placeholder="Please describe the problem"
                                    placeholderTextColor="#999"
                                    multiline
                                    numberOfLines={4}
                                    value={otherReason}
                                    onChangeText={setOtherReason}
                                    textAlignVertical="top"
                                    maxLength={250}
                                />
                            )}
                        </View>
                    );
                })}

                <View style={{ flex: 1 }} />

                <CommonButton
                    title="Submit"
                    onPress={submitHandler}
                    mt={VS(30)}
                    loader={loader}
                />
            </View>
        </KeyboardAvoidScrollingTemplate>
    );
};

export default DeletionReason;

const styles = StyleSheet.create({


    card: {
        flex: 1,
        backgroundColor: C.WHITE,
        marginTop: VS(20),
        borderTopStartRadius: MS(28),
        borderTopEndRadius: MS(28),
        paddingHorizontal: HS(24),
        paddingTop: VS(32),
        paddingBottom: VS(20),
    },

    row: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: VS(20),
    },

    radio: {
        width: HS(22),
        height: HS(22),
        borderRadius: HS(11),
        borderWidth: 1.5,
        borderColor: '#FFC107',
        justifyContent: 'center',
        alignItems: 'center',
    },

    radioSelected: {
        backgroundColor: '#FFC107',
    },

    textArea: {
        minHeight: VS(110),
        borderWidth: 1,
        borderColor: '#E5E5E5',
        borderRadius: MS(12),
        paddingHorizontal: HS(15),
        paddingVertical: VS(12),
        fontSize: MS(16),
        color: C.BLACK,
        marginBottom: VS(20),
        backgroundColor: '#FAFAFA',
    },
});