import { StyleSheet, Text, View } from 'react-native'
import React, { useState } from 'react';
import KeyboardAvoidScrollingTemplate from '../../../Component/Template/KeyboardAvoidScrollingTemplate';
import Word from '../../../Component/Word/Word';
import CommonButton from '../../../Component/Buttons/CommonButton';
import Header from '../../Common/Header';
import InputComponent from '../../../Component/InputComponent/InputComponent';
import { C } from '../../../Utils/ColorFonts';
import { MS, VS } from '../../../Utils/FontSize';
import { useNavigation, useRoute } from '@react-navigation/native';

const DeleteOTP = () => {
    const navigation = useNavigation();
    const [otpData, setOtpData] = useState('');
    const [loader, setLoader] = useState(false);
    const route = useRoute();
    const { isDelete } = route.params;

    const submitHandler = () => {
        navigation.navigate('accountDeactivated');
    }

    return (
        <>
            <Header name={isDelete ? 'Delete account' : 'Account Recovery'} />
            <KeyboardAvoidScrollingTemplate>
                <View style={{ padding: MS(20) }}>
                    <Word mb={20} font={1} text={'To delete your account please enter the OTP send to your Email.'} />
                    <InputComponent
                        placeholder="Enter OTP"
                        value={otpData}
                        onChangeText={setOtpData}
                        keyboardType={'number'}
                    />
                    <View style={styles.resendContain}>
                        <Word text={'Didn’t receive the OTP,'} color={C.TEXT} size={14} />
                        <Word text={' Resend OTP in 43 sec'} size={14} color={C.RED} />
                    </View>
                </View>
            </KeyboardAvoidScrollingTemplate>
            <View style={{ width: '100%', position: 'absolute', bottom: VS(0), padding: 25 }}>
                <CommonButton
                    title="Confirm"
                    onPress={submitHandler}
                    mt={VS(30)}
                    loader={loader}
                />
            </View>
        </>
    )
}

export default DeleteOTP;

const styles = StyleSheet.create({
    resendContain: {
        flexDirection: 'row',
        alignItems: 'center'
    }
})