import { View, TouchableOpacity, Keyboard } from 'react-native';
import React, { useState } from 'react';
import Template2 from '../../Component/Template/Template2';
import { boxI1con, boxIcon, call, logo, } from '../../assets/images/imgIndex';
import { HS, MS, VS } from '../../Utils/FontSize';
import { C } from '../../Utils/ColorFonts';
import { useNavigation } from '@react-navigation/native';
import { NUMBER, Toast } from '../../Utils/Constants';
import Word from '../../Component/Word/Word';
import InputComponent from '../../Component/InputComponent/InputComponent';
import Img from '../../Component/img/Img';
import CommonButton from '../../Component/Buttons/CommonButton';
import { post } from '../../Redux/apiRequest/ApiHandler';
import { URLS } from '../../Redux/apiRequest/Constant';


const Login = () => {
  const navigation = useNavigation();

  const [isTerms, setIsTerms] = useState(false);
  const [loader, setLoader] = useState(false);
  const termsClickHandler = () => {
    setIsTerms(prev => !prev);
  };
  const [mobileNo, setMobileNo] = useState('');
  const [mobileNoErr, setMobileNoErr] = useState(null);



  const onChangeHandler = value => {
    const numericValue = value.replace(/\D/g, '');

    if (numericValue.length <= 10) {
      setMobileNo(numericValue);

      if (numericValue.length === 10) {
        Keyboard.dismiss();
        setMobileNoErr(null);
      }
    }
  };

  const submitHandler = async () => {

    const mobile = mobileNo.trim();


    if (!mobile) {
      setMobileNoErr('Please enter mobile number');
      return;
    }


    if (mobile.length !== 10) {
      setMobileNoErr('Mobile number must be 10 digits');
      return;
    }


    if (!/^[6-9]\d{9}$/.test(mobile)) {
      setMobileNoErr('Please enter a valid mobile number');
      return;
    }

    setMobileNoErr(null);


    if (isTerms === false) {
      Toast('Please accept terms and conditions');
      return;
    }
    setLoader(true);
    const res = await post(URLS.LOGIN, { mobile: mobileNo, country_code: '+91' });
    if (res?.status) {
      setLoader(false);
      Toast(res?.message);
      navigation.navigate('otp', { mobile: mobileNo, expires_in: res?.data?.expires_in, otp: res?.data?.otp });
    } else {
      setLoader(false);
      Toast(res?.message);
    }
  };

  return (
    <Template2>
      <View style={{ width: '100%', padding: 25 }}>
        <View>
          <Img src={logo} width={260} height={62} resize={'cover'} />
        </View>

        <Word
          text="Hi Welcome to NinosTranz 👋"
          font={3}
          color={C.BLACK}
          size={18}
          mt={20}
        />
        <Word
          text="Please enter your mobile Number to login"
          font={1}
          color={'black'}
          mt={45}
          size={14}
        />r
        <InputComponent
          mt={15}
          ErrorText={mobileNoErr}
          keyboardType={'number'}
          textColor={C.BLACK}
          ErrorColor={C.RED}
          maxLength={10}
          errMsg={'Enter valid Mobile No'}
          onChangeText={onChangeHandler}
          ps={10}
          pe={15}
          placeholder="Enter Mobile Number"
          img={call}
          value={mobileNo}
          countryCode={'+91'}
        />
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            // marginTop: VS(15),
          }}>
          <TouchableOpacity
            onPress={termsClickHandler}
            style={{
              marginRight: 7,
              borderWidth: isTerms ? 0 : 1,
              borderColor: C.BLACK,
              padding: 5,
              borderRadius: MS(5),
              width: HS(18),
              height: VS(18),
              alignItems: 'center',
              justifyContent: 'center'
            }}>
            <Img src={isTerms ? boxIcon : null} width={18} height={18} />
          </TouchableOpacity>
          <View>
            <Word
              text="By Login you are agreeing to our Terms & Conditions"
              font={1}
              size={12}
              color={C.BLACK}
            />
            <Word
              text={'and Privacy Policy'}
              color={C.BLACK}
              font={1}
              size={12}
            />
          </View>
        </View>
      </View>
      <View style={{ width: '100%', position: 'absolute', bottom: VS(0), padding: MS(25) }}>
        <CommonButton
          title={'Confirm'}
          onPress={submitHandler}
          loader={loader}
        />
      </View>
    </Template2>
  );
};

export default Login;
