import { Pressable, StyleSheet, Text, View } from 'react-native'
import React, { useState } from 'react';
import KeyboardAvoidScrollingTemplate from '../../Component/Template/KeyboardAvoidScrollingTemplate';
import Img from '../../Component/img/Img';
import { editIcon, leftArrow } from '../../assets/images/imgIndex';
import { HS, VS } from '../../Utils/FontSize';
import Word from '../../Component/Word/Word';
import InputComponent from '../../Component/InputComponent/InputComponent';
import CommonButton from '../../Component/Buttons/CommonButton';
import { useNavigation, useRoute } from '@react-navigation/native';
import RadioBtn from '../../Component/Buttons/RadioBtn';
import Header from '../Common/Header';
import UploadImagePopup from '../../Component/modal/UploadImagePopup';
import { mmkvStorage, Toast } from '../../Utils/Constants';
import { URLS } from '../../Redux/apiRequest/Constant';
import { post } from '../../Redux/apiRequest/ApiHandler';

const Register = () => {
  const navigation = useNavigation();
  const [image, setImage] = useState(null);
  const [loader, setLoader] = useState(false);
  const [showUploadPopup, setShowUploadPopup] = useState(false);
  const [gender, setGender] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: '',
  });
  const route = useRoute();
  const { mobile } = route.params;

  const submitHandler = async () => {
    if (!formData.name) {
      Toast('Please enter your name');
      return;
    }

    if (!formData.email) {
      Toast('Please enter your email');
      return;
    }

    if (!formData.address) {
      Toast('Please enter your address');
      return;
    }

    const payload = new FormData();

    payload.append('name', formData.name);
    payload.append('email', formData.email);
    payload.append('gender', gender);
    payload.append('address', formData.address);
    payload.append('mobile', mobile);
    payload.append('country_code', '+91');

    if (image?.uri) {
      payload.append('profile_image', {
        uri: image.uri,
        type: image.type || 'image/jpeg',
        name: image.name || image.fileName || 'profile.jpg',
      });
    }

    console.log('Payload:', payload);
    setLoader(true);
    const res = await post(URLS.REGISTER, payload);

    if (res?.status) {
      Toast(res?.message || 'Registration successful');
      mmkvStorage.set('token', res?.data?.token);
      mmkvStorage.set('userdata', JSON.stringify(res?.data));
      setLoader(false);
      navigation.reset({
        index: 0,
        routes: [{ name: 'referral' }],
      });
    } else {
      setLoader(false);
      Toast(res?.message || 'Registration failed');
    }
  };

  const handleImageSelect = data => {
    console.log('Selected Image:', data);
    setImage(data);
  };

  return (
    <KeyboardAvoidScrollingTemplate>
      <View style={{ width: '100%' }}>
        <Header name="Registration" />
        <View style={styles.inputContainer}>
          <View style={{ alignSelf: 'center', marginBottom: VS(30), position: 'relative', width: HS(110), }}>
            <Img
              src={
                image?.uri
                  ? { uri: image.uri }
                  : {
                    uri: 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png',
                  }
              }
              width={100}
              height={100}
              radius={50}
              resize="cover"
            />
            <Pressable onPress={() => setShowUploadPopup(true)} style={styles.imageContainer}>
              <Img src={editIcon} width={20} height={20} />
            </Pressable>
          </View>

          <InputComponent
            placeholder='Enter your name'
            value={formData.name}
            onChangeText={text => setFormData({ ...formData, name: text })}

          />
          <InputComponent
            placeholder='Enter your email'
            value={formData.email}
            onChangeText={text => setFormData({ ...formData, email: text })}
          />
          <View style={styles.radioContainer}>
            <RadioBtn
              title="Male"
              value={gender === 1}
              onPress={() => setGender(1)}
            />

            <RadioBtn
              title="Female"
              value={gender === 2}
              onPress={() => setGender(2)}
            />
            <RadioBtn
              title="Others"
              value={gender === 3}
              onPress={() => setGender(3)}
            />
          </View>
          <InputComponent
            mt={20}
            placeholder='Enter your address'
            value={formData.address}
            onChangeText={text => setFormData({ ...formData, address: text })}
            multiline
            numberOfLines={4}
          />
        </View>
      </View>
      <View style={{ width: '100%', position: 'absolute', bottom: VS(0), padding: 25 }}>
        <CommonButton
          title={'Confirm'}
          onPress={submitHandler}
          loader={loader}
        />
      </View>
      {showUploadPopup &&
        <UploadImagePopup
          visible={showUploadPopup}
          setImagePopup={setShowUploadPopup}
          onSelect={handleImageSelect}
        />
      }
    </KeyboardAvoidScrollingTemplate>
  )
}

export default Register

const styles = StyleSheet.create({
  header: {
    width: '100%',
    height: HS(40),
    paddingHorizontal: HS(15),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  inputContainer: {
    width: '100%',
    paddingHorizontal: HS(15),
    marginTop: HS(20),
  },
  radioContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: VS(20),
    gap: HS(10),
  },
  imageContainer: {
    position: 'absolute',
    bottom: VS(-5), right: 0,
    backgroundColor: '#fff',
    borderRadius: 50, padding: 5
  }

})