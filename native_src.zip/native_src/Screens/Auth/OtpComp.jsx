import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  TextInput,
  TouchableOpacity,
  Alert,
  Keyboard,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';

import Template2 from '../../Component/Template/Template2';
import Img from '../../Component/img/Img';
import Word from '../../Component/Word/Word';
import CommonButton from '../../Component/Buttons/CommonButton';

import { logo } from '../../assets/images/imgIndex';
import { C, F } from '../../Utils/ColorFonts';
import { MS, VS } from '../../Utils/FontSize';
import { mmkvStorage, Toast } from '../../Utils/Constants';
import { URLS } from '../../Redux/apiRequest/Constant';
import { post } from '../../Redux/apiRequest/ApiHandler';

const OtpComp = () => {
  const navigation = useNavigation();

  const [loader, setLoader] = useState(false);
  const route = useRoute();
  const { mobile, expires_in, otp: sentOtp } = route.params;
  const [timer, setTimer] = useState(expires_in || 0);
  const [otp, setOtp] = useState(['', '', '', '']);

  useEffect(() => {
    if (sentOtp) {
      Alert.alert('OTP Received', `Your OTP is: ${sentOtp}`, [{ text: 'OK' }]);
    }
  }, [sentOtp]);

  const input1 = useRef(null);
  const input2 = useRef(null);
  const input3 = useRef(null);
  const input4 = useRef(null);

  const inputRefs = [input1, input2, input3, input4];

  const handleChange = (text, index) => {
    if (!/^\d*$/.test(text)) return;

    const newOtp = [...otp];
    newOtp[index] = text;
    setOtp(newOtp);

    if (text && index < 3) {
      inputRefs[index + 1].current.focus();
    } else {
      Keyboard.dismiss();
    }
  };

  const handleKeyPress = ({ nativeEvent }, index) => {
    if (
      nativeEvent.key === 'Backspace' &&
      otp[index] === '' &&
      index > 0
    ) {
      inputRefs[index - 1].current.focus();
    }
  };

  const submitHandler = async () => {
    const finalOtp = otp.join('');

    if (finalOtp.length !== 4) {
      Toast('Please enter a valid OTP');
      return;
    }
    setLoader(true);
    const res = await post(URLS.VERIFY_OTP, {
      mobile: mobile,
      country_code: '+91',
      otp: finalOtp,
    });
    console.log("res otp", res);

    if (res?.status) {
      setLoader(false);
      Toast(res?.message || 'OTP verified successfully');
      if (res?.data?.is_newuser === false) {
        mmkvStorage.set('token', res?.data?.token);
        mmkvStorage.set('userdata', JSON.stringify(res?.data));
        navigation.reset({
          index: 0,
          routes: [{ name: 'home' }]
        });
      } else {
        navigation.navigate('register', { mobile: mobile });
      }
    } else {
      setLoader(false);
      Toast(res?.message || 'OTP verification failed');
    }
  };



  useEffect(() => {
    if (timer <= 0) return;

    const interval = setInterval(() => {
      setTimer(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [timer]);

  const handleResendOTP = async () => {
    const res = await post(URLS.LOGIN, { mobile: mobile, country_code: '+91' });
    if (res?.status) {
      setTimer(res?.data?.expires_in || 0);
      Alert.alert('OTP Received', `Your OTP is: ${res?.data?.otp}`, [{ text: 'OK' }]);
    }
  }

  return (
    <Template2>
      <View
        style={{
          width: '100%',
          padding: 25,
        }}>
        <Img
          src={logo}
          width={260}
          height={62}
          mt={15}
          resize={'cover'}
        />

        <Word
          text="Hi Welcome to NinosTranz 👋"
          font={3}
          color={C.BLACK}
          size={18}
          mt={20}
        />

        <Word
          text="Please enter the 4 digit OTP sent to your Mobile Number"
          font={1}
          color={'black'}
          mt={45}
          size={14}
        />

        {/* OTP BOXES */}

        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginTop: VS(15),
          }}>
          {otp.map((item, index) => (
            <TextInput
              key={index}
              ref={inputRefs[index]}
              value={item}
              onChangeText={text => handleChange(text, index)}
              onKeyPress={e => handleKeyPress(e, index)}
              keyboardType="number-pad"
              maxLength={1}
              textAlign="center"
              style={{
                width: 51,
                height: VS(51),
                borderWidth: 1,
                borderColor: C.GRAY3,
                borderRadius: 12,
                fontSize: MS(24),
                color: C.BLACK,
                fontFamily: F.f3,
              }}
            />
          ))}
        </View>

        {/* Resend */}

        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: VS(20),
          }}>
          <Word
            text="Didn't receive the OTP? "
            font={1}
            size={12}
            color={C.BLACK}
          />

          <TouchableOpacity onPress={handleResendOTP} disabled={timer > 0}>
            <Word
              text={
                timer > 0
                  ? `Resend OTP in ${timer} sec`
                  : 'Resend OTP'
              }
              color={C.PRIMARY}
              font={3}
              size={12}
            />
          </TouchableOpacity>
        </View>
      </View>

      <View
        style={{
          width: '100%',
          position: 'absolute',
          bottom: 0,
          padding: 25,
        }}>
        <CommonButton
          title="Confirm"
          onPress={submitHandler}
          loader={loader}
        />
      </View>
    </Template2>
  );
};

export default OtpComp;