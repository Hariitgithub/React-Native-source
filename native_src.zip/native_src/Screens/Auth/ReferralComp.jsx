import { View, TouchableOpacity, Pressable } from 'react-native';
import React, { useState } from 'react';
import Template2 from '../../Component/Template/Template2';
import { boxI1con, boxIcon, call, logo, } from '../../assets/images/imgIndex';
import { VS } from '../../Utils/FontSize';
import { C } from '../../Utils/ColorFonts';
import { useNavigation } from '@react-navigation/native';
import { NUMBER, Toast } from '../../Utils/Constants';
import Word from '../../Component/Word/Word';
import InputComponent from '../../Component/InputComponent/InputComponent';
import Img from '../../Component/img/Img';
import CommonButton from '../../Component/Buttons/CommonButton';
import { URLS } from '../../Redux/apiRequest/Constant';
import { post } from '../../Redux/apiRequest/ApiHandler';


const ReferralComp = () => {
  const navigation = useNavigation();

  const [loader, setLoader] = useState(false);

  const [referralCode, setReferralCode] = useState('');
  const [referralCodeErr, setReferralCodeErr] = useState(false);


  const onChangeReferral = (text) => {
    setReferralCode(text);

    if (text.trim().length > 0) {
      setReferralCodeErr('');
    }
  };

  const submitHandler = async () => {
    if (!referralCode?.trim()) {
      Toast('Please enter the referral code');
      return;
    }

    if (referralCode.trim().length < 4) {
      Toast('Please enter a valid referral code');
      return;
    }

    setLoader(true);

    const res = await post(URLS.REFERRAL, { referral_code: referralCode });
    if (res?.status) {
      setLoader(false);
      Toast(res?.message);
      navigation.reset({
        index: 0,
        routes: [{ name: 'home' }]
      });
    } else {
      setLoader(false);
    }

  };

  return (
    <Template2>
      <View style={{ width: '100%', padding: 25 }}>
        <View>
          <Img src={logo} width={260} height={62} resize={'cover'} />
        </View>

        <Word
          text="Hi Welcome to NinosTranz 👋"
          font={3}
          color={C.BLACK}
          size={18}
          mt={20}
        />
        <Word
          text="Please enter the referral Code"
          font={1}
          color={'black'}
          mt={45}
          size={14}
        />
        <InputComponent
          mh={20}
          mt={5}
          err={referralCodeErr}
          textColor={C.BLACK}
          ErrorColor={C.RED}
          errMsg={'Enter valid referral Code'}
          onChangeText={onChangeReferral}
          ps={10}
          pe={15}
          placeholder="Enter Referral Code"
          value={referralCode}
        />

      </View>
      <View style={{ width: '100%', position: 'absolute', bottom: VS(0), padding: 25 }}>
        <Pressable style={{ alignSelf: 'center', marginBottom: VS(10) }} onPress={() => navigation.navigate('home')}>
          <Word text={'Skip'} font={2} />
        </Pressable>
        <CommonButton
          title={'Confirm'}
          onPress={submitHandler}
          loader={loader}
        />
      </View>
    </Template2>
  );
};

export default ReferralComp;
