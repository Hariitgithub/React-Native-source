import { StyleSheet, Text, View } from 'react-native'
import React, { useCallback, useState } from 'react';
import KeyboardAvoidScrollingTemplate from '../../Component/Template/KeyboardAvoidScrollingTemplate';
import Header from '../Common/Header';
import { MS, VS } from '../../Utils/FontSize';
import { URLS } from '../../Redux/apiRequest/Constant';
import { get } from '../../Redux/apiRequest/ApiHandler';
import Word from '../../Component/Word/Word';
import { C } from '../../Utils/ColorFonts';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import Img from '../../Component/img/Img';
import CommonButton from '../../Component/Buttons/CommonButton';
import { folderIcon } from '../../assets/images/imgIndex';


const AccountDeactivated = () => {
    const navigation = useNavigation();
    const [formData, setFormData] = useState({
        name: '',
        mobile: '',
        profile_image: '',
    });

    const getData = async () => {
        const res = await get(URLS.VIEW_PROFILE);
        const data = res?.data
        setFormData({
            name: data?.name,
            mobile: data?.mobile,
            profile_image: data?.profile_image,
        })
    }

    useFocusEffect(
        useCallback(() => {
            getData();
        }, [])
    );

    const handleDelete = () => {
        navigation.navigate('deleteOTP', { isDelete: false });
    }

    return (
        <>
            <Header name={'Account Deactivated'} />
            <KeyboardAvoidScrollingTemplate>
                <View style={styles.contantContain}>
                    <View style={styles.profileContainer}>
                        <Img
                            src={
                                formData?.profile_image
                                    ? { uri: formData?.profile_image }
                                    : {
                                        uri: 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png',
                                    }
                            }
                            width={100}
                            height={100}
                            radius={50}
                            resize="cover"
                        />

                        <Word
                            text={formData?.name || "SATHISH R"}
                            mt={12}
                            font={2}
                        />

                        <Word
                            text={formData?.mobile || "xxx xxx xxxx"}
                            mt={5}
                            font={1}
                            color="#666"
                        />
                    </View>
                    <Img src={folderIcon} width={75} height={75} />
                    <Word align={'center'} text={'Your Account has been deleted!'} font={3} size={24} />
                    <Word align={'center'} ml={20} me={20} font={1} size={16} color={C.BLACK} text={'Your account has been deactivated and will be permanently removed soon. If you wish to restore it, Click the restore button and Enter the OTP sent to your email before the final deletion process is completed.'} />
                </View>
            </KeyboardAvoidScrollingTemplate>
            <View style={{ width: '100%', position: 'absolute', bottom: VS(0), padding: 25 }}>
                <CommonButton
                    title={'Restore with Email'}
                    onPress={handleDelete}
                // loading={loader}
                />
            </View>
        </>
    )
}

export default AccountDeactivated;

const styles = StyleSheet.create({
    profileContainer: {
        alignItems: 'center',
        marginTop: VS(20),
        marginBottom: VS(20),
    },
    contantContain: {
        padding: MS(20),
        alignItems: 'center',
        gap: MS(20)
    }
})